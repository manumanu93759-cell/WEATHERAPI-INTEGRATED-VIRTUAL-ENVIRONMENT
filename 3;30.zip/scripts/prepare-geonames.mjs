/**
 * Downloads GeoNames IN.txt and writes a compact gzip index for server-side search.
 * Source: https://download.geonames.org/export/dump/IN.zip (CC BY 4.0)
 */
import { createWriteStream, readFileSync } from "node:fs";
import { mkdir, writeFile, stat } from "node:fs/promises";
import { pipeline } from "node:stream/promises";
import { createGzip } from "node:zlib";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const OUT_DIR = path.join(ROOT, "server", "data");
const ZIP_PATH = "/tmp/geonames-IN.zip";
const TXT_PATH = "/tmp/geonames-IN.txt";
const ADMIN1_PATH = "/tmp/geonames-admin1.txt";
const OUT_PATH = path.join(OUT_DIR, "geonames-in.json.gz");
const META_PATH = path.join(OUT_DIR, "geonames-meta.json");

const KEEP_CLASS = new Set(["P", "A"]);
const KEEP_CODES = new Set([
  "PK", "MT", "HLL", "HLLS", "PASS",
  "PRK", "RESW", "RESF", "RESN",
  "BCH", "BCHS", "LGN", "ISLS", "ISL",
  "TEMP", "HSTS", "MNMT", "PYR", "CARN",
  "DAM", "FLLS", "GLCR",
]);

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: "inherit" });
    child.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(`${cmd} exited ${code}`))));
  });
}

async function download(url, dest) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed ${res.status} ${url}`);
  await pipeline(res.body, createWriteStream(dest));
}

async function ensureDump() {
  try {
    const s = await stat(ZIP_PATH);
    if (s.size < 1_000_000) throw new Error("zip too small");
  } catch {
    console.log("Downloading GeoNames IN.zip…");
    await download("https://download.geonames.org/export/dump/IN.zip", ZIP_PATH);
  }
  console.log("Extracting IN.txt…");
  await run("unzip", ["-o", "-d", "/tmp", ZIP_PATH, "IN.txt"]);
  await run("mv", ["-f", "/tmp/IN.txt", TXT_PATH]);
  console.log("Downloading admin1 codes…");
  await download("https://download.geonames.org/export/dump/admin1CodesASCII.txt", ADMIN1_PATH);
}

function parseAdmin1() {
  const text = readFileSync(ADMIN1_PATH, "utf8");
  const map = {};
  for (const line of text.split("\n")) {
    if (!line.startsWith("IN.")) continue;
    const [code, name] = line.split("\t");
    map[code.replace("IN.", "")] = name;
  }
  return map;
}

function categoryFor(fclass, fcode) {
  if (fcode === "ADM1") return "state";
  if (fcode === "ADM2" || fcode === "ADM3") return "district";
  if (fcode === "PPLC" || fcode === "PPLA") return "city";
  if (fcode === "PPLA2" || fcode === "PPLA3" || fcode === "PPLA4") return "town";
  if (fclass === "P") return Number(fcode.replace(/\D/g, "") || 0) > 0 || fcode === "PPL" ? "village" : "town";
  if (fcode === "BCH" || fcode === "BCHS") return "beach";
  if (fcode === "PRK" || fcode.startsWith("RES")) return "park";
  if (fcode === "TEMP" || fcode === "HSTS" || fcode === "MNMT") return "pilgrimage";
  if (fclass === "T" || fclass === "H" || fclass === "L" || fclass === "S") return "landmark";
  return "place";
}

async function compact() {
  const admin1 = parseAdmin1();
  const text = readFileSync(TXT_PATH, "utf8");
  const records = [];
  const counts = {};
  for (const line of text.split("\n")) {
    if (!line) continue;
    const cols = line.split("\t");
    const fclass = cols[6];
    const fcode = cols[7];
    if (!KEEP_CLASS.has(fclass) && !KEEP_CODES.has(fcode)) continue;
    const lat = Number(cols[4]);
    const lon = Number(cols[5]);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
    if (lat < 6 || lat > 37.8 || lon < 67 || lon > 97.8) continue;
    const name = cols[1];
    const ascii = cols[2];
    const alts = cols[3] ? cols[3].split(",").slice(0, 6) : [];
    const rec = {
      id: `gn-${cols[0]}`,
      name,
      lat: Math.round(lat * 1e5) / 1e5,
      lon: Math.round(lon * 1e5) / 1e5,
      category: categoryFor(fclass, fcode),
      fcode,
      state: admin1[cols[10]] || "",
      district: "",
      population: Number(cols[14]) || 0,
      source: "geonames",
    };
    if (ascii && ascii !== name) alts.unshift(ascii);
    if (alts.length) rec.alternateNames = alts.slice(0, 8);
    records.push(rec);
    counts[rec.category] = (counts[rec.category] || 0) + 1;
  }

  await mkdir(OUT_DIR, { recursive: true });
  const json = JSON.stringify(records);
  await pipeline(
    async function* () {
      yield json;
    }(),
    createGzip({ level: 9 }),
    createWriteStream(OUT_PATH)
  );
  const meta = {
    generatedAt: new Date().toISOString(),
    recordCount: records.length,
    categories: counts,
    source: "GeoNames IN dump (CC BY 4.0)",
    attribution: "GeoNames https://www.geonames.org/",
  };
  await writeFile(META_PATH, JSON.stringify(meta, null, 2));
  const outStat = await stat(OUT_PATH);
  console.log(`Wrote ${records.length} records → ${OUT_PATH} (${Math.round(outStat.size / 1024)} KB gzip)`);
  console.log(counts);
}

await ensureDump();
await compact();
