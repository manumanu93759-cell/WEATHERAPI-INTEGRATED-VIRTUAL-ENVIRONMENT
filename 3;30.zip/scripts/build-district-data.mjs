/**
 * Builds simplified, lazily-loadable district datasets from udit-001/india-maps-data
 * (put the repo's geojson/states/*.geojson into data-src/states/). Run: node scripts/build-district-data.mjs
 * Output: public/data/districts/<state-slug>.json, public/data/district-index.json, public/data/places-index.json
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";
import { normalize, normalizeState, slugify, stateSlug } from "../src/utils/geoText.js";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SRC = path.join(ROOT, "data-src", "states");
const OUT = path.join(ROOT, "public", "data");
const TOL = Number(process.env.SIMPLIFY_TOL || 0.004); // degrees (~400 m)
const r3 = (n) => Math.round(n * 1000) / 1000;

function dp(pts, tol) { // Douglas-Peucker (iterative)
  if (pts.length < 5) return pts;
  const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1;
  const st = [[0, pts.length - 1]];
  while (st.length) {
    const [a, b] = st.pop(); let md = 0, mi = -1;
    const [ax, ay] = pts[a], [bx, by] = pts[b]; const dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
    for (let i = a + 1; i < b; i++) {
      const [px, py] = pts[i]; let t = L ? ((px - ax) * dx + (py - ay) * dy) / L : 0; t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(px - (ax + t * dx), py - (ay + t * dy)); if (d > md) { md = d; mi = i; }
    }
    if (md > tol && mi > 0) { keep[mi] = 1; st.push([a, mi], [mi, b]); }
  }
  return pts.filter((_, i) => keep[i]);
}
function ring(r) {
  let o = dp(r.slice(0, -1), TOL).map(([x, y]) => [r3(x), r3(y)]);
  o = o.filter((p, i) => i === 0 || p[0] !== o[i - 1][0] || p[1] !== o[i - 1][1]);
  if (o.length < 3) return null; o.push(o[0]); return o;
}
function simplifyGeom(g) {
  const polys = g.type === "Polygon" ? [g.coordinates] : g.coordinates;
  const out = [];
  for (const p of polys) { const outer = ring(p[0]); if (!outer) continue; const holes = p.slice(1).map(ring).filter(Boolean); out.push([outer, ...holes]); }
  return out.length ? { type: "MultiPolygon", coordinates: out } : null;
}
function area(r) { let s = 0; for (let i = 0; i < r.length - 1; i++) s += r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1]; return s / 2; }
function bbox(mp) { let a = 1e9, b = 1e9, c = -1e9, d = -1e9; for (const p of mp) for (const [x, y] of p[0]) { a = Math.min(a, x); b = Math.min(b, y); c = Math.max(c, x); d = Math.max(d, y); } return [a, b, c, d]; }
function centroid(mp) { // area-weighted centroid of the largest polygon; falls back to bbox centre if outside
  let best = null, ba = 0; for (const p of mp) { const a = Math.abs(area(p[0])); if (a > ba) { ba = a; best = p[0]; } }
  let cx = 0, cy = 0, A = 0; for (let i = 0; i < best.length - 1; i++) { const f = best[i][0] * best[i + 1][1] - best[i + 1][0] * best[i][1]; cx += (best[i][0] + best[i + 1][0]) * f; cy += (best[i][1] + best[i + 1][1]) * f; A += f; }
  let pt = A ? [cx / (3 * A), cy / (3 * A)] : best[0];
  if (!pip(pt, mp)) { // concave: use midpoint of widest horizontal chord through the bbox centre line
    const bb = bbox(mp), y = (bb[1] + bb[3]) / 2, xs = [];
    for (const p of mp) { const r = p[0]; for (let i = 0; i < r.length - 1; i++) { const [x1, y1] = r[i], [x2, y2] = r[i + 1]; if ((y1 <= y) !== (y2 <= y)) xs.push(x1 + ((y - y1) / (y2 - y1)) * (x2 - x1)); } }
    xs.sort((a, b) => a - b); let w = -1; for (let i = 0; i + 1 < xs.length; i += 2) if (xs[i + 1] - xs[i] > w) { w = xs[i + 1] - xs[i]; pt = [(xs[i] + xs[i + 1]) / 2, y]; }
  }
  return [r3(pt[0]), r3(pt[1])];
}
function inRing(pt, r) { let c = false; for (let i = 0, j = r.length - 1; i < r.length; j = i++) { const [xi, yi] = r[i], [xj, yj] = r[j]; if ((yi > pt[1]) !== (yj > pt[1]) && pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) c = !c; } return c; }
function pip(pt, mp) { return mp.some((p) => inRing(pt, p[0]) && !p.slice(1).some((h) => inRing(pt, h))); }

fs.mkdirSync(path.join(OUT, "districts"), { recursive: true });
const usedIds = new Set(); const index = [], all = []; const report = { states: {}, skipped: [] };
for (const f of fs.readdirSync(SRC).filter((x) => x.endsWith(".geojson")).sort()) {
  const slug = f.replace(".geojson", ""); const fc = JSON.parse(fs.readFileSync(path.join(SRC, f), "utf8"));
  const feats = [];
  for (const ft of fc.features) {
    const p = ft.properties || {};
    if (!ft.geometry || !p.district || !p.st_nm) { report.skipped.push({ file: f, props: p }); continue; }
    const g = simplifyGeom(ft.geometry); if (!g) { report.skipped.push({ file: f, props: p, reason: "degenerate" }); continue; }
    const state = String(p.st_nm).trim(), name = String(p.district).trim();
    let id = `${slugify(state)}:${slugify(name)}`; for (let n = 2; usedIds.has(id); n++) id = `${slugify(state)}:${slugify(name)}-${n}`; usedIds.add(id);
    const c = centroid(g.coordinates), bb = bbox(g.coordinates);
    const rec = { id, name, state, stateSlug: stateSlug(state), lat: c[1], lon: c[0], bbox: bb.map(r3), vintage: p.year || "" };
    feats.push({ type: "Feature", properties: { id, name, state, stateSlug: rec.stateSlug, lat: rec.lat, lon: rec.lon }, geometry: g });
    index.push(rec); all.push({ rec, g: g.coordinates });
  }
  const outSlug = feats.length ? stateSlug(feats[0].properties.state) : slug;
  fs.writeFileSync(path.join(OUT, "districts", `${outSlug}.json`), JSON.stringify({ type: "FeatureCollection", features: feats }));
  report.states[outSlug] = feats.length;
}
if (usedIds.size !== index.length) throw new Error("duplicate ids");
fs.writeFileSync(path.join(OUT, "district-index.json"), JSON.stringify(index));

// Places index (cities + towns from GeoNames, CC BY 4.0) with district assignment by point-in-polygon.
const gnPath = path.join(ROOT, "server", "data", "geonames-in.json.gz");
const places = [];
if (fs.existsSync(gnPath)) {
  const gn = JSON.parse(zlib.gunzipSync(fs.readFileSync(gnPath)));
  const byState = new Map(); for (const a of all) { const k = normalizeState(a.rec.state); (byState.get(k) || byState.set(k, []).get(k)).push(a); }
  let unassigned = 0;
  for (const p of gn) {
    if (p.category !== "city" && p.category !== "town") continue;
    const cands = byState.get(normalizeState(p.state)) || []; let d = "";
    for (const a of cands) { const b = a.rec.bbox; if (p.lon < b[0] || p.lon > b[2] || p.lat < b[1] || p.lat > b[3]) continue; if (pip([p.lon, p.lat], a.g)) { d = a.rec.name; break; } }
    if (!d) unassigned++;
    places.push([p.name, p.state, d, r3(p.lat), r3(p.lon), p.category === "city" ? 1 : 0, p.population || 0, (p.alternateNames || []).slice(0, 3)]);
  }
  report.placesUnassignedDistrict = unassigned;
}
fs.writeFileSync(path.join(OUT, "places-index.json"), JSON.stringify(places));
report.districts = index.length; report.places = places.length;
fs.writeFileSync(path.join(ROOT, "data-src", "build-report.json"), JSON.stringify(report, null, 1));
console.log(JSON.stringify({ districts: report.districts, places: report.places, skipped: report.skipped.length, unassigned: report.placesUnassignedDistrict }));
