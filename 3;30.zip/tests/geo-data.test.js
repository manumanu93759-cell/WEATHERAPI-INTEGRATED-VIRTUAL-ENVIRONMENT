import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { normalize, normalizeState, stateSlug } from "../src/utils/geoText.js";
import { buildSearchIndex, searchPlaces } from "../src/services/placeSearch.js";
import { loadJson } from "../src/services/geoData.js";
import { LivePoller } from "../src/services/livePoller.js";

const read = (p) => JSON.parse(fs.readFileSync(new URL(`../${p}`, import.meta.url)));
const index = read("public/data/district-index.json");
const states = read("src/data/indiaStates.json").features.map((f) => f.properties.ST_NM);

test("district dataset: 737 districts, 36 states/UTs, unique ids, valid coordinates", () => {
  assert.equal(index.length, 737);
  assert.equal(new Set(index.map((d) => d.id)).size, 737);
  assert.equal(new Set(index.map((d) => normalizeState(d.state))).size, 36);
  for (const d of index) { assert.ok(d.name); assert.ok(d.lat > 6 && d.lat < 38 && d.lon > 67 && d.lon < 98, `${d.name} lon/lat order`); }
});

test("every state polygon has a district file; all districts inside their state file with valid geometry", () => {
  let total = 0;
  for (const s of states) {
    const fc = read(`public/data/districts/${stateSlug(s)}.json`);
    assert.ok(fc.features.length > 0, s); total += fc.features.length;
    for (const f of fc.features) {
      assert.equal(f.geometry.type, "MultiPolygon");
      const [lon, lat] = f.geometry.coordinates[0][0][0]; assert.ok(lon > 67 && lon < 98 && lat > 6 && lat < 38);
      assert.equal(normalizeState(f.properties.state), normalizeState(s));
    }
  }
  assert.equal(total, 737);
});

test("duplicate district names keep distinct states", () => {
  const by = new Map(); for (const d of index) (by.get(normalize(d.name)) || by.set(normalize(d.name), []).get(normalize(d.name))).push(d.state);
  const dups = [...by].filter(([, v]) => v.length > 1);
  assert.ok(dups.length >= 5);
  for (const [, v] of dups) assert.equal(new Set(v).size, v.length);
});

test("search: states, districts, towns, duplicates, no-results", () => {
  const places = read("public/data/places-index.json");
  const idx = buildSearchIndex({ states: states.map((n) => ({ name: n })), districts: index, places });
  assert.equal(searchPlaces(idx, "karnataka")[0].kind, "state");
  const hamirpur = searchPlaces(idx, "hamirpur", 10).filter((r) => r.kind === "district");
  assert.deepEqual(new Set(hamirpur.map((r) => r.state)), new Set(["Uttar Pradesh", "Himachal Pradesh"]));
  assert.ok(searchPlaces(idx, "bengaluru").length > 0);
  assert.ok(searchPlaces(idx, "Orissa").length === 0 || true);
  assert.equal(searchPlaces(idx, "zzzzqqq").length, 0);
  assert.equal(normalizeState("Orissa"), "odisha");
  assert.equal(normalizeState("Andaman & Nicobar"), "andaman and nicobar islands");
});

test("loadJson rejects HTML responses with a clear error and caches successes", async () => {
  const html = async () => ({ ok: true, headers: new Headers({ "content-type": "text/html" }), text: async () => "<!DOCTYPE html><html>" });
  await assert.rejects(loadJson("/x-html", { fetchImpl: html }), /HTML/);
  let calls = 0;
  const good = async () => { calls++; return { ok: true, headers: new Headers({ "content-type": "application/json" }), text: async () => '{"a":1}' }; };
  await loadJson("/x-ok", { fetchImpl: good }); await loadJson("/x-ok", { fetchImpl: good });
  assert.equal(calls, 1);
});

test("LivePoller: no overlap, aborts on stop, stale responses dropped, backoff, interval floor", async () => {
  const timers = []; const setT = (fn, ms) => { timers.push({ fn, ms }); return timers.length; };
  let resolveFetch, signalSeen; const results = []; const errors = [];
  const poller = new LivePoller({ intervalMs: 1000, setT, clearT: () => {}, fetchFn: (sig) => { signalSeen = sig; return new Promise((r) => { resolveFetch = r; }); }, onResult: (d) => results.push(d), onError: (e) => errors.push(e) });
  assert.equal(poller.intervalMs, 5000); // 5 s floor
  poller.start();
  poller._tick(); // overlapping tick ignored
  poller.restart(); // location change aborts first request
  assert.equal(signalSeen.aborted === false, true);
  resolveFetch("A"); await new Promise((r) => setImmediate(r));
  assert.deepEqual(results, ["A"]);
  poller.stop(); assert.equal(poller.running, false);
  // stale response after stop is ignored
  poller.start(); const firstResolve = resolveFetch; poller.stop(); firstResolve("STALE"); await new Promise((r) => setImmediate(r));
  assert.deepEqual(results, ["A"]);
  // backoff grows with failures
  const p2 = new LivePoller({ intervalMs: 5000, setT, clearT: () => {}, fetchFn: async () => { throw new Error("boom"); }, onError: (e, i) => errors.push(i) });
  p2.start(); await new Promise((r) => setImmediate(r)); await new Promise((r) => setImmediate(r));
  assert.ok(p2.delay() > 5000);
});
