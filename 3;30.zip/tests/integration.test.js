import { INDIAN_CITIES, searchIndianCities, getCityByName, isWithinIndia, findNearestIndianCity } from "../src/data/indianCities.js";
import { INDIAN_WEATHER_PRESETS, createSimulatedWeatherBundle, getIconForCondition } from "../src/services/demoWeather.js";
import { getAirQualityMeta, generateContextualGuidance, formatIST } from "../src/services/weatherService.js";
import { mapWeatherToEnvironment, computeSolarPhase } from "../src/environment.js";

function assert(condition, message) {
  if (!condition) {
    console.error(`❌ FAIL: ${message}`);
    process.exit(1);
  }
}

console.log("\n🧪 Running VARSHA Full Integration Test Suite...\n");

// --- TEST 1: Indian Geographic Database ---
console.log("▶ Testing Indian Cities Database & Geolocation Bounds...");
assert(INDIAN_CITIES.length >= 60, "Must contain at least 60 Indian cities across states/UTs");
assert(isWithinIndia(28.6139, 77.2090), "New Delhi coordinates must be inside India");
assert(isWithinIndia(19.0760, 72.8777), "Mumbai coordinates must be inside India");
assert(!isWithinIndia(51.5074, -0.1278), "London coordinates must be detected as outside India");
assert(!isWithinIndia(40.7128, -74.0060), "New York coordinates must be detected as outside India");

const nearestToMumbai = findNearestIndianCity(19.08, 72.88);
assert(nearestToMumbai.name === "Mumbai", "Nearest city to 19.08, 72.88 must be Mumbai");
console.log("  ✔ Cities count: " + INDIAN_CITIES.length + " (All verified within territory)");

// --- TEST 2: City Search ---
console.log("▶ Testing Indian City Search & Prefix Matching...");
const searchDelhi = searchIndianCities("delhi");
assert(searchDelhi.length > 0 && searchDelhi[0].name === "New Delhi", "Search 'delhi' should match New Delhi");
const searchBang = searchIndianCities("bengal");
assert(searchBang.some((c) => c.name === "Bengaluru"), "Search 'bengal' should match Bengaluru");
const emptySearch = searchIndianCities("");
assert(emptySearch.length === 0, "Empty search should return empty array");
console.log("  ✔ City search prefix and case-insensitive matching verified");

// --- TEST 3: Weather Presets & Scenarios ---
console.log("▶ Testing Indian Weather Presets (Monsoon, Storm, Heatwave, Fog, Snow)...");
for (const [key, preset] of Object.entries(INDIAN_WEATHER_PRESETS)) {
  const bundle = createSimulatedWeatherBundle({ presetKey: key, cityName: "Mumbai" });
  assert(bundle.city === "Mumbai", `Bundle city must match: ${key}`);
  assert(bundle.country === "IN", `Bundle country must be IN: ${key}`);
  assert(Array.isArray(bundle.hourly) && bundle.hourly.length === 8, `Hourly slots must be 8: ${key}`);
  assert(Array.isArray(bundle.daily) && bundle.daily.length === 5, `Daily forecast must be 5 days: ${key}`);
  assert(bundle.airQuality && bundle.airQuality.aqi >= 1 && bundle.airQuality.aqi <= 5, `AQI must be 1-5: ${key}`);
}
console.log("  ✔ All 6 Indian weather presets generated valid 24h hourly and 5-day forecast payloads");

// --- TEST 4: Environment Mapping ---
console.log("▶ Testing Atmospheric 3D World Mapping Rules...");
const monsoon = mapWeatherToEnvironment(createSimulatedWeatherBundle({ presetKey: "monsoon" }));
assert(monsoon.isMonsoon === 1, "Monsoon scenario must set isMonsoon = 1");
assert(monsoon.rainIntensity >= 0.9, "Monsoon must have high rain intensity");
assert(monsoon.wetness > 0.8, "Monsoon must have high surface wetness");

const storm = mapWeatherToEnvironment(createSimulatedWeatherBundle({ presetKey: "thunderstorm" }));
assert(storm.storminess > 0.8, "Thunderstorm must trigger high storminess and lightning");

const fog = mapWeatherToEnvironment(createSimulatedWeatherBundle({ presetKey: "fog" }));
assert(fog.fogDensity > 0.05, "Fog scenario must have high atmospheric fog density");

const heatwave = mapWeatherToEnvironment(createSimulatedWeatherBundle({ presetKey: "heatwave" }));
assert(heatwave.temperatureAccent > 0.8, "Heatwave must have elevated temperature accent");
assert(heatwave.rainIntensity === 0, "Heatwave must have 0 rain");
console.log("  ✔ 3D Atmospheric mapping verified for all meteorological states");

// --- TEST 5: Air Quality Index & Guidance ---
console.log("▶ Testing AQI Translation & Contextual Advisories...");
assert(getAirQualityMeta(1).label === "Good", "AQI 1 must be Good");
assert(getAirQualityMeta(5).label === "Very Poor / Severe", "AQI 5 must be Severe");

const heatGuidance = generateContextualGuidance({ temp: 43, weatherId: 800, windSpeed: 4, visibility: 8000 });
assert(heatGuidance.some((g) => g.type === "heat"), "43°C must trigger Heatwave alert");

const stormGuidance = generateContextualGuidance({ temp: 24, weatherId: 211, windSpeed: 14, visibility: 2500 });
assert(stormGuidance.some((g) => g.type === "storm"), "WeatherId 211 must trigger Thunderstorm advisory");
console.log("  ✔ AQI and contextual guidance generation verified");

// --- TEST 6: IST Time & Solar Arc Formatting ---
console.log("▶ Testing IST Local Time Calculations...");
const ist = formatIST(1700000000, 19800);
assert(ist.clock.includes("IST"), "Clock must be in IST");
assert(ist.full.includes("IST"), "Full date string must include IST");
console.log("  ✔ IST formatting verified");

console.log("\n🎉 ALL INTEGRATION TESTS PASSED SUCCESSFULLY! (6/6 Suites Passed)\n");
