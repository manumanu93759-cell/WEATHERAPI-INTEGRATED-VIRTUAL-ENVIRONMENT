# Geographic data sources, coverage and limitations

## District boundaries — `public/data/districts/*.json`, `public/data/district-index.json`
- Source: <https://github.com/udit-001/india-maps-data> (`geojson/states/*.geojson`, as uploaded). The repository's README says the data was curated from public internet sources; **the uploaded copy contains no LICENSE file, so the licence/redistribution terms are unverified. Confirm them before commercial use.**
- Verified content (see `data-src/build-report.json`): **737 district features** in 36 state/UT files (28 states + 8 UTs), all with geometry and names, unique generated IDs, coordinates in WGS84 longitude/latitude order.
- Vintage is **mixed**: most features are tagged Census 2011 (634), others 2012–2019 and one 2025 update. The dataset therefore may **not match today's official district list** (districts created later may be missing or merged; e.g. Delhi is a single feature). Counts were not checked against an official current list.
- Boundary lines for Jammu & Kashmir and Ladakh are exactly as depicted in the source dataset.
- Processing (`scripts/build-district-data.mjs`): Douglas–Peucker simplification at 0.004° (~400 m) with 3-decimal coordinates for web delivery (raw files were 28 MB). Districts are split per state and loaded lazily. A representative point (area centroid, or an interior point for concave shapes) is computed for each district. To regenerate, place the upstream `geojson/states/*.geojson` files in `data-src/states/` and run `npm run build:data`.
- 5 district names occur in two states (Aurangabad, Balrampur, Bilaspur, Hamirpur, Pratapgarh); search shows the state to disambiguate.

## State/UT outlines — `src/data/indiaStates.json` (unchanged, from the original VARSHA project).

## Cities and towns — `public/data/places-index.json`
- Source: GeoNames India dump (CC BY 4.0, <https://www.geonames.org/>) via `server/data/geonames-in.json.gz`; only places classed city/town are indexed (11,859). Villages and landmarks are **not** searchable. Each place is assigned to a district by point-in-polygon against the simplified boundaries; 144 could not be assigned and show state only.
- Not every Indian locality is searchable.

## Weather
OpenWeather (server-side key). Weather is for one coordinate (district representative point or the selected city), not an area average.
