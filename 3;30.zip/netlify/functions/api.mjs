// Netlify Function wrapping the Express apiRouter. Routes: /api/* (see netlify.toml)
import express from "express";
import { IncomingMessage, ServerResponse } from "node:http";
import { Socket } from "node:net";
import { apiRouter } from "../../server/apiRouter.js";

const app = express();
app.use("/api", apiRouter);

function json(status, body) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

export default async (request) => {
  try {
    const url = new URL(request.url);
    const req = new IncomingMessage(new Socket());
    req.method = request.method;
    req.url = url.pathname.replace(/^\/\.netlify\/functions\/api/, "/api") + url.search;
    request.headers.forEach((v, k) => { req.headers[k.toLowerCase()] = v; });
    const bodyText = ["GET", "HEAD"].includes(request.method) ? "" : await request.text();
    if (bodyText) req.push(bodyText);
    req.push(null);

    const res = new ServerResponse(req);
    const chunks = [];
    const done = new Promise((resolve) => {
      res.write = (c, enc, cb) => { if (c) chunks.push(Buffer.from(c, typeof enc === "string" ? enc : undefined)); if (typeof enc === "function") enc(); else if (cb) cb(); return true; };
      res.end = (c, enc, cb) => { if (c && typeof c !== "function") chunks.push(Buffer.from(c, typeof enc === "string" ? enc : undefined)); res.finished = true; resolve(); return res; };
    });
    app(req, res, () => { res.statusCode = 404; res.setHeader("content-type", "application/json"); res.end(JSON.stringify({ error: "NOT_FOUND", message: "Unknown API route." })); });
    await Promise.race([done, new Promise((_, r) => setTimeout(() => r(new Error("API timeout")), 20000))]);

    const headers = new Headers();
    for (const [k, v] of Object.entries(res.getHeaders())) headers.set(k, Array.isArray(v) ? v.join(", ") : String(v));
    if (!headers.has("content-type")) headers.set("content-type", "application/json");
    return new Response(Buffer.concat(chunks), { status: res.statusCode || 200, headers });
  } catch (err) {
    return json(500, { error: "FUNCTION_ERROR", message: String(err?.message || err) });
  }
};

export const config = { path: "/api/*" };
