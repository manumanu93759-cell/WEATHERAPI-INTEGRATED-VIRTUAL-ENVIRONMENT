import { defineConfig } from "vite";
import dotenv from "dotenv";
import { apiRouter } from "./server/apiRouter.js";

dotenv.config();

export default defineConfig({
  server: {
    port: 5173,
    strictPort: false,
  },
  preview: {
    port: 4173,
  },
  build: {
    target: "es2022",
    sourcemap: true,
    chunkSizeWarningLimit: 600,
    rollupOptions: {
      output: {
        manualChunks: {
          three: ["three"],
          chartjs: ["chart.js"],
        },
      },
    },
  },
  plugins: [
    {
      name: "varsha-api-middleware",
      configureServer(server) {
        server.middlewares.use("/api", apiRouter);
      },
    },
  ],
});
