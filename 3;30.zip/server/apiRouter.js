import { Router, json } from "express";
import dotenv from "dotenv";
import { INDIAN_CITIES, isWithinIndia, searchIndianCities, getCityByName } from "../src/data/indianCities.js";

// Load environment variables from .env
dotenv.config();

export const apiRouter = Router();
apiRouter.use(json());

// Compatibility middleware for Connect (Vite dev server) and Express
apiRouter.use((req, res, next) => {
  if (!res.json) {
    res.json = (data) => {
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify(data));
    };
  }
  if (!res.status) {
    res.status = (code) => {
      res.statusCode = code;
      return res;
    };
  }
  if (!req.query && req.url) {
    try {
      const parsed = new URL(req.url, "http://localhost");
      req.query = Object.fromEntries(parsed.searchParams.entries());
    } catch {
      req.query = {};
    }
  }
  next();
});

const OPENWEATHER_BASE = "https://api.openweathermap.org/data/2.5";
const REQUEST_TIMEOUT_MS = 8000;

// In-memory cache: key -> { data, expiresAt }
const cache = new Map();
// In-flight requests deduplication: key -> Promise
const inFlight = new Map();

function getCached(key) {
  const item = cache.get(key);
  if (!item) return null;
  if (Date.now() > item.expiresAt) {
    cache.delete(key);
    return null;
  }
  return item.data;
}

function setCached(key, data, ttlSeconds) {
  cache.set(key, {
    data,
    expiresAt: Date.now() + ttlSeconds * 1000,
  });
}

function getApiKey(req) {
  const fromHeader = req?.headers?.["x-api-key"] || req?.headers?.["authorization"]?.replace(/^Bearer\s+/i, "");
  const fromQuery = req?.query?.key || req?.query?.appid || req?.query?.apiKey;
  const fromEnv = process.env.OPENWEATHER_API_KEY;
  return (fromHeader || fromQuery || fromEnv || "").trim();
}

async function fetchWithTimeout(url, timeoutMs = REQUEST_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { signal: controller.signal });
    return response;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * GET /api/status
 * Returns server readiness and whether an OpenWeather API key is configured.
 */
apiRouter.get("/status", (req, res) => {
  const apiKey = getApiKey(req);
  const hasKey = apiKey.length > 0;
  res.json({
    ok: true,
    name: "VARSHA Weather Intelligence API",
    version: "1.0.0",
    hasKey,
    keyConfigured: hasKey,
    serverTimeIST: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
    cachedKeysCount: cache.size,
  });
});

/**
 * GET /api/cities
 * Returns curated Indian cities.
 */
apiRouter.get("/cities", (req, res) => {
  res.json({
    ok: true,
    count: INDIAN_CITIES.length,
    cities: INDIAN_CITIES,
  });
});

/**
 * GET /api/search?q=...
 * Searches Indian cities with prefix/substring matching.
 */
apiRouter.get("/search", (req, res) => {
  const q = String(req.query.q || "");
  const limit = Math.min(20, Math.max(1, Number(req.query.limit) || 8));
  const results = searchIndianCities(q, limit);
  res.json({
    ok: true,
    query: q,
    count: results.length,
    results,
  });
});

/**
 * GET /api/weather?city=...&lat=...&lon=...
 * Secure server-side OpenWeather Current Weather endpoint.
 */
apiRouter.get("/weather", async (req, res) => {
  const apiKey = getApiKey(req);
  if (!apiKey) {
    return res.status(200).json({
      error: "KEY_MISSING",
      code: "KEY_MISSING",
      message: "OPENWEATHER_API_KEY is not configured in .env on the server. You can configure it for live data or enjoy the full experience in Demo Mode.",
      isDemoAvailable: true,
    });
  }

  const { city, lat, lon } = req.query;

  // Determine query params
  const params = new URLSearchParams({
    appid: apiKey,
    units: "metric",
  });

  let cacheKey = "";
  let indianCityMeta = null;

  if (lat && lon) {
    const nLat = Number(lat);
    const nLon = Number(lon);
    if (!Number.isFinite(nLat) || !Number.isFinite(nLon)) {
      return res.status(400).json({ error: "INVALID_COORDINATES", message: "Invalid latitude or longitude." });
    }
    // Validate territory is in or around India
    if (!isWithinIndia(nLat, nLon)) {
      return res.status(400).json({
        error: "LOCATION_OUTSIDE_INDIA",
        message: "VARSHA is focused exclusively on India. Selected location is outside Indian territory.",
      });
    }
    params.set("lat", nLat.toFixed(4));
    params.set("lon", nLon.toFixed(4));
    cacheKey = `weather:coord:${nLat.toFixed(3)},${nLon.toFixed(3)}`;
  } else if (city) {
    const trimmed = String(city).trim();
    if (!trimmed) {
      return res.status(400).json({ error: "MISSING_CITY", message: "Please provide a valid Indian city name." });
    }
    indianCityMeta = getCityByName(trimmed);
    if (indianCityMeta) {
      params.set("lat", indianCityMeta.lat.toFixed(4));
      params.set("lon", indianCityMeta.lon.toFixed(4));
      cacheKey = `weather:city:${indianCityMeta.name.toLowerCase()}`;
    } else {
      // Ensure query is scoped to India
      const queryCity = trimmed.toLowerCase().includes(",in") || trimmed.toLowerCase().includes(", in")
        ? trimmed
        : `${trimmed},IN`;
      params.set("q", queryCity);
      cacheKey = `weather:q:${queryCity.toLowerCase()}`;
    }
  } else {
    return res.status(400).json({ error: "MISSING_PARAMS", message: "Please provide a city name or coordinates." });
  }

  // Check cache (5 minutes TTL for current weather)
  const cached = getCached(cacheKey);
  if (cached) {
    return res.json({ ...cached, _cached: true, _source: "server-cache" });
  }

  // Deduplicate in-flight requests
  if (inFlight.has(cacheKey)) {
    try {
      const data = await inFlight.get(cacheKey);
      return res.json(data);
    } catch (err) {
      // Fall through to retry
    }
  }

  const fetchPromise = (async () => {
    const url = `${OPENWEATHER_BASE}/weather?${params.toString()}`;
    let response;
    try {
      response = await fetchWithTimeout(url);
    } catch (err) {
      throw {
        status: 504,
        error: "NETWORK_TIMEOUT",
        message: "Timeout or network failure connecting to OpenWeather.",
      };
    }

    let payload;
    try {
      payload = await response.json();
    } catch {
      throw { status: 502, error: "MALFORMED_RESPONSE", message: "Invalid JSON response from weather provider." };
    }

    if (!response.ok) {
      if (response.status === 401) {
        throw {
          status: 401,
          error: "INVALID_KEY",
          message: "OpenWeather rejected the configured API key. Please check your credentials in .env.",
        };
      }
      if (response.status === 404) {
        throw { status: 404, error: "CITY_NOT_FOUND", message: "Indian city not found on weather provider." };
      }
      if (response.status === 429) {
        throw { status: 429, error: "RATE_LIMITED", message: "OpenWeather rate limit exceeded. Try again shortly." };
      }
      throw {
        status: response.status,
        error: "PROVIDER_ERROR",
        message: payload?.message || "Weather provider error.",
      };
    }

    // Attach Indian metadata if matched
    if (indianCityMeta) {
      payload._indianMeta = {
        name: indianCityMeta.name,
        state: indianCityMeta.state,
        region: indianCityMeta.region,
      };
    }

    // Cache valid payload for 300 seconds (5 mins)
    setCached(cacheKey, payload, Math.max(1, Number(process.env.WEATHER_CACHE_TTL_SECONDS) || 300));
    return payload;
  })();

  inFlight.set(cacheKey, fetchPromise);
  try {
    const result = await fetchPromise;
    res.json(result);
  } catch (err) {
    res.status(err.status || 500).json(err);
  } finally {
    inFlight.delete(cacheKey);
  }
});

/**
 * GET /api/forecast?city=...&lat=...&lon=...
 * 5-Day / 3-Hour Forecast endpoint.
 */
apiRouter.get("/forecast", async (req, res) => {
  const apiKey = getApiKey(req);
  if (!apiKey) {
    return res.status(200).json({
      error: "KEY_MISSING",
      code: "KEY_MISSING",
      message: "OPENWEATHER_API_KEY is not configured in .env on the server.",
      isDemoAvailable: true,
    });
  }

  const { city, lat, lon } = req.query;
  const params = new URLSearchParams({
    appid: apiKey,
    units: "metric",
  });

  let cacheKey = "";
  if (lat && lon) {
    const nLat = Number(lat);
    const nLon = Number(lon);
    if (!isWithinIndia(nLat, nLon)) {
      return res.status(400).json({ error: "OUTSIDE_INDIA", message: "Location outside India." });
    }
    params.set("lat", nLat.toFixed(4));
    params.set("lon", nLon.toFixed(4));
    cacheKey = `forecast:coord:${nLat.toFixed(3)},${nLon.toFixed(3)}`;
  } else if (city) {
    const trimmed = String(city).trim();
    const meta = getCityByName(trimmed);
    if (meta) {
      params.set("lat", meta.lat.toFixed(4));
      params.set("lon", meta.lon.toFixed(4));
      cacheKey = `forecast:city:${meta.name.toLowerCase()}`;
    } else {
      const queryCity = trimmed.toLowerCase().includes(",in") ? trimmed : `${trimmed},IN`;
      params.set("q", queryCity);
      cacheKey = `forecast:q:${queryCity.toLowerCase()}`;
    }
  } else {
    return res.status(400).json({ error: "MISSING_PARAMS", message: "City or coordinates required." });
  }

  const cached = getCached(cacheKey);
  if (cached) {
    return res.json({ ...cached, _cached: true });
  }

  try {
    const response = await fetchWithTimeout(`${OPENWEATHER_BASE}/forecast?${params.toString()}`);
    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({
        error: "FORECAST_ERROR",
        message: data?.message || "Failed to retrieve forecast data.",
      });
    }
    // Cache forecast for 15 minutes (900 seconds)
    setCached(cacheKey, data, 900);
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: "FORECAST_FETCH_FAILED", message: "Could not reach forecast service." });
  }
});

/**
 * GET /api/air-pollution?lat=...&lon=...
 * OpenWeather Air Pollution API endpoint (AQI, PM2.5, PM10, etc.).
 */
apiRouter.get(["/air-pollution", "/air_pollution"], async (req, res) => {
  const apiKey = getApiKey(req);
  if (!apiKey) {
    return res.status(200).json({
      error: "KEY_MISSING",
      code: "KEY_MISSING",
      message: "OPENWEATHER_API_KEY is not configured.",
      isDemoAvailable: true,
    });
  }

  const lat = Number(req.query.lat);
  const lon = Number(req.query.lon);

  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    return res.status(400).json({ error: "INVALID_COORDINATES", message: "Valid lat and lon required." });
  }

  if (!isWithinIndia(lat, lon)) {
    return res.status(400).json({ error: "OUTSIDE_INDIA", message: "Coordinates outside India." });
  }

  const cacheKey = `air:${lat.toFixed(3)},${lon.toFixed(3)}`;
  const cached = getCached(cacheKey);
  if (cached) {
    return res.json({ ...cached, _cached: true });
  }

  const params = new URLSearchParams({
    lat: lat.toFixed(4),
    lon: lon.toFixed(4),
    appid: apiKey,
  });

  try {
    const response = await fetchWithTimeout(`${OPENWEATHER_BASE}/air_pollution?${params.toString()}`);
    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({
        error: "AIR_QUALITY_ERROR",
        message: data?.message || "Failed to retrieve air pollution data.",
      });
    }
    // Cache for 15 minutes
    setCached(cacheKey, data, 900);
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: "AIR_QUALITY_FETCH_FAILED", message: "Could not reach air pollution service." });
  }
});
