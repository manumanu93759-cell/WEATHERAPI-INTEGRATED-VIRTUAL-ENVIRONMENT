# VARSHA — India's Live Weather Intelligence

> **Understand India's Weather. Experience It Live.**

VARSHA is an India-focused real-time weather intelligence platform. It transforms live meteorological telemetry into an interactive visual experience where an interactive dashboard, analytics charts, a live India weather map, and a procedural 3D visual world respond to real-time atmospheric conditions across the Indian subcontinent.

---

## 🌟 Key Features

1. **Focused Exclusively on India**
   - Curated index of all 28 Indian States and 8 Union Territories with 70+ major cities and state capitals.
   - Real-time search with instant prefix matching, keyboard navigation, and territory validation.
   - Bounded GPS geolocation ("Locate Me") detecting the nearest Indian city.

2. **Secure Server-Side API Architecture**
   - Private `OPENWEATHER_API_KEY` is kept strictly on the server in `.env`.
   - Never exposed to frontend bundles, browser `localStorage`, or client-side code.
   - Built-in in-memory caching (5-minute TTL for current weather, 15-minute TTL for forecast and air quality) and request deduplication to prevent rate limits.

3. **Interactive India Weather Map**
   - Built with Leaflet, centered on the Indian subcontinent `[22.0°N, 80.0°E]`.
   - Dynamic glowing city markers with live temperature tags and condition icons.
   - Click-to-select: clicking any city updates the entire dashboard, telemetry, charts, and 3D environment.

4. **Weather-Responsive 3D Visual Environment**
   - Procedural Three.js world dynamically responsive to Indian meteorology:
     - **Monsoon Deluge**: Heavy tropical cloud sheets, dense rain particles, saturated dark terrain, and accelerated water waves.
     - **Kalbaisakhi / Thunderstorm**: Dark convective storm atmosphere, high wind drift, and dynamic lightning flashes.
     - **Summer Heatwave (Loo)**: Scorching sunlight, heat haze, and minimal cloud cover.
     - **Winter Morning Fog**: Dense radiation fog with reduced visual range.
     - **Himalayan Snow**: Sub-zero ambient light, snow flurries, and frosty terrain peaks.
     - **Clear Night**: Indian night sky with starlight constellations and moonlight on water.
   - Full support for `prefers-reduced-motion` and multiple camera viewpoints (Cinematic Orbit, Horizon View, Top-Down).

5. **Atmospheric Telemetry Dashboard**
   - **Hero Card**: Temperature, feels-like, diurnal high/low, condition badge, and Indian local time (IST).
   - **Telemetry Grid**: Humidity, wind velocity (m/s & km/h) with compass direction, barometric pressure, visibility range, cloud cover, precipitation rate, and solar daylight progress arc.
   - **Air Quality Index (AQI)**: 5-level Indian National AQI categorization with PM2.5, PM10, NO2, and O3 telemetry.
   - **24-Hour Atmospheric Forecast**: Horizontally scrollable strip showing 3-hour intervals with rain probabilities (`pop %`).
   - **5-Day Outlook**: Multi-day forecast with minimum/maximum temperature bars.

6. **Weather Analytics Charts**
   - Powered by Chart.js with glowing high-contrast curves:
     - 🌡️ **Temperature Curve**: 24-hour diurnal trend with feels-like overlay.
     - 🌧️ **Precipitation**: Rain probability (%) and estimated rainfall volume (mm).
     - 💨 **Wind Trends**: Surface wind speed patterns over 24 hours.

7. **Contextual Meteorological Guidance**
   - IMD-aligned factual advisories (Heatwave warnings, Monsoon rainfall alerts, AQI health guidance, Thunderstorm precautions, Fog transit alerts).

8. **Zero-Key Demo Scenario Lab**
   - Full functionality is available even without an API key!
   - Test realistic Indian meteorological phenomena: Monsoon, Kalbaisakhi Storm, Summer Heatwave, Winter Fog, Deccan Breeze, Himalayan Snow, plus Day/Night toggles.

---

## 🛠️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                       Client (Browser)                      │
│                                                             │
│   Dashboard UI  ◄──►  Interactive Map  ◄──►  Chart.js       │
│         │                    │                     │        │
│         └────────────┬───────┴─────────────────────┘        │
│                      │                                      │
│             EnvironmentController                           │
│                      │                                      │
│                      ▼                                      │
│           Three.js Procedural World                         │
└──────────────────────┬──────────────────────────────────────┘
                       │ /api/weather, /api/forecast, /api/cities
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                 Server (Node.js / Express)                  │
│                                                             │
│   • OPENWEATHER_API_KEY (stored safely in .env)             │
│   • Indian Territory Bounding & City Validation             │
│   • In-Memory TTL Caching & Request Deduplication           │
│   • Timeout & Rate-Limit Resiliency                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
         OpenWeather External API
```

---

## 🚀 Local Installation & Quick Start

### 1. Prerequisites
- **Node.js**: v18.0.0 or later (tested on Node v24).
- **npm**: v9.0.0 or later.

### 2. Clone or Extract Project
```bash
cd /Users/manum/Projects/skyshift
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Open `.env` in any editor:
```env
# Free API key from https://openweathermap.org/api
OPENWEATHER_API_KEY=your_actual_key_here

# Optional: defaults to 5173
PORT=5173
```

> **Note:** An API key is **optional** for exploring the website. If no key is set in `.env`, VARSHA starts seamlessly in **Demo Mode**, providing full simulation of Indian cities and weather systems.

### 5. Start Development Server
```bash
npm run dev
```

Open your browser at:
```
http://localhost:5173
```
*(If port 5173 is already occupied, Vite will automatically select `http://localhost:5174` or the next available port).*

---

## 🧪 Testing & Verification

Run the automated test suite:
```bash
npm test
```

This verifies:
1. Indian cities database integrity (70+ cities across all 28 states & 8 UTs).
2. Geolocation bounding box validation (inside vs. outside India).
3. Indian city search with prefix matching and case-insensitivity.
4. All 6 Indian weather presets and simulated forecast payloads.
5. 3D Atmospheric mapping rules (Monsoon, Storm, Heatwave, Fog, Snow, Night/Day).
6. AQI translation and contextual guidance generation.
7. IST local time formatting.

To run the production build check:
```bash
npm run build
```

---

## 📦 Production Deployment / Standalone Server

To run the production-built application with the standalone Express server:

```bash
# 1. Build optimized static assets
npm run build

# 2. Start standalone server
npm start
```

The application will start at `http://localhost:5173` (or the configured `PORT` in `.env`).

---

## 🔑 How to Obtain an OpenWeather API Key

1. Visit [OpenWeather Registration](https://home.openweathermap.org/users/sign_up) and create a free account.
2. Go to the **API keys** tab on your profile dashboard.
3. Copy your default key (or generate a new one).
4. Paste it into `.env`:
   ```env
   OPENWEATHER_API_KEY=your_openweathermap_key
   ```
5. Restart `npm run dev` or click **API Setup** in the top bar to verify the connection.

*Note: Newly created OpenWeather API keys can take 10–20 minutes to activate globally.*

---

## 📜 Available Scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Starts Vite development server with backend API middleware |
| `npm run build` | Compiles optimized production bundle into `dist/` |
| `npm run preview` | Previews the production build locally |
| `npm start` | Starts standalone Node.js Express server (`server.js`) |
| `npm test` | Runs the full integration test suite |
| `npm run check` | Runs atmospheric mapping assertions |

---

## 🛡️ License

Private project developed for India's Live Weather Intelligence.

---

## Netlify deployment (fixed)

The app needs a backend for `/api/*`. On Netlify this is provided by `netlify/functions/api.mjs` (wraps `server/apiRouter.js`).
Without it, Netlify returned `index.html` for `/api/*` and the browser failed with *"Unexpected token '<' … is not valid JSON"*.

1. Push the project to GitHub (do not commit `node_modules`, `.env`).
2. Netlify → Add new site → Import from Git. Settings are read from `netlify.toml` (build `npm run build`, publish `dist`).
3. Site configuration → Environment variables: add `OPENWEATHER_API_KEY` (optional: `WEATHER_CACHE_TTL_SECONDS`, default 300).
4. Deploy. Check `https://<site>/api/status` returns JSON with `"hasKey": true`.

Do NOT drag-and-drop only `dist` — that skips the function.

## Auto-refresh and demo mode
- Header dropdown sets auto-refresh (off / 5s / 15s / 60s / 5m) for live mode; it pauses when the tab is hidden.
- OpenWeather updates data only every few minutes and the server caches current weather for `WEATHER_CACHE_TTL_SECONDS` (default 300). For genuinely fresh data every 5 s set it to `5`, but mind your plan's call limits.
- "Demo: on" forces demo data regardless of API key; the **Edit demo data** row lets you set temperature, humidity, wind, pressure, clouds, visibility and condition, which drives the dashboard and 3D scene.

---

## District map, search and weather (integration notes)

- **Map:** the default tab is *India District Map* (Leaflet, existing library). Click a state → its districts load lazily from `/data/districts/<state>.json`; click a district (or pick one in the dropdown) → boundary highlighted and weather is fetched for its representative point. The 3D map tab is unchanged.
- **Why only a few districts appeared before:** the project shipped only 36 state polygons (`src/data/indiaStates.json`) and no district boundary data at all; `src/data/indiaGeographicDb.js` (a hand-written list) was never imported. District data now comes from `public/data` (see `DATA_SOURCES.md` for coverage, vintage and licence caveats).
- **Search:** states/UTs, 737 districts and 11,859 GeoNames cities/towns, debounced (200 ms), fully client-side (no geocoding requests). Duplicates show their state/district.
- **Live polling:** header dropdown (off / 5 s / 15 s / 60 s default / 5 min). One request at a time, aborted on location change, exponential backoff on errors, stale indicator after 3 missed intervals, "new data / unchanged" status. OpenWeather updates observations only every several minutes and the server caches current weather for `WEATHER_CACHE_TTL_SECONDS` (default 300), so shorter intervals mostly return unchanged cached data and consume function invocations. Forecast/air quality are re-fetched at most every 10 minutes.
- **Demo mode:** *Demo* button (or automatic when no key). Live polling is stopped and in-flight live requests are discarded; presets and manual values (temperature, humidity, wind, pressure, clouds, rain mm/h, fog %, condition, day/night) drive the dashboard and 3D scene immediately and persist until changed. Click the button again to return to live.
- **Security:** the previously hard-coded fallback OpenWeather key was removed from the client code. **That key was exposed in the original files — revoke/rotate it in your OpenWeather account.** Users may still paste their own key in *API Setup* (stored only in their browser; needed for radar overlay tiles).
- **Regenerate data:** `npm run build:data` (needs upstream per-state GeoJSON in `data-src/states/`).
- **Fixed:** `npm start` crashed on Express 5 (`app.get("*")`).
