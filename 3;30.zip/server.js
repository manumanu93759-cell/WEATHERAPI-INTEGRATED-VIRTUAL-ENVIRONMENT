import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { apiRouter } from "./server/apiRouter.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5173;

// Mount API router
app.use("/api", apiRouter);

// Serve static assets from built frontend
const distPath = path.join(__dirname, "dist");
app.use(express.static(distPath));

// Fallback to index.html for SPA routes
app.use((req, res) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "NOT_FOUND", message: "Unknown API route." });
  res.sendFile(path.join(distPath, "index.html"));
});

app.listen(PORT, () => {
  console.log(`\n==================================================`);
  console.log(`  VARSHA — India's Live Weather Intelligence`);
  console.log(`  Server running at: http://localhost:${PORT}`);
  console.log(`  OpenWeather API Key: ${process.env.OPENWEATHER_API_KEY ? "CONFIGURED (Live Mode ready)" : "NOT SET (Demo Mode ready)"}`);
  console.log(`==================================================\n`);
});
