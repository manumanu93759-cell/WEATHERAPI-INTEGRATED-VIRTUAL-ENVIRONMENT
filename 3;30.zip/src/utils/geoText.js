/** Name normalisation shared by the build script, search and matching logic. */
const STATE_ALIASES = {
  "orissa": "odisha", "uttaranchal": "uttarakhand", "pondicherry": "puducherry",
  "nct of delhi": "delhi", "delhi nct": "delhi", "new delhi": "delhi",
  "jammu kashmir": "jammu and kashmir", "j k": "jammu and kashmir",
  "andaman nicobar islands": "andaman and nicobar islands", "andaman nicobar": "andaman and nicobar islands", "andaman and nicobar": "andaman and nicobar islands",
  "dadra nagar haveli and daman diu": "dadra and nagar haveli and daman and diu",
  "dadra and nagar haveli": "dadra and nagar haveli and daman and diu", "daman and diu": "dadra and nagar haveli and daman and diu",
  "telengana": "telangana",
};
export function normalize(s) {
  return String(s ?? "")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
}
export function normalizeState(s) { const n = normalize(s); return STATE_ALIASES[n] || n; }
export function slugify(s) { return normalize(s).replace(/ /g, "-"); }
/** Canonical file slug for a state name (resolves aliases). */
export function stateSlug(s) { return slugify(normalizeState(s)); }
