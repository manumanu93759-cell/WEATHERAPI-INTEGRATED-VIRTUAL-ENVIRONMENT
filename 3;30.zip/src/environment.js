function clamp(value, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function weatherGroup(id) {
  if (id >= 200 && id < 300) return "thunderstorm";
  if (id >= 502 && id <= 504) return "monsoon"; // Heavy/extreme torrential rain
  if (id >= 300 && id < 600) return "rain";
  if (id >= 600 && id < 700) return "snow";
  if (id >= 700 && id < 800) return "atmosphere";
  if (id === 800) return "clear";
  if (id > 800 && id < 900) return "clouds";
  return "clear";
}

/**
 * Convert UTC unix timestamps into a 0–1 daylight factor using the city's
 * sunrise/sunset. Twilight is blended over ±45 minutes.
 */
export function computeSolarPhase(dt, sunrise, sunset) {
  if (![dt, sunrise, sunset].every(Number.isFinite)) {
    return { dayFactor: 0.85, phase: "day", label: "Solar time unavailable — defaulting to daytime lighting." };
  }

  const twilight = 45 * 60;
  if (dt < sunrise - twilight) {
    return { dayFactor: 0.04, phase: "night", label: "Local sunrise has not occurred. Night starlight active." };
  }
  if (dt < sunrise + twilight) {
    const t = clamp((dt - (sunrise - twilight)) / (twilight * 2));
    return { dayFactor: t, phase: "dawn", label: "Dawn transition near sunrise. Golden morning light expanding." };
  }
  if (dt < sunset - twilight) {
    return { dayFactor: 1, phase: "day", label: "Daytime solar cycle. Direct sunlight active across the subcontinent." };
  }
  if (dt < sunset + twilight) {
    const t = clamp((dt - (sunset - twilight)) / (twilight * 2));
    return {
      dayFactor: 1 - t,
      phase: "dusk",
      label: "Dusk transition near sunset. Twilight blending into evening darkness.",
    };
  }
  return { dayFactor: 0.04, phase: "night", label: "Post-sunset night phase. Lunar and starlight lighting active." };
}

export function defaultEnvironmentState() {
  return {
    dayFactor: 1,
    sunIntensity: 1.6,
    ambientIntensity: 0.7,
    cloudDensity: 0.18,
    rainIntensity: 0,
    snowIntensity: 0,
    fogDensity: 0.012,
    storminess: 0,
    wetness: 0,
    windSpeed: 3,
    windDeg: 90,
    starVisibility: 0,
    exposure: 1.05,
    fogFar: 420,
    terrainDarken: 0,
    temperatureAccent: 0.5,
    isMonsoon: 0,
  };
}

export function mapWeatherToEnvironment(weather) {
  let group = weatherGroup(weather.weatherId);
  if (weather.presetId === "monsoon") {
    group = "monsoon";
  } else if (group === "rain" && weather.rain1h && weather.rain1h > 12) {
    group = "monsoon";
  }

  const solar = computeSolarPhase(weather.dt, weather.sunrise, weather.sunset);
  const clouds = clamp(asNumber(weather.clouds, 0) / 100);
  const visibility = clamp(asNumber(weather.visibility, 10000) / 10000);
  const windSpeed = Math.max(0, asNumber(weather.windSpeed, 0));
  const temp = asNumber(weather.temp, 22);

  const isMonsoon = group === "monsoon" ? 1 : 0;
  const isStorm = group === "thunderstorm" ? 1 : 0;
  const isRain = group === "rain" || isMonsoon || isStorm ? (isMonsoon ? 1.0 : isStorm ? 0.95 : 0.7) : 0;
  const isSnow = group === "snow" ? 0.9 : temp < 0 && isRain > 0 ? 0.4 : 0;
  const isMist = group === "atmosphere" ? 1 : 0;

  const fogFromVis = 0.008 + (1 - visibility) * 0.08;
  const fogFromMist = isMist * 0.07;
  const fogFromRain = isRain * 0.022;
  const fogDensity = clamp(fogFromVis + fogFromMist + fogFromRain, 0.006, 0.12);

  const cloudDensity = clamp(
    Math.max(clouds, isRain * 0.65, isMonsoon * 0.95, isStorm * 0.95, isSnow * 0.5, group === "clear" ? 0.08 : 0)
  );
  const day = solar.dayFactor;
  const overcast = clamp(clouds * 0.7 + isStorm * 0.4 + isMonsoon * 0.45 + isMist * 0.2);
  const sunIntensity = (0.55 + day * 1.35) * (1 - overcast * 0.6);
  const ambientIntensity = 0.42 + day * 0.38 + overcast * 0.08 + (1 - day) * 0.08;
  const starVisibility = clamp((1 - day) * (1 - cloudDensity * 0.7));
  const wetness = clamp(isRain * 0.88 + isMonsoon * 0.98 + isStorm * 0.4);
  const fogFar = 140 + visibility * 340 - isMist * 80;
  const terrainDarken = clamp(isRain * 0.35 + isMonsoon * 0.45 + isStorm * 0.4 + (1 - day) * 0.2);
  const temperatureAccent = clamp((temp + 5) / 45);

  return {
    dayFactor: day,
    sunIntensity,
    ambientIntensity,
    cloudDensity,
    rainIntensity: isSnow > 0.4 ? 0 : isRain,
    snowIntensity: isSnow,
    fogDensity,
    storminess: isStorm,
    wetness,
    windSpeed,
    windDeg: asNumber(weather.windDeg, 0),
    starVisibility,
    exposure: 0.95 + day * 0.28 - isStorm * 0.12 - isMonsoon * 0.08,
    fogFar: Math.max(90, fogFar),
    terrainDarken,
    temperatureAccent,
    isMonsoon,
    phase: solar.phase,
    group,
    solarLabel: solar.label,
  };
}

export function explainEnvironment(weather, env) {
  const notes = [];
  const group = env.group;

  notes.push(env.solarLabel);

  if (group === "monsoon") {
    notes.push("Indian Southwest Monsoon conditions active. Dense convective cloud layers, sustained tropical precipitation, and wet saturated terrain are simulated.");
  } else if (group === "clear") {
    if (weather.temp >= 38) {
      notes.push(`High summer temperature recorded (${Math.round(weather.temp)}°C). Warm golden solar irradiance and minimal cloud attenuation.`);
    } else {
      notes.push("Clear sky reported across the region. Direct sunlight and unobstructed visual horizon.");
    }
  } else if (group === "clouds") {
    notes.push(`Cloud cover is ${Math.round(asNumber(weather.clouds, 0))}%. Diffuse lighting with soft sky luminance.`);
  } else if (group === "rain") {
    notes.push("Precipitation reported by telemetry sensors. Droplet particle streams and wet terrain shaders are engaged.");
  } else if (group === "thunderstorm") {
    notes.push("Thunderstorm cell active. Convective storm clouds, heavy rainfall, and dynamic lightning flashes enabled.");
  } else if (group === "snow") {
    notes.push("Himalayan snowfall conditions active. Cooler lighting, snow particles, and frosty ambient accents enabled.");
  } else if (group === "atmosphere") {
    notes.push("Atmospheric fog/mist reported. Atmospheric particulate scattering has reduced visual range.");
  }

  if (asNumber(weather.visibility, 10000) < 5000) {
    notes.push(
      `Visibility is ${(asNumber(weather.visibility, 0) / 1000).toFixed(1)} km. Fog density increased accordingly.`
    );
  }
  if (asNumber(weather.windSpeed, 0) >= 6) {
    notes.push(
      `Surface wind is ${asNumber(weather.windSpeed, 0).toFixed(1)} m/s (${(asNumber(weather.windSpeed, 0) * 3.6).toFixed(0)} km/h). Cloud and rain vectors drift with this velocity.`
    );
  }

  notes.push("Procedural 3D world reflects actual atmospheric parameters.");
  return notes;
}

export function activeEffects(env) {
  const chips = [];
  if (env.dayFactor > 0.55) chips.push("Daylight");
  else if (env.dayFactor > 0.2) chips.push("Twilight");
  else chips.push("Night");

  if (env.isMonsoon > 0.5) chips.push("Monsoon Deluge");
  if (env.cloudDensity > 0.45) chips.push("Dense Clouds");
  if (env.rainIntensity > 0.15) chips.push("Rainfall");
  if (env.snowIntensity > 0.15) chips.push("Snowfall");
  if (env.storminess > 0.4) chips.push("Lightning");
  if (env.fogDensity > 0.03) chips.push("Atmospheric Fog");
  if (env.wetness > 0.2) chips.push("Wet Terrain");
  if (env.starVisibility > 0.25) chips.push("Constellations");
  if (env.windSpeed > 6) chips.push("Gusty Wind");
  if (env.temperatureAccent > 0.8) chips.push("Heatwave");
  return chips;
}

export class EnvironmentController {
  constructor() {
    this.current = defaultEnvironmentState();
    this.target = defaultEnvironmentState();
    this.explanations = [];
    this.group = "clear";
    this.phase = "day";
    this.reducedMotion = false;

    if (typeof window !== "undefined" && window.matchMedia) {
      const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      this.reducedMotion = mq.matches;
      mq.addEventListener?.("change", (e) => {
        this.reducedMotion = e.matches;
      });
    }
  }

  applyWeather(weather, { snap = false } = {}) {
    const mapped = mapWeatherToEnvironment(weather);
    this.target = mapped;
    this.group = mapped.group;
    this.phase = mapped.phase;
    this.explanations = explainEnvironment(weather, mapped);

    if (snap || this.reducedMotion) {
      const current = defaultEnvironmentState();
      for (const key of Object.keys(current)) {
        if (typeof mapped[key] === "number") current[key] = mapped[key];
      }
      this.current = current;
    }
  }

  tick(dtSeconds) {
    const rate = this.reducedMotion ? 10 : 1.8;
    const t = 1 - Math.exp(-dtSeconds * rate);
    const keys = [
      "dayFactor",
      "sunIntensity",
      "ambientIntensity",
      "cloudDensity",
      "rainIntensity",
      "snowIntensity",
      "fogDensity",
      "storminess",
      "wetness",
      "windSpeed",
      "windDeg",
      "starVisibility",
      "exposure",
      "fogFar",
      "terrainDarken",
      "temperatureAccent",
      "isMonsoon",
    ];
    for (const key of keys) {
      this.current[key] = lerp(this.current[key], this.target[key], t);
    }
  }
}

function asNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
