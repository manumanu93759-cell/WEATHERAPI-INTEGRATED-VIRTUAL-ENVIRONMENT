import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

/**
 * Atmosphere3DWorld — Cinematic 3D Indian Environmental Simulation
 * 
 * Features:
 * - Towering fractal Himalayan mountain range with glaciated peaks
 * - Rolling fertile Indo-Gangetic plains & Deccan basalt crags
 * - Dynamic sacred meandering river with wave interference & specular sun glints
 * - Rayleigh/Mie atmospheric scattering sky with smooth Day/Dawn/Dusk/Night transitions
 * - Volumetric drifting cloud clusters responsive to wind speed and direction
 * - Wind-responsive instanced vegetation (Himalayan pines & tropical valley trees)
 * - Multi-layer monsoon rainfall, thunderstorm lightning flashes, and valley fog
 * - Multiple cinematic camera perspectives (Cinematic Drone, Himalayan Vista, Riverbank, Satellite)
 */

const PINE_COUNT = 180;
const TROPICAL_TREE_COUNT = 220;
const RAIN_COUNT = 5000;
const SNOW_COUNT = 3200;
const STAR_COUNT = 2200;
const CLOUD_COUNT = 48;

// Procedural Terrain Noise
function hash(x, y) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

function noise(x, y) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const n00 = hash(xi, yi);
  const n10 = hash(xi + 1, yi);
  const n01 = hash(xi, yi + 1);
  const n11 = hash(xi + 1, yi + 1);
  return THREE.MathUtils.lerp(
    THREE.MathUtils.lerp(n00, n10, u),
    THREE.MathUtils.lerp(n01, n11, u),
    v
  );
}

function fbm(x, y) {
  let val = 0;
  let amp = 0.52;
  let freq = 1.0;
  for (let i = 0; i < 5; i++) {
    val += amp * noise(x * freq, y * freq);
    amp *= 0.48;
    freq *= 2.05;
  }
  return val;
}

/**
 * Geographic elevation function for Indian Subcontinent:
 * - North (z < -10): Towering Himalayan Massif
 * - Center (-15 <= z <= 30): Rolling Indo-Gangetic Plains & river channel
 * - South (z > 30): Deccan basalt plateau
 */
function getTerrainElevation(x, z) {
  const dist = Math.hypot(x, z) / 140;
  const edgeMask = THREE.MathUtils.smoothstep(1.3, 0.2, dist);

  // 1. Himalayan Massif (z < -5)
  const himalayaFactor = THREE.MathUtils.smoothstep(12, -75, z);
  const mountainFractal = Math.pow(fbm(x * 0.02 + 8, z * 0.02), 1.35) * 44 * himalayaFactor;
  const sharpRidges = Math.abs(noise(x * 0.035, z * 0.035) - 0.5) * 18 * himalayaFactor;

  // 2. Southern Deccan Plateau Tablelands (z > 20)
  const deccanFactor = THREE.MathUtils.smoothstep(-5, 60, z);
  const deccanMesa = (fbm(x * 0.03 + 30, z * 0.03) * 10 + 4) * deccanFactor;

  // 3. Central Gangetic Plains Rolling Knolls
  const plainsHills = fbm(x * 0.038 + 15, z * 0.038) * 5.2;
  const microDetail = fbm(x * 0.12, z * 0.12) * 1.4;

  // 4. Sacred Meandering River Channel
  const riverCurve = Math.sin(z * 0.065) * 26 + Math.cos(z * 0.028) * 10;
  const distToRiver = Math.abs(x - riverCurve);
  const riverTrench = THREE.MathUtils.smoothstep(14, 1.2, distToRiver) * 5.8;

  let y = (mountainFractal + sharpRidges + deccanMesa + plainsHills + microDetail + 3.8 - riverTrench) * edgeMask;
  if (edgeMask > 0.3) {
    y = Math.max(y, 0.8);
  }
  return y;
}

export function createWeatherWorld(canvasElement) {
  const canvas = canvasElement;
  let renderer = null;
  let scene = null;
  let camera = null;
  let controls = null;
  let animId = null;

  // Environment state (lerped)
  const currentEnv = {
    dayFactor: 1.0,
    sunIntensity: 1.8,
    ambientIntensity: 0.8,
    cloudDensity: 0.25,
    rainIntensity: 0.0,
    snowIntensity: 0.0,
    fogDensity: 0.008,
    storminess: 0.0,
    wetness: 0.0,
    windSpeed: 3.5,
    windDeg: 210,
    temperatureAccent: 0.5,
    isMonsoon: 0.0,
    exposure: 1.1,
    terrainDarken: 0,
    starVisibility: 0,
    fogFar: 420,
  };

  const targetEnv = { ...currentEnv };

  // Lighting References
  let sunLight = null;
  let ambientLight = null;
  let skyMesh = null;
  let terrainMesh = null;
  let waterMesh = null;
  let pineInstanced = null;
  let tropicalInstanced = null;
  let cloudsGroup = null;
  let rainSystem = null;
  let snowSystem = null;
  let starsSystem = null;
  let lightningLight = null;
  let lightningFlashTimer = 0;
  let boltLife = 0;
  let boltLines = null;
  let frameNo = 0;
  let visibleInView = true;

  // Tree matrices
  const pineTransforms = [];
  const tropicalTransforms = [];

  // Clock
  const clock = new THREE.Clock();
  let isRunning = true;
  let activeCameraPreset = "cinematic";

  // Setup Three.js
  const width = canvas.clientWidth || 800;
  const height = canvas.clientHeight || 500;

  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x87ceeb, 0.008);

  camera = new THREE.PerspectiveCamera(46, width / height, 0.2, 800);
  camera.position.set(0, 18, 52);

  controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.maxPolarAngle = Math.PI / 2.02; // Prevent going underneath terrain
  controls.minDistance = 6;
  controls.maxDistance = 160;
  controls.target.set(0, 5, 0);

  // 1. Celestial Atmospheric Sky Dome
  const skyGeom = new THREE.SphereGeometry(380, 32, 24);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: {
      uZenith: { value: new THREE.Color(0x1e3a8a) },
      uHorizon: { value: new THREE.Color(0x93c5fd) },
      uNadir: { value: new THREE.Color(0x0f172a) },
      uDay: { value: 1.0 },
      uSunDir: { value: new THREE.Vector3(0.4, 0.7, 0.5).normalize() },
      uSunVis: { value: 1.0 },
      uFlash: { value: 0.0 },
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPos.xyz;
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,
    fragmentShader: `
      varying vec3 vWorldPosition;
      uniform vec3 uZenith;
      uniform vec3 uHorizon;
      uniform vec3 uNadir;
      uniform float uDay;
      uniform vec3 uSunDir;
      uniform float uSunVis;
      uniform float uFlash;
      void main() {
        vec3 dir = normalize(vWorldPosition);
        float h = dir.y;
        vec3 col = mix(uHorizon, uZenith, smoothstep(-0.02, 0.65, h));
        col = mix(uNadir, col, smoothstep(-0.4, -0.02, h));
        float sd = max(dot(dir, normalize(uSunDir)), 0.0);
        col += vec3(1.0, 0.86, 0.6) * pow(sd, 6.0) * 0.28 * uSunVis;
        col += vec3(1.0, 0.95, 0.85) * pow(sd, 160.0) * 1.6 * uSunVis;
        col += vec3(0.75, 0.82, 1.0) * uFlash * (0.35 + 0.65 * (1.0 - clamp(h, 0.0, 1.0)));
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  skyMesh = new THREE.Mesh(skyGeom, skyMat);
  scene.add(skyMesh);

  // 2. Sun & Moon Lights
  sunLight = new THREE.DirectionalLight(0xfff7ed, 1.8);
  sunLight.position.set(40, 60, 40);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.width = 1024;
  sunLight.shadow.mapSize.height = 1024;
  sunLight.shadow.bias = -0.0006;
  sunLight.shadow.camera.near = 1;
  sunLight.shadow.camera.far = 180;
  sunLight.shadow.camera.left = -55;
  sunLight.shadow.camera.right = 55;
  sunLight.shadow.camera.top = 55;
  sunLight.shadow.camera.bottom = -55;
  scene.add(sunLight);

  ambientLight = new THREE.AmbientLight(0x64748b, 0.8);
  scene.add(ambientLight);

  // Lightning PointLight (for Kalbaisakhi thunderstorms)
  lightningLight = new THREE.PointLight(0xa5f3fc, 0, 220);
  lightningLight.position.set(0, 45, -20);
  scene.add(lightningLight);

  // 3. Procedural Indian Subcontinent Terrain
  const terrainRes = 140;
  const terrainSize = 240;
  const terrainGeom = new THREE.PlaneGeometry(terrainSize, terrainSize, terrainRes, terrainRes);
  terrainGeom.rotateX(-Math.PI / 2);

  const posAttr = terrainGeom.attributes.position;
  const colors = new Float32Array(posAttr.count * 3);

  // Palette colors
  const colSnow = new THREE.Color(0xf1f5f9);
  const colRock = new THREE.Color(0x334155);
  const colAlpineSlate = new THREE.Color(0x475569);
  const colPlainsLush = new THREE.Color(0x15803d);
  const colPlainsDry = new THREE.Color(0x65a30d);
  const colSand = new THREE.Color(0xb45309);
  const colBasalt = new THREE.Color(0x1e293b);

  const validTreePositions = [];

  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const z = posAttr.getZ(i);
    const y = getTerrainElevation(x, z);
    posAttr.setY(i, y);

    // Color computation based on elevation, slope, and latitude
    let vertexCol = colPlainsLush.clone();

    if (y > 22) {
      // High Himalayan Snow Caps
      const snowFactor = THREE.MathUtils.smoothstep(22, 34, y);
      vertexCol.lerp(colSnow, snowFactor);
    } else if (y > 14) {
      // Rocky Alpine Slopes
      vertexCol.lerp(colAlpineSlate, THREE.MathUtils.smoothstep(14, 22, y));
    } else if (z > 25 && y > 5) {
      // Deccan Plateau Basalt
      vertexCol.lerp(colBasalt, 0.65);
    } else if (y < 2.5) {
      // Riverbed Sandy Loam
      vertexCol.lerp(colSand, THREE.MathUtils.smoothstep(2.5, 1.2, y));
    } else {
      // Lush Plains
      const moisture = noise(x * 0.05, z * 0.05);
      vertexCol.lerp(colPlainsDry, moisture * 0.4);
    }

    colors[i * 3] = vertexCol.r;
    colors[i * 3 + 1] = vertexCol.g;
    colors[i * 3 + 2] = vertexCol.b;

    // Collect valid tree spots (not in river water, not on sheer snow peak)
    if (y > 3.2 && y < 20 && Math.random() < 0.28) {
      validTreePositions.push({ x, y, z });
    }
  }

  terrainGeom.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  terrainGeom.computeVertexNormals();

  const terrainMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.75,
    metalness: 0.15,
    flatShading: false,
  });

  const terrainU = { uSnow: { value: 0 }, uWet: { value: 0 } };
  terrainMat.onBeforeCompile = (sh) => {
    sh.uniforms.uSnow = terrainU.uSnow;
    sh.uniforms.uWet = terrainU.uWet;
    sh.vertexShader = sh.vertexShader
      .replace("#include <common>", "#include <common>\nvarying float vUp;")
      .replace("#include <begin_vertex>", "#include <begin_vertex>\nvUp = normal.y;");
    sh.fragmentShader = sh.fragmentShader
      .replace("#include <common>", "#include <common>\nvarying float vUp;\nuniform float uSnow;\nuniform float uWet;")
      .replace("#include <color_fragment>", `#include <color_fragment>
        float snowMask = smoothstep(0.55, 0.9, vUp) * uSnow;
        diffuseColor.rgb = mix(diffuseColor.rgb * (1.0 - uWet * 0.38), vec3(0.93, 0.96, 1.0), snowMask);`)
      .replace("#include <roughnessmap_fragment>", `#include <roughnessmap_fragment>
        roughnessFactor = mix(roughnessFactor, 0.35, uWet * 0.7);`);
  };

  terrainMesh = new THREE.Mesh(terrainGeom, terrainMat);
  terrainMesh.receiveShadow = true;
  terrainMesh.castShadow = true;
  scene.add(terrainMesh);

  // 4. Reflective Sacred River / Lake Mesh
  const waterGeom = new THREE.PlaneGeometry(240, 240, 72, 72);
  waterGeom.rotateX(-Math.PI / 2);

  const waterMat = new THREE.ShaderMaterial({
    transparent: true,
    uniforms: {
      uTime: { value: 0 },
      uWind: { value: 3.5 },
      uDeepColor: { value: new THREE.Color(0x042f2e) },
      uShallowColor: { value: new THREE.Color(0x0d9488) },
      uSunDir: { value: new THREE.Vector3(0.5, 0.8, 0.3).normalize() },
      uDay: { value: 1.0 },
    },
    vertexShader: `
      uniform float uTime;
      uniform float uWind;
      varying vec3 vWorldPos;
      varying vec3 vNormal;
      void main() {
        vec3 p = position;
        float w1 = sin(p.x * 0.08 + uTime * 1.6) * 0.22;
        float w2 = cos(p.z * 0.06 + uTime * 1.2) * 0.18;
        float w3 = sin((p.x + p.z) * 0.12 + uTime * (0.8 + uWind * 0.08)) * 0.14;
        p.y += w1 + w2 + w3;
        vWorldPos = (modelMatrix * vec4(p, 1.0)).xyz;
        vNormal = normalize(vec3(-w1 * 0.5, 1.0, -w2 * 0.5));
        gl_Position = projectionMatrix * viewMatrix * vec4(vWorldPos, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uDeepColor;
      uniform vec3 uShallowColor;
      uniform vec3 uSunDir;
      uniform float uDay;
      varying vec3 vWorldPos;
      varying vec3 vNormal;
      void main() {
        vec3 viewDir = normalize(cameraPosition - vWorldPos);
        float fresnel = pow(1.0 - max(0.0, dot(viewDir, vNormal)), 3.0);
        vec3 waterCol = mix(uDeepColor, uShallowColor, fresnel * 0.6);
        // Specular glint from sun
        vec3 halfDir = normalize(uSunDir + viewDir);
        float spec = pow(max(0.0, dot(vNormal, halfDir)), 64.0) * uDay * 1.5;
        waterCol += vec3(0.95, 0.98, 1.0) * spec;
        gl_FragColor = vec4(waterCol, 0.88);
      }
    `,
  });

  waterMesh = new THREE.Mesh(waterGeom, waterMat);
  waterMesh.position.y = 1.95; // River water level
  scene.add(waterMesh);

  // 5. Living Wind-Responsive Vegetation
  // A. Himalayan Pines (Alpine conifer cones)
  const pineGeom = new THREE.ConeGeometry(0.85, 3.2, 6);
  pineGeom.translate(0, 1.6, 0);
  const pineMat = new THREE.MeshStandardMaterial({
    color: 0x064e3b,
    roughness: 0.8,
    metalness: 0.1,
    flatShading: true,
  });
  pineInstanced = new THREE.InstancedMesh(pineGeom, pineMat, PINE_COUNT);
  pineInstanced.castShadow = true;
  pineInstanced.receiveShadow = true;

  // B. Tropical Valley Trees (Banyan / Deciduous crowns)
  const tropicalGeom = new THREE.DodecahedronGeometry(1.4, 1);
  tropicalGeom.translate(0, 1.8, 0);
  const tropicalMat = new THREE.MeshStandardMaterial({
    color: 0x15803d,
    roughness: 0.75,
    metalness: 0.1,
    flatShading: true,
  });
  tropicalInstanced = new THREE.InstancedMesh(tropicalGeom, tropicalMat, TROPICAL_TREE_COUNT);
  tropicalInstanced.castShadow = true;
  tropicalInstanced.receiveShadow = true;

  // Place trees according to ecology
  const dummy = new THREE.Object3D();
  let pineIdx = 0;
  let tropIdx = 0;

  for (const pos of validTreePositions) {
    if (pos.y > 9 && pineIdx < PINE_COUNT) {
      // High slope = Pine
      const s = Math.random() * 0.5 + 0.85;
      dummy.position.set(pos.x, pos.y, pos.z);
      dummy.scale.set(s, s * 1.2, s);
      dummy.rotation.y = Math.random() * Math.PI * 2;
      dummy.updateMatrix();
      pineInstanced.setMatrixAt(pineIdx, dummy.matrix);
      pineTransforms.push({
        basePos: dummy.position.clone(),
        baseScale: dummy.scale.clone(),
        baseRot: dummy.rotation.clone(),
        phase: Math.random() * Math.PI * 2,
      });
      pineIdx++;
    } else if (pos.y <= 9 && tropIdx < TROPICAL_TREE_COUNT) {
      // Low plains = Tropical
      const s = Math.random() * 0.6 + 0.9;
      dummy.position.set(pos.x, pos.y, pos.z);
      dummy.scale.set(s, s, s);
      dummy.rotation.y = Math.random() * Math.PI * 2;
      dummy.updateMatrix();
      tropicalInstanced.setMatrixAt(tropIdx, dummy.matrix);
      tropicalTransforms.push({
        basePos: dummy.position.clone(),
        baseScale: dummy.scale.clone(),
        baseRot: dummy.rotation.clone(),
        phase: Math.random() * Math.PI * 2,
      });
      tropIdx++;
    }
  }

  pineInstanced.instanceMatrix.needsUpdate = true;
  tropicalInstanced.instanceMatrix.needsUpdate = true;
  scene.add(pineInstanced);
  scene.add(tropicalInstanced);

  // 6. Volumetric Drifting Clouds Canopy
  cloudsGroup = new THREE.Group();
  const cloudMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.95,
    metalness: 0.05,
    transparent: true,
    opacity: 0.85,
    flatShading: true,
  });

  for (let i = 0; i < CLOUD_COUNT; i++) {
    const cloudCluster = new THREE.Group();
    const puffs = Math.floor(Math.random() * 5) + 4;
    for (let p = 0; p < puffs; p++) {
      const r = Math.random() * 4.5 + 3.0;
      const puffGeom = new THREE.DodecahedronGeometry(r, 1);
      const puffMesh = new THREE.Mesh(puffGeom, cloudMat);
      puffMesh.position.set(
        (Math.random() - 0.5) * 12,
        (Math.random() - 0.5) * 3,
        (Math.random() - 0.5) * 10
      );
      cloudCluster.add(puffMesh);
    }

    cloudCluster.position.set(
      (Math.random() - 0.5) * 200,
      Math.random() * 18 + 26,
      (Math.random() - 0.5) * 200
    );
    cloudCluster.userData = {
      driftSpeed: Math.random() * 0.08 + 0.04,
      baseY: cloudCluster.position.y,
    };
    cloudsGroup.add(cloudCluster);
  }
  scene.add(cloudsGroup);

  // 7. Rain streaks (LineSegments; draw range scales with intensity)
  const rainGeom = new THREE.BufferGeometry();
  const rainPositions = new Float32Array(RAIN_COUNT * 6);
  const rainHeads = new Float32Array(RAIN_COUNT * 3);
  const rainVelocities = new Float32Array(RAIN_COUNT);

  for (let i = 0; i < RAIN_COUNT; i++) {
    rainHeads[i * 3] = (Math.random() - 0.5) * 160;
    rainHeads[i * 3 + 1] = Math.random() * 55 + 1;
    rainHeads[i * 3 + 2] = (Math.random() - 0.5) * 160;
    rainVelocities[i] = Math.random() * 0.8 + 0.9;
  }
  rainGeom.setAttribute("position", new THREE.BufferAttribute(rainPositions, 3));
  const rainMat = new THREE.LineBasicMaterial({
    color: 0xb6d4f5,
    transparent: true,
    opacity: 0.45,
    depthWrite: false,
  });
  rainSystem = new THREE.LineSegments(rainGeom, rainMat);
  rainSystem.frustumCulled = false;
  rainSystem.visible = false;
  scene.add(rainSystem);

  // 7b. Lightning bolt (main channel + branch, regenerated per strike)
  const BOLT_PTS = 22;
  boltLines = [0, 1].map(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(BOLT_PTS * 3), 3));
    const m = new THREE.LineBasicMaterial({ color: 0xe8f1ff, transparent: true, opacity: 0, fog: false, depthWrite: false });
    const l = new THREE.Line(g, m);
    l.frustumCulled = false;
    l.visible = false;
    scene.add(l);
    return l;
  });
  const _fwd = new THREE.Vector3();
  const _right = new THREE.Vector3();
  function strikeBolt() {
    camera.getWorldDirection(_fwd);
    _fwd.y = 0;
    if (_fwd.lengthSq() < 1e-4) _fwd.set(0, 0, -1);
    _fwd.normalize();
    _right.set(-_fwd.z, 0, _fwd.x);
    const dist = 55 + Math.random() * 40;
    const side = (Math.random() - 0.5) * dist * 0.9;
    const bx = camera.position.x + _fwd.x * dist + _right.x * side;
    const bz = camera.position.z + _fwd.z * dist + _right.z * side;
    const topY = 62;
    const botY = 3;
    const fill = (line, x0, y0, z0, y1, jag) => {
      const a = line.geometry.attributes.position.array;
      let x = x0, z = z0;
      for (let k = 0; k < BOLT_PTS; k++) {
        const t = k / (BOLT_PTS - 1);
        a[k * 3] = x;
        a[k * 3 + 1] = y0 + (y1 - y0) * t;
        a[k * 3 + 2] = z;
        x += (Math.random() - 0.5) * jag;
        z += (Math.random() - 0.5) * jag * 0.6;
      }
      line.geometry.attributes.position.needsUpdate = true;
      line.visible = true;
    };
    fill(boltLines[0], bx, topY, bz, botY, 7);
    const mid = Math.floor(BOLT_PTS * (0.35 + Math.random() * 0.2));
    const ma = boltLines[0].geometry.attributes.position.array;
    fill(boltLines[1], ma[mid * 3], ma[mid * 3 + 1], ma[mid * 3 + 2], botY + 18, 9);
    boltLife = 1;
    lightningLight.position.set(bx, 40, bz);
    lightningLight.intensity = 14 + Math.random() * 8;
  }

  // 8. Himalayan Snow Flurries
  const snowGeom = new THREE.BufferGeometry();
  const snowPositions = new Float32Array(SNOW_COUNT * 3);
  const snowDrift = new Float32Array(SNOW_COUNT);

  for (let i = 0; i < SNOW_COUNT; i++) {
    snowPositions[i * 3] = (Math.random() - 0.5) * 160;
    snowPositions[i * 3 + 1] = Math.random() * 50;
    snowPositions[i * 3 + 2] = (Math.random() - 0.5) * 160;
    snowDrift[i] = Math.random() * 0.2 + 0.12;
  }
  snowGeom.setAttribute("position", new THREE.BufferAttribute(snowPositions, 3));
  const snowMat = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.22,
    transparent: true,
    opacity: 0.8,
  });
  snowSystem = new THREE.Points(snowGeom, snowMat);
  snowSystem.visible = false;
  scene.add(snowSystem);

  // 9. Midnight Starlight Canopy
  const starGeom = new THREE.BufferGeometry();
  const starPositions = new Float32Array(STAR_COUNT * 3);
  for (let i = 0; i < STAR_COUNT; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 0.95);
    const radius = 370;
    starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    starPositions[i * 3 + 1] = radius * Math.cos(phi);
    starPositions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
  }
  starGeom.setAttribute("position", new THREE.BufferAttribute(starPositions, 3));
  const starMat = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.65,
    transparent: true,
    opacity: 0.0,
  });
  starsSystem = new THREE.Points(starGeom, starMat);
  scene.add(starsSystem);

  // Camera animation lerp target
  const camAnim = {
    pos: new THREE.Vector3(0, 18, 52),
    look: new THREE.Vector3(0, 5, 0),
    alpha: 1,
  };

  function setCameraPreset(preset) {
    activeCameraPreset = preset;
    camAnim.alpha = 0;

    if (preset === "cinematic") {
      camAnim.pos.set(0, 22, 54);
      camAnim.look.set(0, 5, 0);
    } else if (preset === "himalaya") {
      // Perched on mountain ridge looking out over the plains
      camAnim.pos.set(15, 38, -48);
      camAnim.look.set(0, 8, 10);
    } else if (preset === "riverbank") {
      // Serene ground perspective watching the river
      camAnim.pos.set(18, 3.8, 12);
      camAnim.look.set(-5, 4.2, -18);
    } else if (preset === "satellite") {
      // High-altitude atmospheric overview
      camAnim.pos.set(0, 88, 10);
      camAnim.look.set(0, 0, 0);
    } else if (preset === "horizon") {
      camAnim.pos.set(-30, 12, 40);
      camAnim.look.set(10, 8, -20);
    }
  }

  function applyWeatherState(state) {
    if (!state) return;
    Object.assign(targetEnv, state);
  }

  function resize() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (w === 0 || h === 0) return;

    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }

  const C = {
    zenDay: new THREE.Color(0x1e3a8a), zenNight: new THREE.Color(0x020617),
    horDay: new THREE.Color(0x93c5fd), horSunset: new THREE.Color(0xf97316), horNight: new THREE.Color(0x0f172a),
    storm: new THREE.Color(0x334155), fogGrey: new THREE.Color(0xaeb7c2), snowGrey: new THREE.Color(0xc9d3de),
    cloudWhite: new THREE.Color(0xf8fafc), cloudDark: new THREE.Color(0x334155),
    zen: new THREE.Color(), hor: new THREE.Color(),
  };
  const dummyObj = new THREE.Object3D();

  function renderLoop() {
    if (!isRunning) { animId = null; return; }
    animId = requestAnimationFrame(renderLoop);

    const delta = Math.min(clock.getDelta(), 0.1);
    const time = clock.getElapsedTime();
    frameNo++;
    // Skip all work while the tab is hidden or the 3D view is not on screen.
    if (document.hidden || !visibleInView || canvas.clientWidth === 0) return;
    const f60 = delta * 60;

    // 1. Smoothly interpolate environment parameters
    const lerpRate = Math.min(1.0, delta * 2.2);
    for (const key of Object.keys(targetEnv)) {
      currentEnv[key] = THREE.MathUtils.lerp(currentEnv[key], targetEnv[key], lerpRate);
    }

    // 2. Camera Fly-to
    if (camAnim.alpha < 1) {
      camAnim.alpha += delta * 1.5;
      const t = Math.min(1, camAnim.alpha);
      const ease = t * t * (3 - 2 * t);
      camera.position.lerp(camAnim.pos, ease * 0.12);
      controls.target.lerp(camAnim.look, ease * 0.12);
    }

    // 3. Cinematic Drone Drift (if cinematic preset active)
    if (activeCameraPreset === "cinematic" && camAnim.alpha >= 1) {
      const droneRadius = 56;
      const droneSpeed = 0.045;
      camera.position.x = Math.sin(time * droneSpeed) * droneRadius;
      camera.position.z = Math.cos(time * droneSpeed) * (droneRadius * 0.9);
      camera.position.y = 20 + Math.sin(time * 0.08) * 4;
      controls.target.set(0, 5 + Math.sin(time * 0.06) * 2, 0);
    }

    // 4. Update Solar Cycle & Celestial Sky
    const day = currentEnv.dayFactor;
    skyMat.uniforms.uDay.value = day;
    waterMat.uniforms.uDay.value = day;

    // Day / Night / Golden hour sky palette (no per-frame allocations)
    const curZenith = C.zen.copy(C.zenNight).lerp(C.zenDay, day);
    const curHorizon = C.hor;
    if (day > 0.4) curHorizon.copy(C.horSunset).lerp(C.horDay, Math.min(1, (day - 0.4) / 0.3));
    else curHorizon.copy(C.horNight).lerp(C.horSunset, day / 0.4);

    // Overcast / storm / snow / fog desaturate the sky toward grey
    const overcast = Math.max(currentEnv.cloudDensity, currentEnv.rainIntensity, currentEnv.storminess);
    if (overcast > 0.3) {
      const k = Math.min(1, overcast);
      curZenith.lerp(C.storm, k * 0.65);
      curHorizon.lerp(C.storm, k * 0.55 * (0.4 + 0.6 * Math.max(currentEnv.storminess, currentEnv.rainIntensity)));
      curHorizon.lerp(C.fogGrey, k * 0.35 * (1 - currentEnv.storminess));
    }
    if (currentEnv.snowIntensity > 0.05) {
      curZenith.lerp(C.snowGrey, currentEnv.snowIntensity * 0.45 * day);
      curHorizon.lerp(C.snowGrey, currentEnv.snowIntensity * 0.7 * day);
    }
    const fogAmt = Math.min(1, Math.max(0, (currentEnv.fogDensity - 0.03) / 0.07));
    if (fogAmt > 0) {
      curZenith.lerp(C.fogGrey, fogAmt * 0.6 * day);
      curHorizon.lerp(C.fogGrey, fogAmt * 0.85 * (0.25 + 0.75 * day));
    }

    skyMat.uniforms.uZenith.value.copy(curZenith);
    skyMat.uniforms.uHorizon.value.copy(curHorizon);
    skyMat.uniforms.uSunVis.value = Math.max(0, 1 - overcast * 1.25 - fogAmt) * Math.min(1, day * 1.5);

    // Fog color & density
    // Scene-scale fog (raw API visibility density is far too heavy for this world size)
    scene.fog.density = 0.0035 + Math.min(0.12, currentEnv.fogDensity) * 0.2;
    scene.fog.color.copy(curHorizon);
    renderer.toneMappingExposure = Math.max(0.5, currentEnv.exposure || 1);
    terrainU.uSnow.value = currentEnv.snowIntensity;
    terrainU.uWet.value = Math.min(1, currentEnv.wetness + currentEnv.terrainDarken * 0.4);

    // Sunlight direction & intensity
    const sunAngle = (day - 0.1) * Math.PI;
    sunLight.position.set(
      Math.cos(sunAngle) * 55,
      Math.sin(sunAngle) * 65 + 5,
      35
    );
    skyMat.uniforms.uSunDir.value.copy(sunLight.position).normalize();
    sunLight.intensity = currentEnv.sunIntensity * Math.max(0.08, day);
    ambientLight.intensity = currentEnv.ambientIntensity * Math.max(0.18, day);

    // Starlight opacity
    starsSystem.material.opacity = (1 - day) * 0.9;

    // 5. Thunderstorm lightning: visible bolt + flash light + sky flash
    if (currentEnv.storminess > 0.4) {
      lightningFlashTimer -= delta;
      if (lightningFlashTimer <= 0) {
        strikeBolt();
        lightningFlashTimer = Math.random() * 3 + 1.8;
      }
    }
    if (boltLife > 0) {
      boltLife = Math.max(0, boltLife - delta * 3.2);
      // flicker: two quick pulses
      const pulse = boltLife > 0.55 ? 1 : boltLife > 0.4 ? 0.25 : boltLife > 0.25 ? 0.9 : boltLife * 2;
      for (const l of boltLines) {
        l.material.opacity = pulse;
        if (boltLife === 0) l.visible = false;
      }
      skyMat.uniforms.uFlash.value = pulse * 0.55;
      lightningLight.intensity = lightningLight.intensity * 0.82 + pulse * 2;
    } else {
      skyMat.uniforms.uFlash.value = 0;
      lightningLight.intensity = 0;
    }

    // 6. Water Waves & Wind
    waterMat.uniforms.uTime.value = time;
    waterMat.uniforms.uWind.value = currentEnv.windSpeed;
    waterMat.uniforms.uSunDir.value.copy(sunLight.position).normalize();

    // 7. Drifting Volumetric Clouds
    const windRad = (currentEnv.windDeg * Math.PI) / 180;
    const windVecX = Math.sin(windRad) * (currentEnv.windSpeed * 0.08);
    const windVecZ = Math.cos(windRad) * (currentEnv.windSpeed * 0.08);

    const cd = currentEnv.cloudDensity;
    cloudMat.opacity = Math.min(0.95, 0.35 + cd * 0.7);
    const shade = Math.max(currentEnv.storminess * 0.85, Math.max(0, cd - 0.5) * 0.9, currentEnv.rainIntensity * 0.5);
    cloudMat.color.copy(C.cloudWhite).lerp(C.cloudDark, Math.min(1, shade));
    cloudMat.color.multiplyScalar(0.3 + 0.7 * Math.max(day, 0.15));

    const shown = Math.ceil(CLOUD_COUNT * Math.max(0.15, Math.min(1, cd)));
    const lowering = cd > 0.6 ? (cd - 0.6) * 10 : 0;
    for (let ci = 0; ci < cloudsGroup.children.length; ci++) {
      const c = cloudsGroup.children[ci];
      c.visible = ci < shown;
      if (!c.visible) continue;
      c.position.x += (windVecX + c.userData.driftSpeed) * f60;
      c.position.z += windVecZ * f60;
      c.position.y = c.userData.baseY - lowering;
      if (c.position.x > 120) c.position.x = -120;
      if (c.position.x < -120) c.position.x = 120;
      if (c.position.z > 120) c.position.z = -120;
      if (c.position.z < -120) c.position.z = 120;
    }

    // 8. Wind-Responsive Vegetation Swaying
    const swayAmp = Math.min(0.28, currentEnv.windSpeed * 0.015);
    if (frameNo % 2 === 0) {
    for (let i = 0; i < pineTransforms.length; i++) {
      const tr = pineTransforms[i];
      const sway = Math.sin(time * (1.8 + currentEnv.windSpeed * 0.25) + tr.phase) * swayAmp;
      dummyObj.position.copy(tr.basePos);
      dummyObj.scale.copy(tr.baseScale);
      dummyObj.rotation.set(tr.baseRot.x + sway, tr.baseRot.y, tr.baseRot.z + sway * 0.5);
      dummyObj.updateMatrix();
      pineInstanced.setMatrixAt(i, dummyObj.matrix);
    }
    pineInstanced.instanceMatrix.needsUpdate = true;

    for (let i = 0; i < tropicalTransforms.length; i++) {
      const tr = tropicalTransforms[i];
      const sway = Math.sin(time * (1.4 + currentEnv.windSpeed * 0.2) + tr.phase) * (swayAmp * 1.3);
      dummyObj.position.copy(tr.basePos);
      dummyObj.scale.copy(tr.baseScale);
      dummyObj.rotation.set(tr.baseRot.x + sway, tr.baseRot.y, tr.baseRot.z + sway * 0.7);
      dummyObj.updateMatrix();
      tropicalInstanced.setMatrixAt(i, dummyObj.matrix);
    }
    tropicalInstanced.instanceMatrix.needsUpdate = true;
    }

    // 9. Rain streaks (only the active fraction is simulated and drawn)
    if (currentEnv.rainIntensity > 0.05) {
      rainSystem.visible = true;
      const n = Math.max(200, Math.floor(RAIN_COUNT * Math.min(1, currentEnv.rainIntensity)));
      const out = rainSystem.geometry.attributes.position.array;
      const fall = (1.2 + currentEnv.rainIntensity) * f60;
      const streak = 1.1 + currentEnv.rainIntensity * 1.1;
      const dx = windVecX * 0.8 * f60;
      const dz = windVecZ * 0.8 * f60;
      for (let i = 0; i < n; i++) {
        const o = i * 3;
        rainHeads[o + 1] -= rainVelocities[i] * fall;
        rainHeads[o] += dx;
        rainHeads[o + 2] += dz;
        if (rainHeads[o + 1] < 1.0) {
          rainHeads[o + 1] = 52.0;
          rainHeads[o] = (Math.random() - 0.5) * 160;
          rainHeads[o + 2] = (Math.random() - 0.5) * 160;
        }
        const q = i * 6;
        out[q] = rainHeads[o];
        out[q + 1] = rainHeads[o + 1];
        out[q + 2] = rainHeads[o + 2];
        out[q + 3] = rainHeads[o] - windVecX * 2;
        out[q + 4] = rainHeads[o + 1] + streak;
        out[q + 5] = rainHeads[o + 2] - windVecZ * 2;
      }
      rainSystem.geometry.setDrawRange(0, n * 2);
      rainSystem.geometry.attributes.position.needsUpdate = true;
      rainMat.opacity = 0.3 + 0.3 * Math.min(1, currentEnv.rainIntensity);
    } else {
      rainSystem.visible = false;
    }

    // 10. Snow particles
    if (currentEnv.snowIntensity > 0.05) {
      snowSystem.visible = true;
      const n = Math.max(300, Math.floor(SNOW_COUNT * Math.min(1, currentEnv.snowIntensity + 0.1)));
      const positions = snowSystem.geometry.attributes.position.array;
      for (let i = 0; i < n; i++) {
        positions[i * 3 + 1] -= snowDrift[i] * f60;
        positions[i * 3] += (Math.sin(time + i) * 0.05 + windVecX * 0.3) * f60;
        positions[i * 3 + 2] += (Math.cos(time + i) * 0.05 + windVecZ * 0.3) * f60;
        if (positions[i * 3 + 1] < 1.0) positions[i * 3 + 1] = 48.0;
      }
      snowSystem.geometry.setDrawRange(0, n);
      snowSystem.geometry.attributes.position.needsUpdate = true;
    } else {
      snowSystem.visible = false;
    }

    // Render
    controls.update();
    renderer.render(scene, camera);
  }

  // Start loop
  renderLoop();
  window.addEventListener("resize", resize);
  let io = null;
  if (typeof IntersectionObserver !== "undefined") {
    io = new IntersectionObserver((entries) => { visibleInView = entries[0]?.isIntersecting !== false; });
    io.observe(canvas);
  }

  return {
    applyWeatherState,
    applyEnvironment: applyWeatherState,
    start() {
      isRunning = true;
      if (!animId) renderLoop();
    },
    setCameraPreset,
    setPaused(paused) {
      isRunning = !paused;
      if (isRunning) { clock.getDelta(); if (!animId) renderLoop(); }
    },
    resize,
    dispose() {
      isRunning = false;
      if (animId) cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
      io?.disconnect();
      controls.dispose();
      renderer.dispose();
    },
  };
}
