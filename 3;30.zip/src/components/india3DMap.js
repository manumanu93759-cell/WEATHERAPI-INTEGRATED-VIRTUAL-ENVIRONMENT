import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import indiaStatesGeoJSON from "../data/indiaStates.json";
import { INDIAN_CITIES, getCitiesByState, getPrimaryCityForState } from "../data/indianCities.js";

/**
 * India3DGeoMap — Premium Interactive 3D Geographic Visualization of India
 * 
 * Features:
 * 1. Geographically Authentic: Extrudes all 36 Indian States and Union Territories from official WGS84 GeoJSON.
 * 2. Conformal Projection: Accurate equirectangular projection centered at 82.5°E, 22.0°N with latitude cosine scaling.
 * 3. 3D State Meshes: Extruded vector boundaries with neon glowing edges, hover elevation, and state raycast selection.
 * 4. 3D City Beacons: Holographic light pillars, pulsing radar rings, and floating weather tags for all 77 curated Indian cities.
 * 5. Selected City Highlighting: Radiant vertical beam with rotating orbital gyro rings and close-up camera tweening.
 * 6. Meteorological Overlays: Real-time Precipitation Radar, State Temperature Heatmap, Wind Stream Vectors, and Clouds.
 * 7. Smooth Navigation: Full 3D rotation, pitch, zoom, auto-cinematic rotate, and quick camera reset.
 */

const CENTER_LON = 82.5;
const CENTER_LAT = 22.0;
const COS_LAT = Math.cos((CENTER_LAT * Math.PI) / 180);
const SCALE_X = 1.15 * COS_LAT;
const SCALE_Z = 1.15;
const BASE_ELEVATION = 0.35;

export function projectCoordinates(lon, lat) {
  return {
    x: (lon - CENTER_LON) * SCALE_X,
    z: -(lat - CENTER_LAT) * SCALE_Z,
  };
}

export class India3DGeoMap {
  constructor(containerElement, { onCitySelect, onStateSelect } = {}) {
    this.container = containerElement;
    this.onCitySelect = onCitySelect || (() => {});
    this.onStateSelect = onStateSelect || (() => {});

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.animId = null;

    this.statesGroup = new THREE.Group();
    this.stateMeshes = new Map(); // stateName -> Array of meshes
    this.stateBorders = new THREE.Group();
    this.markersGroup = new THREE.Group();
    this.cityMarkers = new Map(); // cityName -> Marker Group
    this.overlayGroup = new THREE.Group();

    this.selectedCityName = null;
    this.selectedStateName = null;
    this.hoveredStateName = null;
    this.hoveredMesh = null;
    this.cityWeatherData = new Map();
    this.activeOverlay = "none"; // 'none' | 'precipitation' | 'temp' | 'wind' | 'clouds'
    this.isAutoRotate = false;
    this.clock = new THREE.Clock();

    // Camera animation target
    this.cameraTarget = {
      pos: new THREE.Vector3(0, 32, 28),
      look: new THREE.Vector3(0, 0, 0),
      alpha: 1,
    };

    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2(-999, -999);

    this.init();
  }

  init() {
    if (!this.container) return;

    const width = this.container.clientWidth || 800;
    const height = this.container.clientHeight || 600;

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060913);
    this.scene.fog = new THREE.FogExp2(0x060913, 0.012);

    // 2. Camera setup: Looking down at India at an isometric 3D tilt
    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 500);
    this.camera.position.set(0, 32, 28);
    this.camera.lookAt(0, 0, 0);

    // 3. WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.innerHTML = "";
    this.container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.renderer.domElement.style.display = "block";
    this.renderer.domElement.style.outline = "none";

    // 4. Orbit Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.maxPolarAngle = Math.PI / 2.05; // Prevent camera going below ground
    this.controls.minDistance = 8;
    this.controls.maxDistance = 75;
    this.controls.target.set(0, 0, 0);

    // 5. Lighting
    this.setupLighting();

    // 6. Base Ocean Bedplate & Coordinates Grid
    this.setupBasePlate();

    // 7. Parse and Build 3D India State Meshes
    this.buildStatesFromGeoJSON();

    // 8. Build 3D City Beacons
    this.buildCityMarkers();

    // 9. Overlay System Setup
    this.setupOverlays();

    // 10. HTML Tooltip overlay
    this.setupHTMLOverlays();

    // 11. Event Listeners
    this.setupEventListeners();

    // 12. Animation Loop
    this.animate = this.animate.bind(this);
    this.animate();

    // Handle immediate resize
    setTimeout(() => this.onResize(), 150);
  }

  setupLighting() {
    const ambient = new THREE.AmbientLight(0x1e293b, 1.4);
    this.scene.add(ambient);

    // Key light (Sun from South-West illuminating terrain faces)
    const sunLight = new THREE.DirectionalLight(0xe0f2fe, 2.2);
    sunLight.position.set(-20, 45, 25);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.bias = -0.0005;
    this.scene.add(sunLight);

    // Cyan fill light from North-East (highlighting Himalayan borders)
    const northFill = new THREE.DirectionalLight(0x0284c7, 1.2);
    northFill.position.set(25, 20, -30);
    this.scene.add(northFill);

    // Sub-surface turquoise underglow from Indian Ocean
    const oceanLight = new THREE.PointLight(0x06b6d4, 1.5, 60);
    oceanLight.position.set(0, -2, 20);
    this.scene.add(oceanLight);
  }

  setupBasePlate() {
    const group = new THREE.Group();

    // 1. Dark reflective ocean plate
    const oceanGeom = new THREE.CylinderGeometry(36, 38, 1.5, 64);
    const oceanMat = new THREE.MeshStandardMaterial({
      color: 0x070c18,
      roughness: 0.35,
      metalness: 0.65,
    });
    const oceanPlate = new THREE.Mesh(oceanGeom, oceanMat);
    oceanPlate.position.y = -0.8;
    oceanPlate.receiveShadow = true;
    group.add(oceanPlate);

    // 2. Glowing outer ring
    const ringGeom = new THREE.RingGeometry(35.8, 36.4, 64);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x0ea5e9,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45,
    });
    const ring = new THREE.Mesh(ringGeom, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -0.02;
    group.add(ring);

    // 3. Geographic Grid lines (Tropic of Cancer 23.43°N, Equator 0°N, Meridians 70°E, 80°E, 90°E)
    const gridMat = new THREE.LineBasicMaterial({
      color: 0x1e3a5f,
      transparent: true,
      opacity: 0.4,
    });

    // Tropic of Cancer line (lat = 23.43°N)
    const cancerZ = projectCoordinates(CENTER_LON, 23.436).z;
    const cancerGeom = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-24, 0.02, cancerZ),
      new THREE.Vector3(24, 0.02, cancerZ),
    ]);
    const cancerLine = new THREE.Line(cancerGeom, new THREE.LineDashedMaterial({
      color: 0x38bdf8,
      dashSize: 0.8,
      gapSize: 0.5,
      transparent: true,
      opacity: 0.6,
    }));
    cancerLine.computeLineDistances();
    group.add(cancerLine);

    // Meridians
    [70, 75, 80, 85, 90, 95].forEach((lon) => {
      const x = projectCoordinates(lon, CENTER_LAT).x;
      const mGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(x, 0.01, -26),
        new THREE.Vector3(x, 0.01, 26),
      ]);
      const mLine = new THREE.Line(mGeom, gridMat);
      group.add(mLine);
    });

    // Latitudes
    [10, 15, 20, 25, 30, 35].forEach((lat) => {
      const z = projectCoordinates(CENTER_LON, lat).z;
      const pGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(-24, 0.01, z),
        new THREE.Vector3(24, 0.01, z),
      ]);
      const pLine = new THREE.Line(pGeom, gridMat);
      group.add(pLine);
    });

    this.scene.add(group);
  }

  buildStatesFromGeoJSON() {
    if (!indiaStatesGeoJSON || !indiaStatesGeoJSON.features) return;

    this.statesGroup.clear();
    this.stateBorders.clear();
    this.stateMeshes.clear();

    // Default state material: Deep sapphire slate with sleek specular highlights
    const baseStateMat = new THREE.MeshStandardMaterial({
      color: 0x0f1d33,
      roughness: 0.45,
      metalness: 0.4,
      flatShading: false,
    });

    const borderMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.75,
    });

    indiaStatesGeoJSON.features.forEach((feature) => {
      const stateName = feature.properties?.ST_NM || "Unknown State";
      const geomType = feature.geometry?.type;
      const coords = feature.geometry?.coordinates;
      const meshesForState = [];

      const processPolygonRings = (rings) => {
        if (!rings || !rings.length) return;
        const outerRing = rings[0];
        if (outerRing.length < 3) return;

        const shape = new THREE.Shape();
        let prev = null;
        let validPoints = 0;
        const linePoints = [];

        outerRing.forEach(([lon, lat]) => {
          const { x, z } = projectCoordinates(lon, lat);
          // In Three.js Shape coordinates, we work in 2D (x, y) where y corresponds to -z
          if (prev && Math.hypot(x - prev.x, z - prev.z) < 0.001) return;

          if (validPoints === 0) shape.moveTo(x, -z);
          else shape.lineTo(x, -z);

          linePoints.push(new THREE.Vector3(x, BASE_ELEVATION + 0.02, z));
          prev = { x, z };
          validPoints++;
        });

        if (validPoints < 3) return;

        // Process holes if any
        for (let h = 1; h < rings.length; h++) {
          const holeRing = rings[h];
          if (holeRing.length >= 3) {
            const holePath = new THREE.Path();
            let hPrev = null;
            let hCount = 0;
            holeRing.forEach(([lon, lat]) => {
              const { x, z } = projectCoordinates(lon, lat);
              if (hPrev && Math.hypot(x - hPrev.x, z - hPrev.z) < 0.001) return;
              if (hCount === 0) holePath.moveTo(x, -z);
              else holePath.lineTo(x, -z);
              hPrev = { x, z };
              hCount++;
            });
            if (hCount >= 3) shape.holes.push(holePath);
          }
        }

        // Extrude into 3D State Slab
        const extrudeGeom = new THREE.ExtrudeGeometry(shape, {
          depth: BASE_ELEVATION,
          bevelEnabled: true,
          bevelSegments: 2,
          steps: 1,
          bevelSize: 0.03,
          bevelThickness: 0.03,
        });

        // Rotate so depth is oriented vertically (Y-axis)
        extrudeGeom.rotateX(Math.PI / 2);

        // State individual material clone for interactive hover/selection
        const stateMat = baseStateMat.clone();
        const stateMesh = new THREE.Mesh(extrudeGeom, stateMat);
        stateMesh.castShadow = true;
        stateMesh.receiveShadow = true;
        stateMesh.userData = {
          stateName,
          originalColor: 0x0f1d33,
          isStateMesh: true,
        };

        this.statesGroup.add(stateMesh);
        meshesForState.push(stateMesh);

        // Boundary glowing edge
        if (linePoints.length > 2) {
          const borderGeom = new THREE.BufferGeometry().setFromPoints(linePoints);
          const borderLine = new THREE.Line(borderGeom, borderMat);
          this.stateBorders.add(borderLine);
        }
      };

      if (geomType === "Polygon") {
        processPolygonRings(coords);
      } else if (geomType === "MultiPolygon") {
        coords.forEach((poly) => processPolygonRings(poly));
      }

      if (meshesForState.length > 0) {
        this.stateMeshes.set(stateName, meshesForState);
      }
    });

    this.scene.add(this.statesGroup);
    this.scene.add(this.stateBorders);
  }

  buildCityMarkers() {
    this.markersGroup.clear();
    this.cityMarkers.clear();

    INDIAN_CITIES.forEach((city) => {
      const { x, z } = projectCoordinates(city.lon, city.lat);
      const isFeatured = !!city.featured;
      const markerGroup = new THREE.Group();
      markerGroup.position.set(x, BASE_ELEVATION, z);
      markerGroup.userData = { city, cityName: city.name };

      // 1. Glowing ground ring (Pulsing radar target)
      const ringGeom = new THREE.RingGeometry(0.18, 0.32, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: isFeatured ? 0x38bdf8 : 0x0284c7,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: isFeatured ? 0.8 : 0.45,
      });
      const ring = new THREE.Mesh(ringGeom, ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.02;
      markerGroup.add(ring);

      // 2. Vertical luminous beacon pin
      const beaconHeight = isFeatured ? 1.6 : 1.1;
      const beaconGeom = new THREE.CylinderGeometry(0.04, 0.08, beaconHeight, 12);
      const beaconMat = new THREE.MeshBasicMaterial({
        color: isFeatured ? 0x38bdf8 : 0x0ea5e9,
        transparent: true,
        opacity: isFeatured ? 0.95 : 0.7,
      });
      const beacon = new THREE.Mesh(beaconGeom, beaconMat);
      beacon.position.y = beaconHeight / 2;
      markerGroup.add(beacon);

      // 3. Floating Hologram Gem / Sphere at apex
      const gemGeom = new THREE.SphereGeometry(isFeatured ? 0.22 : 0.14, 16, 16);
      const gemMat = new THREE.MeshStandardMaterial({
        color: isFeatured ? 0x67e8f9 : 0x38bdf8,
        emissive: isFeatured ? 0x0284c7 : 0x0369a1,
        emissiveIntensity: 0.8,
        roughness: 0.2,
        metalness: 0.8,
      });
      const gem = new THREE.Mesh(gemGeom, gemMat);
      gem.position.y = beaconHeight;
      gem.userData = { isCityGem: true, cityName: city.name, city };
      markerGroup.add(gem);

      // 4. Highlight Orbital Rings (shown when selected)
      const haloGeom = new THREE.TorusGeometry(0.42, 0.03, 8, 24);
      const haloMat = new THREE.MeshBasicMaterial({
        color: 0xf59e0b,
        transparent: true,
        opacity: 0,
      });
      const halo = new THREE.Mesh(haloGeom, haloMat);
      halo.position.y = beaconHeight;
      halo.rotation.x = Math.PI / 3;
      halo.name = "selectionHalo";
      markerGroup.add(halo);

      this.markersGroup.add(markerGroup);
      this.cityMarkers.set(city.name, markerGroup);
    });

    this.scene.add(this.markersGroup);
  }

  setupOverlays() {
    this.overlayGroup.clear();

    // 1. 3D Precipitation Rain Particles
    const rainCount = 1800;
    const rainGeom = new THREE.BufferGeometry();
    const rainPositions = new Float32Array(rainCount * 3);
    const rainVelocities = new Float32Array(rainCount);

    for (let i = 0; i < rainCount; i++) {
      // Confined over Indian Subcontinent bounds [-16..16, -18..18]
      rainPositions[i * 3] = (Math.random() - 0.5) * 32;
      rainPositions[i * 3 + 1] = Math.random() * 12 + 0.5;
      rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 34;
      rainVelocities[i] = Math.random() * 0.25 + 0.18;
    }

    rainGeom.setAttribute("position", new THREE.BufferAttribute(rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.12,
      transparent: true,
      opacity: 0.7,
    });
    this.rainPoints = new THREE.Points(rainGeom, rainMat);
    this.rainPoints.userData = { rainVelocities };
    this.rainPoints.visible = false;
    this.overlayGroup.add(this.rainPoints);

    // 2. Wind Flow Particle Streamlines
    const windCount = 650;
    const windGeom = new THREE.BufferGeometry();
    const windPositions = new Float32Array(windCount * 3);
    const windSpeeds = new Float32Array(windCount);

    for (let i = 0; i < windCount; i++) {
      windPositions[i * 3] = (Math.random() - 0.5) * 36;
      windPositions[i * 3 + 1] = Math.random() * 3 + 1.2;
      windPositions[i * 3 + 2] = (Math.random() - 0.5) * 38;
      windSpeeds[i] = Math.random() * 0.12 + 0.05;
    }

    windGeom.setAttribute("position", new THREE.BufferAttribute(windPositions, 3));
    const windMat = new THREE.PointsMaterial({
      color: 0x6ee7b7,
      size: 0.15,
      transparent: true,
      opacity: 0.65,
    });
    this.windPoints = new THREE.Points(windGeom, windMat);
    this.windPoints.userData = { windSpeeds };
    this.windPoints.visible = false;
    this.overlayGroup.add(this.windPoints);

    this.scene.add(this.overlayGroup);
  }

  setupHTMLOverlays() {
    // Floating 3D Tooltip container inside the map element
    this.tooltip = document.createElement("div");
    this.tooltip.className = "map-3d-tooltip";
    this.tooltip.style.display = "none";
    this.container.appendChild(this.tooltip);

    // Screen-space badges container for 3D City labels
    this.labelsContainer = document.createElement("div");
    this.labelsContainer.className = "map-3d-labels-overlay";
    this.container.appendChild(this.labelsContainer);
  }

  setupEventListeners() {
    const el = this.renderer.domElement;

    this.onMouseMove = (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this.handleHover(e.clientX - rect.left, e.clientY - rect.top);
    };

    this.onClick = (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this.handleClick();
    };

    this.onWindowResize = () => this.onResize();

    el.addEventListener("mousemove", this.onMouseMove);
    el.addEventListener("click", this.onClick);
    window.addEventListener("resize", this.onWindowResize);
  }

  handleHover(screenX, screenY) {
    if (!this.camera) return;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    // 1. Check City Gems first
    const gemHits = this.raycaster.intersectObjects(this.markersGroup.children, true);
    const hitGem = gemHits.find((h) => h.object.userData?.isCityGem);

    if (hitGem) {
      const city = hitGem.object.userData.city;
      const weather = this.cityWeatherData.get(city.name.toLowerCase());
      const tempDisplay = weather ? `${Math.round(weather.temp)}°C` : "—";
      const conditionDisplay = weather?.condition || "Monitored Metro";

      this.tooltip.innerHTML = `
        <div class="tooltip-badge">🇮🇳 ${city.name}</div>
        <div class="tooltip-state">${city.state} • ${city.region} Zone</div>
        <div class="tooltip-temp">${tempDisplay} • ${conditionDisplay}</div>
        <div class="tooltip-click-hint">Click to select city & focus atmosphere</div>
      `;
      this.tooltip.style.left = `${screenX + 16}px`;
      this.tooltip.style.top = `${screenY - 12}px`;
      this.tooltip.style.display = "block";
      this.renderer.domElement.style.cursor = "pointer";
      return;
    }

    // 2. Check States
    const stateHits = this.raycaster.intersectObjects(this.statesGroup.children, true);
    if (stateHits.length > 0) {
      const mesh = stateHits[0].object;
      const stateName = mesh.userData?.stateName;

      if (stateName) {
        if (this.hoveredStateName !== stateName) {
          this.clearStateHover();
          this.hoverState(stateName);
        }

        const citiesInState = getCitiesByState(stateName);
        const cityListStr = citiesInState.length > 0 
          ? `${citiesInState.length} monitored cities: ${citiesInState.slice(0, 3).map((c) => c.name).join(", ")}${citiesInState.length > 3 ? "…" : ""}`
          : "Federal Administrative Sector";

        this.tooltip.innerHTML = `
          <div class="tooltip-badge">STATE / UNION TERRITORY</div>
          <div class="tooltip-title">${stateName}</div>
          <div class="tooltip-state">${cityListStr}</div>
          <div class="tooltip-click-hint">Click to inspect state capital</div>
        `;
        this.tooltip.style.left = `${screenX + 16}px`;
        this.tooltip.style.top = `${screenY - 12}px`;
        this.tooltip.style.display = "block";
        this.renderer.domElement.style.cursor = "pointer";
        return;
      }
    }

    // Clear hover if nothing intersected
    this.clearStateHover();
    this.tooltip.style.display = "none";
    this.renderer.domElement.style.cursor = "default";
  }

  hoverState(stateName) {
    this.hoveredStateName = stateName;
    const meshes = this.stateMeshes.get(stateName) || [];
    meshes.forEach((m) => {
      m.material.color.setHex(0x0284c7);
      m.material.emissive.setHex(0x0369a1);
      m.material.emissiveIntensity = 0.55;
      m.position.y = 0.18; // Elevate slightly in 3D
    });
  }

  clearStateHover() {
    if (!this.hoveredStateName) return;
    const meshes = this.stateMeshes.get(this.hoveredStateName) || [];
    meshes.forEach((m) => {
      const isSelected = this.selectedStateName && this.hoveredStateName.toLowerCase() === this.selectedStateName.toLowerCase();
      m.material.color.setHex(isSelected ? 0x0369a1 : 0x0f1d33);
      m.material.emissive.setHex(isSelected ? 0x0ea5e9 : 0x000000);
      m.material.emissiveIntensity = isSelected ? 0.6 : 0;
      m.position.y = isSelected ? 0.25 : 0;
    });
    this.hoveredStateName = null;
  }

  handleClick() {
    if (!this.camera) return;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    // 1. Did click a City Marker?
    const gemHits = this.raycaster.intersectObjects(this.markersGroup.children, true);
    const hitGem = gemHits.find((h) => h.object.userData?.isCityGem);

    if (hitGem) {
      const city = hitGem.object.userData.city;
      this.selectCity(city);
      return;
    }

    // 2. Did click a State Slab?
    const stateHits = this.raycaster.intersectObjects(this.statesGroup.children, true);
    if (stateHits.length > 0) {
      const mesh = stateHits[0].object;
      const stateName = mesh.userData?.stateName;
      if (stateName) {
        this.selectState(stateName);
      }
    }
  }

  selectCity(city) {
    if (!city) return;
    this.selectedCityName = city.name;
    this.selectedStateName = city.state;

    this.refreshSelections();
    this.focusCity(city.name);

    if (this.onCitySelect) {
      this.onCitySelect(city);
    }
  }

  selectState(stateName) {
    this.selectedStateName = stateName;
    this.refreshSelections();

    if (this.onStateSelect) {
      this.onStateSelect(stateName);
    }

    const primaryCity = getPrimaryCityForState(stateName);
    if (primaryCity) {
      this.selectCity(primaryCity);
    }
  }

  refreshSelections() {
    // 1. Update City Marker Halos & Beams
    this.cityMarkers.forEach((markerGroup, cityName) => {
      const isSelected = this.selectedCityName && cityName.toLowerCase() === this.selectedCityName.toLowerCase();
      const halo = markerGroup.getObjectByName("selectionHalo");
      if (halo) {
        halo.material.opacity = isSelected ? 0.95 : 0;
        halo.material.color.setHex(0xf59e0b);
      }
    });

    // 2. Update State Highlights
    this.stateMeshes.forEach((meshes, sName) => {
      const isSelected = this.selectedStateName && sName.toLowerCase() === this.selectedStateName.toLowerCase();
      meshes.forEach((m) => {
        m.material.color.setHex(isSelected ? 0x0284c7 : 0x0f1d33);
        m.material.emissive.setHex(isSelected ? 0x0ea5e9 : 0x000000);
        m.material.emissiveIntensity = isSelected ? 0.5 : 0;
        m.position.y = isSelected ? 0.25 : 0;
      });
    });
  }

  focusCity(cityName) {
    const found = INDIAN_CITIES.find((c) => c.name.toLowerCase() === (cityName || "").toLowerCase());
    if (!found) return;

    const { x, z } = projectCoordinates(found.lon, found.lat);

    // Smoothly fly camera to hover over city at an intimate 3D tilt
    this.cameraTarget.pos.set(x, 14, z + 12);
    this.cameraTarget.look.set(x, BASE_ELEVATION, z);
    this.cameraTarget.alpha = 0;
  }

  resetCamera() {
    // Reset to full view of India showing mainland, Northeast, and all territories
    this.cameraTarget.pos.set(0, 32, 28);
    this.cameraTarget.look.set(0, 0, 0);
    this.cameraTarget.alpha = 0;
  }

  setPerspective(mode = "isometric") {
    if (mode === "topdown") {
      this.cameraTarget.pos.set(0, 42, 0.1);
      this.cameraTarget.look.set(0, 0, 0);
      this.cameraTarget.alpha = 0;
    } else if (mode === "horizon") {
      this.cameraTarget.pos.set(0, 9, 32);
      this.cameraTarget.look.set(0, 2, 0);
      this.cameraTarget.alpha = 0;
    } else {
      this.resetCamera();
    }
  }

  setOverlay(overlayType) {
    this.activeOverlay = overlayType;

    if (this.rainPoints) this.rainPoints.visible = overlayType === "precipitation";
    if (this.windPoints) this.windPoints.visible = overlayType === "wind";

    // Temperature Heatmap coloring across states
    if (overlayType === "temp") {
      this.applyTemperatureHeatmap();
    } else {
      this.resetStateColors();
    }
  }

  applyTemperatureHeatmap() {
    this.stateMeshes.forEach((meshes, stateName) => {
      const cities = getCitiesByState(stateName);
      let avgTemp = 25;
      if (cities.length > 0) {
        const cityWeather = cities
          .map((c) => this.cityWeatherData.get(c.name.toLowerCase()))
          .filter(Boolean);
        if (cityWeather.length > 0) {
          avgTemp = cityWeather.reduce((sum, w) => sum + (w.temp || 25), 0) / cityWeather.length;
        }
      }

      // Color from cool blue (15°C) to green (24°C) to amber (32°C) to red (42°C+)
      let hex = 0x0284c7; // Moderate blue
      if (avgTemp < 18) hex = 0x38bdf8; // Cool cyan (Ladakh, Kashmir, Himachal)
      else if (avgTemp < 28) hex = 0x10b981; // Mild green
      else if (avgTemp < 36) hex = 0xf59e0b; // Warm amber
      else hex = 0xef4444; // Scorching red

      meshes.forEach((m) => {
        m.material.color.setHex(hex);
        m.material.emissive.setHex(hex);
        m.material.emissiveIntensity = 0.35;
      });
    });
  }

  resetStateColors() {
    this.refreshSelections();
  }

  updateCityWeather(cityWeatherMap) {
    if (!cityWeatherMap) return;
    this.cityWeatherData = cityWeatherMap;

    // Update active overlays if temp heatmap is open
    if (this.activeOverlay === "temp") {
      this.applyTemperatureHeatmap();
    }

    this.updateScreenLabels();
  }

  updateScreenLabels() {
    if (!this.labelsContainer || !this.camera) return;

    const width = this.container.clientWidth;
    const height = this.container.clientHeight;

    // Render 3D City Labels in screen space for featured cities or selected city
    const html = [];
    INDIAN_CITIES.forEach((city) => {
      const isSelected = this.selectedCityName && city.name.toLowerCase() === this.selectedCityName.toLowerCase();
      if (!city.featured && !isSelected) return;

      const { x, z } = projectCoordinates(city.lon, city.lat);
      const worldPos = new THREE.Vector3(x, BASE_ELEVATION + 1.8, z);
      worldPos.project(this.camera);

      // Check if in front of camera
      if (worldPos.z > 1) return;

      const screenX = ((worldPos.x + 1) * width) / 2;
      const screenY = ((-worldPos.y + 1) * height) / 2;

      const weather = this.cityWeatherData.get(city.name.toLowerCase());
      const tempStr = weather ? `${Math.round(weather.temp)}°` : "";
      const iconStr = weather?.icon || "🌤️";

      html.push(`
        <div class="city-3d-tag ${isSelected ? "selected" : ""}" style="transform: translate(-50%, -100%) translate(${screenX}px, ${screenY}px);">
          <span class="city-tag-icon">${iconStr}</span>
          <span class="city-tag-name">${city.name}</span>
          ${tempStr ? `<span class="city-tag-temp">${tempStr}</span>` : ""}
        </div>
      `);
    });

    this.labelsContainer.innerHTML = html.join("");
  }

  animate() {
    this.animId = requestAnimationFrame(this.animate);

    const delta = this.clock.getDelta();
    const time = this.clock.getElapsedTime();

    // 1. Smooth Camera Fly-to Interpolation
    if (this.cameraTarget.alpha < 1) {
      this.cameraTarget.alpha += delta * 1.8;
      const t = Math.min(1, this.cameraTarget.alpha);
      const smoothT = t * t * (3 - 2 * t);

      this.camera.position.lerp(this.cameraTarget.pos, smoothT * 0.15);
      this.controls.target.lerp(this.cameraTarget.look, smoothT * 0.15);
    }

    // 2. Auto-Rotation
    if (this.isAutoRotate && this.cameraTarget.alpha >= 1) {
      this.controls.autoRotate = true;
      this.controls.autoRotateSpeed = 0.8;
    } else {
      this.controls.autoRotate = false;
    }

    // 3. Animate City Marker Pulse Rings & Selection Halos
    this.cityMarkers.forEach((markerGroup, cityName) => {
      const isSelected = this.selectedCityName && cityName.toLowerCase() === this.selectedCityName.toLowerCase();
      const halo = markerGroup.getObjectByName("selectionHalo");
      if (halo && isSelected) {
        halo.rotation.z += delta * 2.2;
        halo.rotation.y += delta * 1.5;
        halo.scale.setScalar(1 + Math.sin(time * 4) * 0.12);
      }
    });

    // 4. Animate Rain Overlay Particles
    if (this.rainPoints && this.rainPoints.visible) {
      const positions = this.rainPoints.geometry.attributes.position.array;
      const velocities = this.rainPoints.userData.rainVelocities;
      for (let i = 0; i < velocities.length; i++) {
        positions[i * 3 + 1] -= velocities[i];
        if (positions[i * 3 + 1] < BASE_ELEVATION) {
          positions[i * 3 + 1] = 12.0;
        }
      }
      this.rainPoints.geometry.attributes.position.needsUpdate = true;
    }

    // 5. Animate Wind Stream Flow
    if (this.windPoints && this.windPoints.visible) {
      const positions = this.windPoints.geometry.attributes.position.array;
      const speeds = this.windPoints.userData.windSpeeds;
      for (let i = 0; i < speeds.length; i++) {
        positions[i * 3] += speeds[i] * 1.2;
        positions[i * 3 + 2] -= speeds[i] * 0.4;
        if (positions[i * 3] > 18) positions[i * 3] = -18;
        if (positions[i * 3 + 2] < -18) positions[i * 3 + 2] = 18;
      }
      this.windPoints.geometry.attributes.position.needsUpdate = true;
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
    this.updateScreenLabels();
  }

  onResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width === 0 || height === 0) return;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  dispose() {
    if (this.animId) cancelAnimationFrame(this.animId);
    window.removeEventListener("resize", this.onWindowResize);
    const el = this.renderer?.domElement;
    if (el) {
      el.removeEventListener("mousemove", this.onMouseMove);
      el.removeEventListener("click", this.onClick);
    }
    if (this.controls) this.controls.dispose();
    if (this.renderer) this.renderer.dispose();
    this.container.innerHTML = "";
  }
}
