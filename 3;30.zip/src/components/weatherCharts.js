import {
  Chart,
  LineController,
  BarController,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Tooltip,
  Filler,
  Legend,
} from "chart.js";

Chart.register(
  LineController,
  BarController,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Tooltip,
  Filler,
  Legend
);

export class WeatherAnalyticsChart {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.chart = null;
    this.currentTab = "temperature"; // 'temperature' | 'rain' | 'wind' | 'aqi'
    this.weatherData = null;
  }

  setTab(tab) {
    if (this.currentTab === tab) return;
    this.currentTab = tab;
    this.render();
  }

  updateData(weather) {
    this.weatherData = weather;
    this.render();
  }

  render() {
    if (!this.canvas || !this.weatherData) return;

    if (this.chart) {
      this.chart.destroy();
      this.chart = null;
    }

    const hourly = this.weatherData.hourly || [];
    const ctx = this.canvas.getContext("2d");
    let config = null;

    if (this.currentTab === "temperature") {
      if (hourly.length === 0) return;
      const labels = hourly.map((h) => h.time);
      const temps = hourly.map((h) => h.temp);
      const feels = hourly.map((h) => h.feelsLike);

      const gradient = ctx.createLinearGradient(0, 0, 0, 200);
      gradient.addColorStop(0, "rgba(56, 189, 248, 0.4)");
      gradient.addColorStop(1, "rgba(56, 189, 248, 0.0)");

      config = {
        type: "line",
        data: {
          labels,
          datasets: [
            {
              label: "Ambient Temperature (°C)",
              data: temps,
              borderColor: "#38bdf8",
              backgroundColor: gradient,
              borderWidth: 2.8,
              tension: 0.38,
              fill: true,
              pointBackgroundColor: "#38bdf8",
              pointBorderColor: "#ffffff",
              pointRadius: 4,
              pointHoverRadius: 7,
            },
            {
              label: "Feels Like (°C)",
              data: feels,
              borderColor: "#a78bfa",
              borderDash: [5, 5],
              borderWidth: 2,
              tension: 0.38,
              fill: false,
              pointBackgroundColor: "#a78bfa",
              pointRadius: 3,
            },
          ],
        },
        options: this.getChartOptions("°C"),
      };
    } else if (this.currentTab === "rain") {
      if (hourly.length === 0) return;
      const labels = hourly.map((h) => h.time);
      const pops = hourly.map((h) => h.pop);
      const rains = hourly.map((h) => Number(h.rain || 0));

      const gradient = ctx.createLinearGradient(0, 0, 0, 200);
      gradient.addColorStop(0, "rgba(52, 211, 153, 0.45)");
      gradient.addColorStop(1, "rgba(52, 211, 153, 0.0)");

      config = {
        type: "line",
        data: {
          labels,
          datasets: [
            {
              type: "line",
              label: "Precipitation Probability (%)",
              data: pops,
              borderColor: "#34d399",
              backgroundColor: gradient,
              borderWidth: 2.5,
              tension: 0.3,
              fill: true,
              yAxisID: "y",
              pointBackgroundColor: "#34d399",
              pointRadius: 4,
            },
            {
              type: "bar",
              label: "Rainfall Volume (mm)",
              data: rains,
              backgroundColor: "rgba(14, 165, 233, 0.55)",
              borderColor: "#38bdf8",
              borderWidth: 1.5,
              borderRadius: 6,
              yAxisID: "y1",
            },
          ],
        },
        options: {
          ...this.getChartOptions("% / mm"),
          scales: {
            x: {
              grid: { color: "rgba(255, 255, 255, 0.04)" },
              ticks: { color: "#64748b", font: { family: "'IBM Plex Sans', sans-serif", size: 10 } },
            },
            y: {
              type: "linear",
              position: "left",
              min: 0,
              max: 100,
              grid: { color: "rgba(255, 255, 255, 0.05)" },
              ticks: { color: "#34d399", callback: (v) => `${v}%` },
            },
            y1: {
              type: "linear",
              position: "right",
              min: 0,
              grid: { drawOnChartArea: false },
              ticks: { color: "#38bdf8", callback: (v) => `${v} mm` },
            },
          },
        },
      };
    } else if (this.currentTab === "wind") {
      if (hourly.length === 0) return;
      const labels = hourly.map((h) => h.time);
      const windsKmh = hourly.map((h) => Math.round(Number(h.windSpeed || 0) * 3.6));

      const gradient = ctx.createLinearGradient(0, 0, 0, 200);
      gradient.addColorStop(0, "rgba(244, 114, 182, 0.4)");
      gradient.addColorStop(1, "rgba(244, 114, 182, 0.0)");

      config = {
        type: "line",
        data: {
          labels,
          datasets: [
            {
              label: "Wind Velocity (km/h)",
              data: windsKmh,
              borderColor: "#f472b6",
              backgroundColor: gradient,
              borderWidth: 2.6,
              tension: 0.35,
              fill: true,
              pointBackgroundColor: "#f472b6",
              pointRadius: 4,
              pointHoverRadius: 6,
            },
          ],
        },
        options: this.getChartOptions("km/h"),
      };
    } else if (this.currentTab === "aqi") {
      const comps = this.weatherData.airQuality?.components || {};
      const labels = ["PM2.5", "PM10", "NO2", "O3", "SO2", "CO / 10"];
      const values = [
        comps.pm2_5 ? Math.round(comps.pm2_5) : 25,
        comps.pm10 ? Math.round(comps.pm10) : 45,
        comps.no2 ? Math.round(comps.no2) : 18,
        comps.o3 ? Math.round(comps.o3) : 35,
        comps.so2 ? Math.round(comps.so2) : 8,
        comps.co ? Math.round(comps.co / 10) : 28,
      ];

      const barColors = values.map((val, idx) => {
        // High PM2.5 or PM10 threshold
        if (idx === 0 && val > 60) return "rgba(244, 63, 94, 0.85)"; // High PM2.5
        if (idx === 1 && val > 100) return "rgba(245, 158, 11, 0.85)"; // High PM10
        return "rgba(52, 211, 153, 0.8)";
      });

      config = {
        type: "bar",
        data: {
          labels,
          datasets: [
            {
              label: "Concentration (µg/m³)",
              data: values,
              backgroundColor: barColors,
              borderColor: "rgba(255, 255, 255, 0.2)",
              borderWidth: 1,
              borderRadius: 6,
            },
          ],
        },
        options: {
          indexAxis: "y",
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: "rgba(15, 23, 42, 0.95)",
              titleColor: "#f8fafc",
              bodyColor: "#cbd5e1",
              borderColor: "rgba(148, 163, 184, 0.25)",
              borderWidth: 1,
              callbacks: {
                label: (ctx) => ` Concentration: ${ctx.parsed.x} µg/m³`,
              },
            },
          },
          scales: {
            x: {
              grid: { color: "rgba(255, 255, 255, 0.05)" },
              ticks: { color: "#64748b", font: { family: "'IBM Plex Sans', sans-serif", size: 10 } },
            },
            y: {
              grid: { display: false },
              ticks: { color: "#cbd5e1", font: { family: "'IBM Plex Sans', sans-serif", size: 11, weight: 600 } },
            },
          },
        },
      };
    }

    if (config) {
      this.chart = new Chart(this.canvas, config);
    }
  }

  getChartOptions(unitLabel) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: "index",
        intersect: false,
      },
      plugins: {
        legend: {
          display: true,
          labels: {
            color: "#94a3b8",
            font: { family: "'IBM Plex Sans', sans-serif", size: 11 },
            boxWidth: 12,
            boxHeight: 12,
          },
        },
        tooltip: {
          backgroundColor: "rgba(15, 23, 42, 0.92)",
          titleColor: "#f8fafc",
          bodyColor: "#cbd5e1",
          borderColor: "rgba(148, 163, 184, 0.25)",
          borderWidth: 1,
          padding: 10,
          cornerRadius: 8,
          titleFont: { family: "'Syne', sans-serif", size: 12, weight: "bold" },
          bodyFont: { family: "'IBM Plex Sans', sans-serif", size: 12 },
          callbacks: {
            label(context) {
              const label = context.dataset.label || "";
              const val = context.parsed.y;
              return `  ${label}: ${val}`;
            },
          },
        },
      },
      scales: {
        x: {
          grid: { color: "rgba(255, 255, 255, 0.04)" },
          ticks: { color: "#64748b", font: { family: "'IBM Plex Sans', sans-serif", size: 10 } },
        },
        y: {
          grid: { color: "rgba(255, 255, 255, 0.05)" },
          ticks: { color: "#64748b", font: { family: "'IBM Plex Sans', sans-serif", size: 10 } },
        },
      },
    };
  }

  resize() {
    if (this.chart) {
      this.chart.resize();
    }
  }

  dispose() {
    if (this.chart) {
      this.chart.destroy();
      this.chart = null;
    }
  }
}
