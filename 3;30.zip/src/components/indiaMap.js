import L from "leaflet";
import "leaflet/dist/leaflet.css";
import indiaStatesGeoJSON from "../data/indiaStates.json";
import { INDIAN_CITIES, getPrimaryCityForState, getCitiesByState } from "../data/indianCities.js";
import { loadUserApiKey } from "../services/weatherService.js";
import { loadStateDistricts } from "../services/geoData.js";
import { normalizeState } from "../utils/geoText.js";

/**
 * IndiaWeatherMap — Precision Geographic Map of India
 * 
 * Features:
 * 1. Accurate WGS84 GeoJSON administrative boundaries for all 28 States and 8 Union Territories.
 * 2. Proper map projection and framing covering mainland India, Northeast states, J&K, Ladakh,
 *    Andaman & Nicobar Islands, and Lakshadweep.
 * 3. Interactive state hover highlighting, tooltip labels, and state selection.
 * 4. Geographically accurate city markers with live temperature color coding and meteorological popups.
 * 5. Real-time OpenWeather radar/satellite tile overlays (Precipitation, Clouds, Temp, Wind).
 * 6. Center India reset navigation and responsive resize handling.
 */
export class IndiaWeatherMap {
  constructor(containerElement, { onCitySelect, onStateSelect, onDistrictSelect, onError } = {}) {
    this.onDistrictSelect = onDistrictSelect || (() => {});
    this.onError = onError || (() => {});
    this.districtLayer = null;
    this.districtState = null;
    this.selectedDistrictId = null;
    this.pointMarker = null;
    this._districtReq = 0;
    this.container = containerElement;
    this.onCitySelect = onCitySelect || (() => {});
    this.onStateSelect = onStateSelect || (() => {});
    this.map = null;
    this.statesLayer = null;
    this.markers = new Map();
    this.selectedCityName = null;
    this.selectedStateName = null;
    this.cityWeatherData = new Map();
    this.activeWeatherLayer = null;
    this.currentOverlayType = "none"; // 'none' | 'precipitation' | 'clouds' | 'temp' | 'wind'

    this.init();
  }

  init() {
    if (!this.container) return;

    // Center on India [22.4°N, 80.0°E], zoom 4.6 with fine-grained zoom snaps
    this.map = L.map(this.container, {
      center: [22.4, 80.0],
      zoom: 4.6,
      zoomSnap: 0.1,
      zoomDelta: 0.5,
      minZoom: 3.8,
      maxZoom: 12,
      zoomControl: true,
      attributionControl: true,
    });

    // Dark high-contrast meteorological basemap from CartoDB
    this.baseLayer = L.tileLayer(
      "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
      {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: "abcd",
        maxZoom: 19,
      }
    ).addTo(this.map);
    let tileErrs = 0;
    this.baseLayer.on("tileerror", () => { if (++tileErrs === 5) this.onError("Basemap tiles could not be loaded; boundaries are still shown."); });

    // Geographic boundary for India [SouthWest: 6°N, 68°E; NorthEast: 37.5°N, 97.5°E]
    const southWest = L.latLng(5.5, 67.0);
    const northEast = L.latLng(38.0, 98.0);
    const bounds = L.latLngBounds(southWest, northEast);
    this.map.setMaxBounds(bounds.pad(0.15));

    // 1. Render Official States & Union Territories GeoJSON
    this.renderStatesGeoJSON();

    // City badge markers are intentionally not rendered by default (visual clutter); the selected location gets one marker.

    // 3. Handle popup action buttons
    this.map.on("popupopen", (e) => {
      const el = e.popup.getElement();
      if (!el) return;
      const btn = el.querySelector(".popup-btn");
      if (btn) {
        btn.addEventListener("click", () => {
          const cityName = btn.dataset.city;
          const found = INDIAN_CITIES.find((c) => c.name.toLowerCase() === (cityName || "").toLowerCase());
          if (found) {
            this.selectedCityName = found.name;
            this.refreshMarkerStyles();
            this.onCitySelect(found);
            this.map.closePopup();
          }
        });
      }
    });

    // Force map size invalidation after layout stabilizes
    setTimeout(() => {
      if (this.map) this.map.invalidateSize();
    }, 250);
  }

  /**
   * Render accurate State and UT vector boundaries with hover and click selection
   */
  renderStatesGeoJSON() {
    if (!this.map || !indiaStatesGeoJSON) return;

    this.statesLayer = L.geoJSON(indiaStatesGeoJSON, {
      style: (feature) => {
        const stateName = feature.properties?.ST_NM || "";
        const isSelected = this.selectedStateName && this.isStateMatch(stateName, this.selectedStateName);
        return {
          fillColor: isSelected ? "#0284c7" : "#0ea5e9",
          fillOpacity: isSelected ? 0.35 : 0.08,
          color: isSelected ? "#38bdf8" : "rgba(56, 189, 248, 0.4)",
          weight: isSelected ? 2.5 : 1.2,
          dashArray: isSelected ? "" : "3, 3",
        };
      },
      onEachFeature: (feature, layer) => {
        const stateName = feature.properties?.ST_NM || "";
        const citiesInState = getCitiesByState(stateName);
        const countBadge = citiesInState.length > 0 ? ` (${citiesInState.length} cities)` : "";

        // Floating tooltip for state
        layer.bindTooltip(`<strong>${stateName}</strong>${countBadge}`, {
          className: "custom-leaflet-tooltip",
          sticky: true,
          direction: "top",
        });

        // Hover highlighting
        layer.on("mouseover", () => {
          const isSelected = this.selectedStateName && this.isStateMatch(stateName, this.selectedStateName);
          if (!isSelected) {
            layer.setStyle({
              fillColor: "#38bdf8",
              fillOpacity: 0.22,
              color: "#38bdf8",
              weight: 2.0,
            });
          }
        });

        layer.on("mouseout", () => {
          const isSelected = this.selectedStateName && this.isStateMatch(stateName, this.selectedStateName);
          if (!isSelected) {
            layer.setStyle({
              fillColor: "#0ea5e9",
              fillOpacity: 0.08,
              color: "rgba(56, 189, 248, 0.4)",
              weight: 1.2,
              dashArray: "3, 3",
            });
          }
        });

        // Click state to select and inspect
        layer.on("click", (e) => {
          L.DomEvent.stopPropagation(e);
          this.selectState(stateName);
        });
      },
    }).addTo(this.map);
  }

  isStateMatch(a, b) {
    if (!a || !b) return false;
    return normalizeState(a) === normalizeState(b);
  }

  selectState(stateName) {
    this.selectedStateName = stateName;
    this.refreshStateStyles();

    // Zoom into state bounds with gentle padding
    if (this.statesLayer) {
      this.statesLayer.eachLayer((layer) => {
        const st = layer.feature?.properties?.ST_NM;
        if (this.isStateMatch(st, stateName)) {
          const bounds = layer.getBounds();
          this.map.fitBounds(bounds, { padding: [40, 40], maxZoom: 7, animate: true, duration: 1.0 });
        }
      });
    }

    // Load this state's district boundaries (lazy, cached) and inform listener
    this.showDistricts(stateName);
    this.onStateSelect(stateName);
  }

  /** Lazily load + draw district boundaries for one state/UT. Stale requests are ignored. */
  async showDistricts(stateName, { selectId = null, fit = false } = {}) {
    const req = ++this._districtReq;
    try {
      const fc = await loadStateDistricts(stateName);
      if (req !== this._districtReq || !this.map) return null;
      if (this.districtLayer) { this.map.removeLayer(this.districtLayer); this.districtLayer = null; }
      this.districtState = stateName;
      this.districtLayer = L.geoJSON(fc, {
        style: (f) => this.districtStyle(f),
        onEachFeature: (f, layer) => {
          const p = f.properties;
          layer.bindTooltip(`<strong>${p.name}</strong><br><small>${p.state}</small>`, { className: "custom-leaflet-tooltip", sticky: true });
          layer.on("mouseover", () => { if (p.id !== this.selectedDistrictId) layer.setStyle({ fillOpacity: 0.3, weight: 2, color: "#7dd3fc" }); });
          layer.on("mouseout", () => layer.setStyle(this.districtStyle(f)));
          layer.on("click", (e) => { L.DomEvent.stopPropagation(e); this.selectDistrict(p.id, { fit: false }); });
        },
      }).addTo(this.map);
      if (fit) this.map.fitBounds(this.districtLayer.getBounds(), { padding: [30, 30], maxZoom: 8 });
      if (selectId) this.selectDistrict(selectId, { fit: true });
      return fc.features.map((f) => f.properties);
    } catch (err) {
      if (req === this._districtReq) this.onError(`District boundaries for ${stateName} could not be loaded: ${err.message}`);
      return null;
    }
  }

  districtStyle(f) {
    const sel = f.properties.id === this.selectedDistrictId;
    return { fillColor: sel ? "#f59e0b" : "#38bdf8", fillOpacity: sel ? 0.45 : 0.1, color: sel ? "#fbbf24" : "#38bdf8", weight: sel ? 3 : 1, dashArray: "" };
  }

  selectDistrict(id, { fit = true, notify = true } = {}) {
    this.selectedDistrictId = id;
    let props = null;
    this.districtLayer?.eachLayer((layer) => {
      layer.setStyle(this.districtStyle(layer.feature));
      if (layer.feature.properties.id === id) {
        props = layer.feature.properties; layer.bringToFront();
        if (fit) this.map.fitBounds(layer.getBounds(), { padding: [40, 40], maxZoom: 9, animate: true });
      }
    });
    if (props) { this.setPointMarker(props.lat, props.lon, props.name); if (notify) this.onDistrictSelect(props); }
    return props;
  }

  /** Show the selected location (city/town/district representative point). */
  setPointMarker(lat, lon, label) {
    if (!this.map) return;
    if (this.pointMarker) this.map.removeLayer(this.pointMarker);
    this.pointMarker = L.circleMarker([lat, lon], { radius: 8, color: "#fff", weight: 2, fillColor: "#ef4444", fillOpacity: 0.95 })
      .bindTooltip(label, { permanent: false, direction: "top" }).addTo(this.map);
  }

  /** Focus any search result: state -> boundary, district -> boundary, city/town -> point zoom. */
  async focusResult(r) {
    if (!this.map) return;
    if (r.kind === "state") { this.selectedStateName = r.name; this.refreshStateStyles(); this.statesLayer?.eachLayer((l) => { if (this.isStateMatch(l.feature.properties.ST_NM, r.name)) this.map.fitBounds(l.getBounds(), { padding: [40, 40], maxZoom: 7 }); }); this.showDistricts(r.name); return; }
    this.selectedStateName = r.state; this.refreshStateStyles();
    if (this.districtState !== r.state || !this.districtLayer) await this.showDistricts(r.state);
    if (r.kind === "district") { this.selectDistrict(r.id, { fit: true, notify: false }); return; }
    // city/town: highlight containing district (if known) and zoom to the point
    const target = this.districtLayer ? [...this.districtLayer.getLayers()].find((l) => l.feature.properties.name === r.district) : null;
    this.selectedDistrictId = target ? target.feature.properties.id : null;
    this.districtLayer?.eachLayer((l) => l.setStyle(this.districtStyle(l.feature)));
    this.setPointMarker(r.lat, r.lon, r.name);
    this.map.flyTo([r.lat, r.lon], 10, { duration: 0.8 });
  }

  refreshStateStyles() {
    if (!this.statesLayer) return;
    this.statesLayer.eachLayer((layer) => {
      const stateName = layer.feature?.properties?.ST_NM || "";
      const isSelected = this.selectedStateName && this.isStateMatch(stateName, this.selectedStateName);
      layer.setStyle({
        fillColor: isSelected ? "#0284c7" : "#0ea5e9",
        fillOpacity: isSelected ? 0.35 : 0.08,
        color: isSelected ? "#38bdf8" : "rgba(56, 189, 248, 0.4)",
        weight: isSelected ? 2.5 : 1.2,
        dashArray: isSelected ? "" : "3, 3",
      });
      if (isSelected) {
        layer.bringToFront();
      }
    });
  }

  /**
   * Toggle OpenWeather meteorological tile layers (Precipitation Radar, Clouds, Temp, Wind)
   */
  setWeatherOverlay(overlayType) {
    this.currentOverlayType = overlayType;

    if (this.activeWeatherLayer) {
      this.map.removeLayer(this.activeWeatherLayer);
      this.activeWeatherLayer = null;
    }

    if (overlayType === "none") return;

    const apiKey = loadUserApiKey();
    if (!apiKey) { this.onError("Weather radar overlays need your own OpenWeather key (Settings → API Setup)."); return; }
    let layerEndpoint = "";

    switch (overlayType) {
      case "precipitation":
        layerEndpoint = "precipitation_new";
        break;
      case "clouds":
        layerEndpoint = "clouds_new";
        break;
      case "temp":
        layerEndpoint = "temp_new";
        break;
      case "wind":
        layerEndpoint = "wind_new";
        break;
      default:
        return;
    }

    this.activeWeatherLayer = L.tileLayer(
      `https://tile.openweathermap.org/map/${layerEndpoint}/{z}/{x}/{y}.png?appid=${apiKey}`,
      {
        opacity: 0.65,
        attribution: '&copy; <a href="https://openweathermap.org">OpenWeather</a>',
        maxZoom: 18,
      }
    ).addTo(this.map);
  }

  updateWeatherData(weather) {
    if (!weather) return;
    this.selectedCityName = weather.city;
    this.cityWeatherData.set(weather.city.toLowerCase(), weather);
    if (weather.state) {
      this.selectedStateName = weather.state;
      this.refreshStateStyles();
    }
    this.refreshMarkerStyles();

    // Pan smoothly to city coordinates
    if (weather.lat && weather.lon && this.map) {
      this.map.panTo([weather.lat, weather.lon], { animate: true, duration: 0.8 });
    }
  }

  getTempColor(temp) {
    if (temp == null || isNaN(temp)) return "#94a3b8";
    if (temp < 15) return "#38bdf8"; // Cold blue
    if (temp < 25) return "#34d399"; // Pleasant emerald
    if (temp < 35) return "#f59e0b"; // Warm amber
    return "#f43f5e"; // Hot rose/red
  }

  renderCityMarkers() {
    // Curated high-importance cities across all zones and state capitals
    const displayCities = INDIAN_CITIES.filter(
      (c) => c.featured || c.region === "North" || c.region === "South" || c.region === "East" || c.region === "West" || c.region === "Northeast" || c.region === "Islands"
    );

    for (const city of displayCities) {
      const isSelected = this.selectedCityName && city.name.toLowerCase() === this.selectedCityName.toLowerCase();
      const cached = this.cityWeatherData.get(city.name.toLowerCase());
      const tempVal = cached ? Math.round(cached.temp) : null;
      const tempText = tempVal != null ? `${tempVal}°` : "—";
      const iconText = cached ? cached.icon : "📍";
      const tempColor = this.getTempColor(tempVal);

      const icon = L.divIcon({
        className: "varsha-map-marker-container",
        html: `
          <div class="map-city-badge ${isSelected ? "selected" : ""}" data-city="${city.name}" style="--badge-accent: ${tempColor}">
            <span class="marker-pulse"></span>
            <span class="marker-icon">${iconText}</span>
            <span class="marker-name">${city.name}</span>
            <span class="marker-temp" style="color: ${tempColor}">${tempText}</span>
          </div>
        `,
        iconSize: [110, 34],
        iconAnchor: [55, 17],
      });

      const marker = L.marker([city.lat, city.lon], { icon }).addTo(this.map);

      marker.on("click", (e) => {
        L.DomEvent.stopPropagation(e);
        this.selectedCityName = city.name;
        this.selectedStateName = city.state;
        this.refreshStateStyles();
        this.refreshMarkerStyles();
        this.onCitySelect(city);
      });

      // Rich meteorological popup
      marker.bindPopup(() => {
        const data = this.cityWeatherData.get(city.name.toLowerCase());
        const temp = data ? `${Math.round(data.temp)}°C` : "—";
        const cond = data ? (data.description || data.condition) : "Meteorological monitoring";
        const hum = data && data.humidity != null ? `${data.humidity}%` : "—";
        const wind = data && data.windSpeed != null ? `${(data.windSpeed * 3.6).toFixed(0)} km/h` : "—";

        return `
          <div class="map-popup-card">
            <div class="popup-head">
              <strong>${city.name}</strong>
              <span class="popup-state">${city.state}</span>
            </div>
            <div class="popup-temp-row">
              <span class="popup-icon">${data?.icon || "📍"}</span>
              <span class="popup-temp">${temp}</span>
              <span class="popup-cond">${cond}</span>
            </div>
            <div class="popup-stats">
              <span>💧 Humidity: <strong>${hum}</strong></span>
              <span>💨 Wind: <strong>${wind}</strong></span>
            </div>
            <button type="button" class="popup-btn" data-city="${city.name}">
              Select & Focus Telemetry
            </button>
          </div>
        `;
      }, { className: "custom-leaflet-popup" });

      this.markers.set(city.name.toLowerCase(), { marker, city });
    }
  }

  refreshMarkerStyles() {
    for (const [cityNameLower, { marker, city }] of this.markers.entries()) {
      const isSelected = this.selectedCityName && cityNameLower === this.selectedCityName.toLowerCase();
      const cached = this.cityWeatherData.get(cityNameLower);
      const tempVal = cached ? Math.round(cached.temp) : null;
      const tempText = tempVal != null ? `${tempVal}°` : "—";
      const iconText = cached ? cached.icon : "📍";
      const tempColor = this.getTempColor(tempVal);

      const icon = L.divIcon({
        className: "varsha-map-marker-container",
        html: `
          <div class="map-city-badge ${isSelected ? "selected" : ""}" data-city="${city.name}" style="--badge-accent: ${tempColor}">
            <span class="marker-pulse"></span>
            <span class="marker-icon">${iconText}</span>
            <span class="marker-name">${city.name}</span>
            <span class="marker-temp" style="color: ${tempColor}">${tempText}</span>
          </div>
        `,
        iconSize: [110, 34],
        iconAnchor: [55, 17],
      });

      marker.setIcon(icon);
      marker.setZIndexOffset(isSelected ? 1000 : 0);
    }
  }

  resetIndiaView() {
    this.selectedStateName = null;
    this.selectedDistrictId = null;
    if (this.districtLayer && this.map) { this.map.removeLayer(this.districtLayer); this.districtLayer = null; }
    if (this.pointMarker && this.map) { this.map.removeLayer(this.pointMarker); this.pointMarker = null; }
    this.refreshStateStyles();
    if (this.map) {
      this.map.flyTo([22.4, 80.0], 4.6, { duration: 1.0 });
    }
  }

  resize() {
    if (this.map) {
      this.map.invalidateSize();
    }
  }

  dispose() {
    if (this.map) {
      this.map.remove();
      this.map = null;
    }
    this.markers.clear();
    this._districtReq++;
    this.statesLayer = null;
    this.districtLayer = null;
  }
}
