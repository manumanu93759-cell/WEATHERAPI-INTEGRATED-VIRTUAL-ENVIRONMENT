import { parseWeatherPayload } from "./weather.js";

const PRESETS = {
  clear: {
    weather: [{ id: 800, main: "Clear", description: "clear sky" }],
    clouds: { all: 8 },
    visibility: 10000,
    main: { temp: 27, feels_like: 27, humidity: 42, pressure: 1014 },
    wind: { speed: 3.2, deg: 80 },
  },
  cloudy: {
    weather: [{ id: 803, main: "Clouds", description: "broken clouds" }],
    clouds: { all: 78 },
    visibility: 9000,
    main: { temp: 22, feels_like: 22, humidity: 61, pressure: 1011 },
    wind: { speed: 5.5, deg: 210 },
  },
  rain: {
    weather: [{ id: 500, main: "Rain", description: "light rain" }],
    clouds: { all: 88 },
    visibility: 5000,
    main: { temp: 19, feels_like: 19, humidity: 86, pressure: 1008 },
    wind: { speed: 6.4, deg: 240 },
  },
  thunderstorm: {
    weather: [{ id: 211, main: "Thunderstorm", description: "thunderstorm" }],
    clouds: { all: 97 },
    visibility: 3500,
    main: { temp: 21, feels_like: 21, humidity: 90, pressure: 1002 },
    wind: { speed: 11, deg: 260 },
  },
  fog: {
    weather: [{ id: 741, main: "Fog", description: "fog" }],
    clouds: { all: 55 },
    visibility: 700,
    main: { temp: 16, feels_like: 16, humidity: 94, pressure: 1016 },
    wind: { speed: 1.4, deg: 20 },
  },
  snow: {
    weather: [{ id: 601, main: "Snow", description: "snow" }],
    clouds: { all: 92 },
    visibility: 2500,
    main: { temp: -2, feels_like: -6, humidity: 88, pressure: 1010 },
    wind: { speed: 4.8, deg: 330 },
  },
};

function solarTimestamps(timeOfDay) {
  const now = Math.floor(Date.now() / 1000);
  if (timeOfDay === "night") {
    return {
      dt: now,
      sys: {
        sunrise: now - 14 * 3600,
        sunset: now - 2 * 3600,
        country: "IN",
      },
    };
  }
  return {
    dt: now,
    sys: {
      sunrise: now - 4 * 3600,
      sunset: now + 6 * 3600,
      country: "IN",
    },
  };
}

export function createDemoWeather({
  preset = "clear",
  timeOfDay = "day",
  windSpeed = 4,
  city = "Bengaluru",
} = {}) {
  const base = PRESETS[preset] || PRESETS.clear;
  const solar = solarTimestamps(timeOfDay);
  const payload = {
    name: city || "Bengaluru",
    timezone: 19800,
    ...solar,
    ...base,
    sys: { ...solar.sys, country: "IN" },
    wind: {
      speed: Number.isFinite(windSpeed) ? windSpeed : base.wind.speed,
      deg: base.wind.deg,
    },
  };
  return parseWeatherPayload(payload, "demo");
}

export const DEMO_PRESETS = Object.keys(PRESETS);
