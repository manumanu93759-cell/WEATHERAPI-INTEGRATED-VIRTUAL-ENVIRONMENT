import { INDIAN_STATES_AND_UTS } from "./data/indiaGeographicDb.js";
import { normalizeState } from "./utils/geoText.js";
import { LivePoller } from "./services/livePoller.js";
import { loadDistrictIndex, loadPlacesIndex } from "./services/geoData.js";
import { buildSearchIndex, searchPlaces, describeResult } from "./services/placeSearch.js";
import { IndiaWeatherMap } from "./components/indiaMap.js";
import indiaStatesGeoJSON from "./data/indiaStates.json";
import { createWeatherWorld } from "./scene.js";
import { EnvironmentController, activeEffects } from "./environment.js";
import { India3DGeoMap } from "./components/india3DMap.js";
import { WeatherAnalyticsChart } from "./components/weatherCharts.js";
import {
  INDIAN_CITIES,
  searchIndianCities,
  getCityByName,
  getPrimaryCityForState,
  findNearestIndianCity,
  isWithinIndia,
} from "./data/indianCities.js";
import {
  checkServerStatus,
  fetchLiveWeatherData,
  loadLastSelectedCity,
  saveLastSelectedCity,
  loadUserApiKey,
  saveUserApiKey,
  formatIST,
} from "./services/weatherService.js";
import {
  INDIAN_WEATHER_PRESETS,
  createSimulatedWeatherBundle,
  getIconForCondition,
} from "./services/demoWeather.js";

// DOM Elements Registry
const els = {
  // 3D Viewports
  sceneCanvas: document.getElementById("scene-canvas"),
  mapContainer: document.getElementById("india-3d-map-container"),
  primaryStage: document.getElementById("primary-stage"),

  // Search & Navigation
  citySearchInput: document.getElementById("city-search-input"),
  searchSuggestions: document.getElementById("search-suggestions"),
  geoBtn: document.getElementById("geo-btn"),
  quickChips: document.getElementById("quick-chips"),
  syncBadge: document.getElementById("sync-badge"),
  syncDot: document.getElementById("sync-dot"),
  syncStatusText: document.getElementById("sync-status-text"),
  refreshBtn: document.getElementById("refresh-btn"),
  configBtn: document.getElementById("config-btn"),

  // Topbar Selected City Pill
  topbarCityPill: document.getElementById("topbar-city-pill"),
  topbarCityName: document.getElementById("topbar-city-name"),
  topbarCityWeather: document.getElementById("topbar-city-weather"),

  // Direct Key Connection Bar
  userApiKeyInput: document.getElementById("user-api-key-input"),
  applyKeyBtn: document.getElementById("apply-key-btn"),
  clearKeyBtn: document.getElementById("clear-key-btn"),
  keyFeedback: document.getElementById("key-feedback"),
  modalApiKeyInput: document.getElementById("modal-api-key-input"),
  modalSaveKeyBtn: document.getElementById("modal-save-key-btn"),

  // Stage Floating HUD
  hudCity: document.getElementById("hud-city"),
  hudState: document.getElementById("hud-state"),
  hudTemp: document.getElementById("hud-temp"),
  hudIcon: document.getElementById("hud-icon"),
  hudCondition: document.getElementById("hud-condition"),
  hudFeels: document.getElementById("hud-feels"),
  hudHighLow: document.getElementById("hud-high-low"),
  hudSourceBadge: document.getElementById("hud-source-badge"),

  // Stage Controls
  stageTabs: document.querySelectorAll(".stage-mode-btn"),
  btnCamOrbit: document.getElementById("btn-cam-orbit"),
  btnCamHorizon: document.getElementById("btn-cam-horizon"),
  btnCamHimalaya: document.getElementById("btn-cam-himalaya"),
  btnCamSatellite: document.getElementById("btn-cam-satellite"),
  btnCamReset: document.getElementById("btn-cam-reset"),
  btnStagePause: document.getElementById("btn-stage-pause"),
  btnStageFullscreen: document.getElementById("btn-stage-fullscreen"),
  mapLayersGroup: document.getElementById("map-layers-group"),

  // Telemetry Cards
  telHumidity: document.getElementById("tel-humidity"),
  telHumidityNote: document.getElementById("tel-humidity-note"),
  telWind: document.getElementById("tel-wind"),
  telWindDir: document.getElementById("tel-wind-dir"),
  telPressure: document.getElementById("tel-pressure"),
  telVisibility: document.getElementById("tel-visibility"),
  telVisibilitySub: document.getElementById("tel-visibility-sub"),
  telClouds: document.getElementById("tel-clouds"),
  telPop: document.getElementById("tel-pop"),
  telRainRate: document.getElementById("tel-rain-rate"),
  telAqi: document.getElementById("tel-aqi"),
  telAqiBadge: document.getElementById("tel-aqi-badge"),
  telAqiSub: document.getElementById("tel-aqi-sub"),
  telSunrise: document.getElementById("tel-sunrise"),
  telSunset: document.getElementById("tel-sunset"),
  daylightProgress: document.getElementById("daylight-progress"),

  // Forecast & Advisories
  hourlyList: document.getElementById("hourly-forecast-list"),
  dailyList: document.getElementById("daily-forecast-list"),
  guidanceList: document.getElementById("guidance-list"),
  envSummary: document.getElementById("env-state-summary"),
  activeChips: document.getElementById("active-env-chips"),

  // Analytics Chart
  chartCanvas: document.getElementById("weather-analytics-chart"),

  // Demo Drawer
  demoDrawer: document.getElementById("demo-drawer"),
  demoPresets: document.getElementById("demo-presets"),
  demoDayBtn: document.getElementById("demo-day-btn"),
  demoNightBtn: document.getElementById("demo-night-btn"),

  // Notice Banner & Modal
  noticeBanner: document.getElementById("notice-banner"),
  noticeTitle: document.getElementById("notice-title"),
  noticeDesc: document.getElementById("notice-desc"),
  noticeDismiss: document.getElementById("notice-dismiss"),
  configModal: document.getElementById("config-modal"),
  modalCloseBtn: document.getElementById("modal-close-btn"),
  modalRecheckBtn: document.getElementById("modal-recheck-btn"),
  modalDemoBtn: document.getElementById("modal-demo-btn"),
  modalStatusText: document.getElementById("modal-status-text"),
  globalLoader: document.getElementById("global-loader"),
  loaderMsg: document.getElementById("loader-msg"),
};

// Application State
const state = {
  activeCityName: loadLastSelectedCity() || "New Delhi",
  activePresetKey: "sunny",
  isNight: false,
  mode: "demo", // 'live' | 'demo'
  hasServerKey: false,
  weather: null,
  activeStageMode: "map", // 'map' | 'world' | 'split'
  isPaused: false,
  allCitiesWeatherCache: new Map(),
  forceDemo: false,
  refreshSeconds: 60,
  activeLocation: null,
  requestGen: 0,
  demoOverrides: null,
  lastSuccessAt: null,
  lastChangeAt: null,
  lastFullAt: 0,
};
let poller = null;
let dmap = null;
let searchIndex = null;
let searchIndexPromise = null;

// Subsystem Instances
const controller = new EnvironmentController();
let world = null;
let map = null;
let chart = null;

// Helpers
function showNotice(title, desc, isError = false) {
  if (!els.noticeBanner) return;
  els.noticeTitle.textContent = title;
  els.noticeDesc.textContent = desc;
  els.noticeBanner.hidden = false;
  els.noticeBanner.style.borderColor = isError ? "var(--accent-rose)" : "var(--accent-cyan)";
}

function hideNotice() {
  if (els.noticeBanner) els.noticeBanner.hidden = true;
}

function setLoader(visible, msg = "Fetching weather intelligence…") {
  if (!els.globalLoader) return;
  els.loaderMsg.textContent = msg;
  els.globalLoader.hidden = !visible;
}

function setSyncStatus(kind, text) {
  if (!els.syncDot || !els.syncStatusText) return;
  els.syncDot.className = `sync-pulse-dot ${kind}`;
  els.syncStatusText.textContent = text;
}

// -------------------------------------------------------------
// UI Rendering
// -------------------------------------------------------------
function renderWeatherToUI(w) {
  if (!w) return;
  updateWxOverlay(w);

  // 1. Topbar City Pill
  if (els.topbarCityName) els.topbarCityName.textContent = w.city;
  if (els.topbarCityWeather) {
    els.topbarCityWeather.textContent = `${w.icon} ${Math.round(w.temp)}°C • ${capitalize(w.description || w.condition)}`;
  }

  // 2. Stage Floating HUD
  if (els.hudCity) els.hudCity.textContent = `${w.city}, India`;
  if (els.hudState) els.hudState.textContent = `${w.district && w.district !== w.city ? w.district + " district • " : ""}${w.state}`;
  const note = document.getElementById("location-note");
  if (note) {
    const pt = Number.isFinite(w.lat) ? `${w.lat.toFixed(2)}°N, ${w.lon.toFixed(2)}°E` : "";
    note.textContent = w.isDemo
      ? "SIMULATED demo values — not real weather."
      : `Current conditions at point ${pt}${w.stationName && w.stationName !== w.city ? ` (nearest provider station: ${w.stationName})` : ""}. One point does not represent a whole district.`;
  }
  if (els.hudTemp) els.hudTemp.textContent = `${Math.round(w.temp)}°`;
  if (els.hudIcon) els.hudIcon.textContent = w.icon;
  if (els.hudCondition) els.hudCondition.textContent = capitalize(w.description || w.condition);
  if (els.hudFeels) els.hudFeels.textContent = `Feels like ${Math.round(w.feelsLike)}°C`;
  if (els.hudHighLow) {
    els.hudHighLow.textContent = `H: ${Math.round(w.tempMax ?? w.temp)}° • L: ${Math.round(w.tempMin ?? w.temp)}°`;
  }

  if (els.hudSourceBadge) {
    if (w.isDemo) {
      els.hudSourceBadge.textContent = `SIMULATED: ${w.presetName || "DEMO"}`;
      els.hudSourceBadge.className = "source-badge demo";
    } else {
      els.hudSourceBadge.textContent = w.source === "server-cache" ? "CACHED TELEMETRY" : "LIVE SATELLITE FEED";
      els.hudSourceBadge.className = "source-badge live";
    }
  }

  // 3. Telemetry Cards
  if (els.telHumidity) els.telHumidity.textContent = w.humidity != null ? `${w.humidity}%` : "—";
  if (els.telHumidityNote && w.humidity != null) {
    els.telHumidityNote.textContent =
      w.humidity > 80 ? "Saturated Humidity" : w.humidity < 30 ? "Dry Desert Profile" : "Optimal Comfort";
  }

  const windMs = Number(w.windSpeed || 0);
  const kmh = Math.round(windMs * 3.6);
  if (els.telWind) els.telWind.textContent = `${windMs.toFixed(1)} m/s`;
  if (els.telWindDir) {
    els.telWindDir.textContent = `${kmh} km/h • ${Math.round(w.windDeg || 0)}° ${degToCompass(w.windDeg)}`;
  }

  if (els.telPressure) els.telPressure.textContent = w.pressure != null ? `${w.pressure} hPa` : "—";

  if (els.telVisibility) {
    els.telVisibility.textContent = w.visibility != null ? `${(w.visibility / 1000).toFixed(1)} km` : "—";
  }
  if (els.telVisibilitySub) {
    els.telVisibilitySub.textContent =
      w.visibility < 1500 ? "Restricted Range" : w.visibility < 5000 ? "Moderate Smog/Haze" : "Clear Visual Horizon";
  }

  if (els.telClouds) els.telClouds.textContent = `${Math.round(w.clouds || 0)}%`;
  if (els.telPop) els.telPop.textContent = `${w.pop || 0}%`;
  if (els.telRainRate) els.telRainRate.textContent = `${w.rain1h ? Number(w.rain1h).toFixed(1) : "0.0"} mm/h`;

  // Air Quality
  if (els.telAqi && els.telAqiBadge && els.telAqiSub) {
    if (w.airQuality) {
      els.telAqi.textContent = w.airQuality.label;
      els.telAqiBadge.textContent = `Index ${w.airQuality.aqi}`;
      els.telAqiBadge.className = `aqi-chip aqi-${["good", "fair", "mod", "poor", "severe"][w.airQuality.aqi - 1] || "mod"}`;
      const pm25 = w.airQuality.components?.pm2_5 ? Math.round(w.airQuality.components.pm2_5) : "—";
      const pm10 = w.airQuality.components?.pm10 ? Math.round(w.airQuality.components.pm10) : "—";
      els.telAqiSub.textContent = `PM2.5: ${pm25} µg/m³ • PM10: ${pm10} µg/m³`;
    } else {
      els.telAqi.textContent = "Data unavailable";
      els.telAqiBadge.textContent = "N/A";
      els.telAqiBadge.className = "aqi-chip";
      els.telAqiSub.textContent = "Sensor telemetry not provided";
    }
  }

  // Sunrise / Sunset & Solar Arc
  if (els.telSunrise && els.telSunset && els.daylightProgress) {
    if (w.sunrise && w.sunset) {
      const sRise = formatIST(w.sunrise, w.timezone);
      const sSet = formatIST(w.sunset, w.timezone);
      els.telSunrise.textContent = sRise.clock.replace(" IST", "");
      els.telSunset.textContent = sSet.clock.replace(" IST", "");

      const nowSec = Math.floor(Date.now() / 1000);
      const totalDay = w.sunset - w.sunrise;
      const elapsed = nowSec - w.sunrise;
      const progress = Math.max(0, Math.min(100, Math.round((elapsed / totalDay) * 100)));
      els.daylightProgress.style.width = `${progress}%`;
    } else {
      els.telSunrise.textContent = "06:10";
      els.telSunset.textContent = "18:15";
      els.daylightProgress.style.width = "50%";
    }
  }

  // 4. Hourly Forecast
  renderHourlyForecast(w.hourly || []);

  // 5. Daily Forecast
  renderDailyForecast(w.daily || []);

  // 6. Guidance & Advisories
  renderGuidance(w.guidance || []);

  // 7. Update Analytics Chart
  if (chart) chart.updateData(w);

  // 8. Update 3D India Map with City Data
  state.allCitiesWeatherCache.set(w.city.toLowerCase(), w);
  if (map) {
    map.selectedCityName = w.city;
    map.selectedStateName = w.state;
    map.refreshSelections();
    map.updateCityWeather(state.allCitiesWeatherCache);
  }
}

function renderHourlyForecast(hourly) {
  if (!els.hourlyList) return;
  els.hourlyList.innerHTML = "";
  if (!hourly || hourly.length === 0) {
    els.hourlyList.innerHTML = `<p class="source-note">Hourly forecast telemetry unavailable.</p>`;
    return;
  }

  for (const h of hourly) {
    const div = document.createElement("div");
    div.className = "hourly-card";
    div.innerHTML = `
      <span class="hourly-time">${h.time}</span>
      <span class="hourly-icon">${h.icon}</span>
      <strong class="hourly-temp">${h.temp}°</strong>
      <span class="hourly-pop">💧 ${h.pop}%</span>
    `;
    els.hourlyList.appendChild(div);
  }
}

function renderDailyForecast(daily) {
  if (!els.dailyList) return;
  els.dailyList.innerHTML = "";
  if (!daily || daily.length === 0) {
    els.dailyList.innerHTML = `<p class="source-note">Daily outlook telemetry unavailable.</p>`;
    return;
  }

  for (const d of daily) {
    const div = document.createElement("div");
    div.className = "daily-row";
    div.innerHTML = `
      <div class="daily-day-meta">
        <span class="daily-day-name">${d.dayName}</span>
        <span class="daily-date">${d.dateStr}</span>
      </div>
      <div class="daily-condition">
        <span class="daily-icon">${d.icon}</span>
        <span class="daily-cond-text">${capitalize(d.description || d.weatherMain)}</span>
      </div>
      <div class="daily-temp-bar-wrap">
        <span class="daily-pop-badge">💧 ${d.pop}%</span>
        <span class="daily-min">${d.tempMin}°</span>
        <strong class="daily-max">${d.tempMax}°</strong>
      </div>
    `;
    els.dailyList.appendChild(div);
  }
}

function renderGuidance(guidance) {
  if (!els.guidanceList) return;
  els.guidanceList.innerHTML = "";
  if (!guidance || guidance.length === 0) {
    els.guidanceList.innerHTML = `<p class="source-note">No severe meteorological advisories active for this sector.</p>`;
    return;
  }

  for (const g of guidance) {
    const div = document.createElement("div");
    div.className = `guidance-item guidance-${g.level || "info"}`;
    div.innerHTML = `
      <div>
        <strong class="guidance-title">${g.title}</strong>
        <span>${g.text}</span>
      </div>
    `;
    els.guidanceList.appendChild(div);
  }
}

function renderIntelligenceText() {
  if (!els.envSummary || !els.activeChips) return;
  const env = controller.current;
  els.envSummary.textContent = `Atmosphere: ${controller.phase.toUpperCase()} • ${controller.group.toUpperCase()} • Clouds ${Math.round(env.cloudDensity * 100)}% • Wind ${(env.windSpeed * 3.6).toFixed(0)} km/h`;

  const chips = activeEffects(env);
  els.activeChips.innerHTML = chips
    .map((c) => `<span class="env-chip">${c}</span>`)
    .join("");
}

// -------------------------------------------------------------
// Weather Application Logic
// -------------------------------------------------------------
function resolveCityLoc(name) {
  const c = getCityByName(name);
  return c ? { name: c.name, state: c.state, lat: c.lat, lon: c.lon, kind: "city" } : { name, kind: "city" };
}

async function loadCityWeather(cityName, opts = {}) {
  const trimmed = (cityName || "").trim();
  if (!trimmed) return;
  return selectLocation(resolveCityLoc(trimmed), opts);
}

function hasLiveSource() {
  return !!(state.hasServerKey || loadUserApiKey());
}

/** Select any location (state capital, district point, city, town) and load weather for its coordinates. */
async function selectLocation(loc, { silent = false, skipMap = false } = {}) {
  if (!loc || !loc.name) return;
  state.activeLocation = loc;
  state.activeCityName = loc.name;
  saveLastSelectedCity(loc.name);
  updateActiveCityChip(loc.name);
  if (els.citySearchInput && document.activeElement !== els.citySearchInput) {
    els.citySearchInput.value = loc.name;
  }
  if (map && getCityByName(loc.name)) map.focusCity(loc.name);
  if (dmap && !skipMap && loc.lat != null) dmap.setPointMarker(loc.lat, loc.lon, loc.name);

  const gen = ++state.requestGen; // invalidates every older in-flight request

  if (state.forceDemo || !hasLiveSource()) {
    poller?.stop();
    switchToDemoForLocation(loc);
    return;
  }

  if (!silent) {
    setLoader(true, `Fetching weather for ${loc.name}…`);
    setSyncStatus("loading", "Fetching weather…");
  }
  try {
    const weather = decorateLive(await fetchLiveWeatherData(liveArgs(loc, { full: true })), loc);
    if (gen !== state.requestGen || state.forceDemo) return; // stale or demo took over
    acceptLiveWeather(weather, { fresh: true });
    state.lastFullAt = Date.now();
    hideNotice();
    startPolling();
  } catch (err) {
    if (gen !== state.requestGen || state.forceDemo) return;
    if (err.code === "KEY_MISSING") {
      state.hasServerKey = false;
      switchToDemoForLocation(loc, "OpenWeather key missing. Showing SIMULATED demo data — set OPENWEATHER_API_KEY for live weather.");
    } else {
      showNotice("Live weather unavailable", `${err.message || "Failed to reach weather server"}. Showing simulated demo data, which is NOT real weather.`, true);
      setSyncStatus("error", "Live unavailable — demo data");
      switchToDemoForLocation(loc);
    }
  } finally {
    if (gen === state.requestGen) setLoader(false);
  }
}

function liveArgs(loc, { full, signal } = {}) {
  const hasCoords = Number.isFinite(loc.lat) && Number.isFinite(loc.lon);
  return { city: hasCoords ? undefined : loc.name, lat: hasCoords ? loc.lat : undefined, lon: hasCoords ? loc.lon : undefined, apiKey: loadUserApiKey(), signal, skipSecondary: !full };
}

/** Label the weather with the user's selected location (the API's own station name is kept separately). */
function decorateLive(w, loc) {
  w.stationName = w.city;
  w.city = loc.name;
  if (loc.state) w.state = loc.state;
  w.district = loc.district || null;
  w.locationKind = loc.kind || "city";
  return w;
}

function weatherSignature(w) {
  return [w.dt, w.temp, w.humidity, w.windSpeed, w.pressure, w.clouds, w.weatherId].join("|");
}

function acceptLiveWeather(w, { fresh = false } = {}) {
  const prev = state.weather;
  if (!w.hasSecondary && prev && prev.source !== "demo" && prev.city === w.city) {
    Object.assign(w, { hourly: prev.hourly, daily: prev.daily, airQuality: prev.airQuality, guidance: prev.guidance, pop: prev.pop });
  }
  const changed = !prev || prev.isDemo || weatherSignature(prev) !== weatherSignature(w);
  state.weather = w;
  state.mode = "live";
  state.lastSuccessAt = Date.now();
  if (changed) state.lastChangeAt = state.lastSuccessAt;
  setDemoUI(false);
  if (changed || fresh) {
    applyWeatherToWorld(w);
    renderWeatherToUI(w);
  }
  updateLiveStatus(changed);
}

function fmtClock(ms) {
  return new Date(ms).toLocaleTimeString("en-IN", { hour12: false, timeZone: "Asia/Kolkata" });
}

function updateLiveStatus(changed) {
  if (state.mode !== "live" || !state.lastSuccessAt) return;
  const stale = Date.now() - state.lastSuccessAt > Math.max(30000, state.refreshSeconds * 3000 || 0);
  const w = state.weather;
  const obs = w?.observedAt ? ` • provider observation ${fmtClock(w.observedAt)} IST` : "";
  if (stale) {
    setSyncStatus("error", `STALE — last successful fetch ${fmtClock(state.lastSuccessAt)} IST`);
  } else {
    const note = changed === undefined ? "" : changed ? " • new data" : " • unchanged since last fetch";
    setSyncStatus("live", `Live: ${w.city} • fetched ${fmtClock(state.lastSuccessAt)} IST${note}${obs}`);
  }
}

function startPolling() {
  if (!poller) {
    poller = new LivePoller({
      intervalMs: Math.max(5, state.refreshSeconds || 60) * 1000,
      fetchFn: async (signal) => {
        const loc = state.activeLocation;
        const needFull = Date.now() - state.lastFullAt > 10 * 60 * 1000;
        const w = decorateLive(await fetchLiveWeatherData(liveArgs(loc, { full: needFull, signal })), loc);
        if (needFull) state.lastFullAt = Date.now();
        return w;
      },
      onResult: (w) => {
        if (state.forceDemo || state.mode !== "live") return; // demo values are never overwritten
        acceptLiveWeather(w);
      },
      onError: (err, { failures, nextInMs }) => {
        if (failures === 1 || failures % 10 === 0) console.warn(`[VARSHA] live refresh failed (${failures}x): ${err.message}; retry in ${Math.round(nextInMs / 1000)}s`);
        updateLiveStatus();
      },
    });
  }
  if (!state.refreshSeconds) { poller.stop(); return; }
  poller.setInterval(state.refreshSeconds * 1000);
  poller.start({ immediate: false });
}

// -------------------------------------------------------------
// Demo mode (independent of live data) + refresh controls
// -------------------------------------------------------------
const DEMO_PRESETS = {
  clear:        { cond: "800|Clear|clear sky",                 temp: 29, humidity: 40, wind: 3,  clouds: 5,  rain: 0,  fog: 0,  night: false },
  partly:       { cond: "802|Clouds|scattered clouds",         temp: 27, humidity: 55, wind: 4,  clouds: 40, rain: 0,  fog: 0,  night: false },
  overcast:     { cond: "804|Clouds|overcast clouds",          temp: 24, humidity: 70, wind: 5,  clouds: 95, rain: 0,  fog: 5,  night: false },
  lightrain:    { cond: "500|Rain|light rain",                 temp: 23, humidity: 82, wind: 5,  clouds: 85, rain: 1,  fog: 10, night: false },
  heavyrain:    { cond: "502|Rain|heavy intensity rain",       temp: 22, humidity: 94, wind: 9,  clouds: 100, rain: 18, fog: 25, night: false },
  thunderstorm: { cond: "211|Thunderstorm|thunderstorm",       temp: 24, humidity: 90, wind: 12, clouds: 100, rain: 8,  fog: 20, night: false },
  fog:          { cond: "741|Fog|fog",                         temp: 14, humidity: 96, wind: 1,  clouds: 60, rain: 0,  fog: 85, night: false },
  night:        { cond: "800|Clear|clear sky",                 temp: 22, humidity: 55, wind: 2,  clouds: 5,  rain: 0,  fog: 0,  night: true },
};

function readDemoEditor() {
  const num = (id, lo, hi) => { const v = parseFloat(document.getElementById(id)?.value); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : null; };
  return {
    cond: document.getElementById("de-cond")?.value || "800|Clear|clear sky",
    temp: num("de-temp", -40, 55), humidity: num("de-humidity", 0, 100), wind: num("de-wind", 0, 60),
    pressure: num("de-pressure", 900, 1100), clouds: num("de-clouds", 0, 100), rain: num("de-rain", 0, 100), fog: num("de-fog", 0, 100),
  };
}

function writeDemoEditor(o) {
  const set = (id, v) => { const el = document.getElementById(id); if (el && v != null) el.value = v; };
  set("de-cond", o.cond); set("de-temp", o.temp); set("de-humidity", o.humidity); set("de-wind", o.wind);
  set("de-pressure", o.pressure); set("de-clouds", o.clouds); set("de-rain", o.rain); set("de-fog", o.fog);
}

function applyDemoOverrides(w, o) {
  const [id, main, desc] = o.cond.split("|");
  const pick = (v, fb) => (v == null ? fb : v);
  w.temp = pick(o.temp, w.temp); w.feelsLike = w.temp;
  w.humidity = pick(o.humidity, w.humidity); w.windSpeed = pick(o.wind, w.windSpeed);
  w.pressure = pick(o.pressure, w.pressure); w.clouds = pick(o.clouds, w.clouds);
  w.weatherId = Number(id); w.condition = main; w.description = desc;
  w.rain1h = pick(o.rain, 0);
  w.visibility = o.fog == null ? w.visibility : Math.max(50, Math.round(10000 * (1 - o.fog / 100)));
  w.icon = getIconForCondition(w.weatherId, state.isNight);
  w.presetId = "custom"; w.presetName = "Custom demo";
  return w;
}

function buildDemoWeather(loc) {
  const w = createSimulatedWeatherBundle({ presetKey: state.activePresetKey, cityName: loc?.name || state.activeCityName, isNight: state.isNight });
  if (loc) { w.city = loc.name; if (loc.state) w.state = loc.state; if (Number.isFinite(loc.lat)) { w.lat = loc.lat; w.lon = loc.lon; } w.district = loc.district || null; }
  if (state.demoOverrides) applyDemoOverrides(w, state.demoOverrides);
  w.source = "demo"; w.isDemo = true;
  return w;
}

function setDemoUI(active) {
  const editor = document.getElementById("demo-editor");
  if (editor) editor.hidden = !active;
  const btn = document.getElementById("force-demo-btn");
  if (btn) {
    btn.textContent = state.forceDemo ? "Demo ON — return to live" : active ? "Demo (no live key)" : "Demo: off";
    btn.setAttribute("aria-pressed", String(state.forceDemo));
    btn.classList.toggle("active", state.forceDemo);
  }
  document.body.classList.toggle("is-demo-mode", active);
}

function switchToDemoForLocation(loc, bannerMsg = null) {
  poller?.stop();
  state.mode = "demo";
  const weather = buildDemoWeather(loc || state.activeLocation);
  state.weather = weather;
  applyWeatherToWorld(weather);
  renderWeatherToUI(weather);
  setDemoUI(true);
  if (!document.activeElement || !document.activeElement.closest?.("#demo-editor")) {
    writeDemoEditor(state.demoOverrides || { cond: `${weather.weatherId}|${weather.condition}|${weather.description}`, temp: weather.temp, humidity: weather.humidity, wind: weather.windSpeed, pressure: weather.pressure, clouds: weather.clouds, rain: weather.rain1h || 0, fog: Math.round((1 - Math.min(1, (weather.visibility ?? 10000) / 10000)) * 100) });
  }
  setSyncStatus("demo", `SIMULATED • ${weather.presetName}`);
  if (bannerMsg) showNotice("Simulated data", bannerMsg, false);
}
function switchToDemoForCity(cityName, bannerMsg = null) { switchToDemoForLocation(state.activeLocation || resolveCityLoc(cityName), bannerMsg); }


// -------------------------------------------------------------
// Cinematic world overlay: card, IST clock, demo/live selector
// -------------------------------------------------------------
function updateWxOverlay(w) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set("wx-city", `${w.city}${w.state ? ", " + w.state : ""}`);
  set("wx-icon", w.icon || "☀️");
  set("wx-temp", `${Math.round(w.temp)}°C`);
  set("wx-cond", capitalize(w.description || w.condition || ""));
  set("wx-hum", w.humidity != null ? `${w.humidity}%` : "—");
  set("wx-wind", w.windSpeed != null ? `${Math.round(w.windSpeed * 3.6)} km/h` : "—");
  set("wx-pres", w.pressure != null ? `${w.pressure} hPa` : "—");
  const src = document.getElementById("wx-src");
  if (src) { src.textContent = w.isDemo ? "DEMO" : "LIVE"; src.classList.toggle("demo", !!w.isDemo); }
  syncPresetHighlight();
}

function syncPresetHighlight() {
  const demoOn = state.mode === "demo";
  const key = demoOn && !state.demoOverrides ? state.activePresetKey : null;
  document.querySelectorAll("#wx-selector .wx-btn[data-preset], #demo-presets .preset-pill[data-preset]").forEach((b) => {
    b.classList.toggle("active", b.dataset.preset === key);
    b.setAttribute("aria-pressed", String(b.dataset.preset === key));
  });
  const liveOn = state.mode === "live" && !state.forceDemo;
  document.getElementById("wx-live-btn")?.classList.toggle("active", liveOn);
  document.getElementById("demo-live-btn")?.classList.toggle("active", liveOn);
}

function tickWxClock() {
  const now = new Date();
  const t = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: false }).format(now);
  const d = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", year: "numeric" }).format(now);
  const a = document.getElementById("wx-time"), b = document.getElementById("wx-date");
  if (a) a.textContent = t;
  if (b) b.textContent = `${d} IST`;
}

function setForceDemo(on) {
  state.forceDemo = on;
  state.requestGen++; // drop any in-flight live request
  if (on) {
    poller?.stop();
    switchToDemoForLocation(state.activeLocation || resolveCityLoc(state.activeCityName));
  } else {
    setDemoUI(false);
    if (!hasLiveSource()) {
      state.forceDemo = false; state.mode = "demo";
      showNotice("Live weather not configured", "Set OPENWEATHER_API_KEY on the server (or paste a key in settings) to use live mode.", true);
      switchToDemoForLocation(state.activeLocation);
    } else {
      selectLocation(state.activeLocation || resolveCityLoc(state.activeCityName), { skipMap: true });
    }
  }
  syncPresetHighlight();
}

function activateDemoPreset(key) {
  if (!key) return;
  state.activePresetKey = key;
  state.demoOverrides = null;
  state.isNight = false;
  els.demoDayBtn?.classList.add("active"); els.demoNightBtn?.classList.remove("active");
  if (state.activeStageMode !== "world" && state.activeStageMode !== "split") setStageMode("split"); // make the effect visible
  if (state.forceDemo) switchToDemoForLocation(state.activeLocation || resolveCityLoc(state.activeCityName));
  else setForceDemo(true); // manual selection always takes over from live data
}

function setupAutoRefreshAndDemoEditor() {
  const sel = document.getElementById("refresh-interval");
  state.refreshSeconds = Number(sel?.value) || 0;
  sel?.addEventListener("change", () => {
    state.refreshSeconds = Number(sel.value) || 0;
    if (state.mode === "live" && !state.forceDemo) startPolling();
    if (!state.refreshSeconds) poller?.stop();
  });
  // stale-data indicator (no network use)
  setInterval(() => { if (state.mode === "live") updateLiveStatus(); }, 2000);

  document.getElementById("force-demo-btn")?.addEventListener("click", () => setForceDemo(!state.forceDemo));

  const applyEditor = () => {
    if (state.mode !== "demo" || !state.weather) return;
    state.demoOverrides = readDemoEditor();
    const w = buildDemoWeather(state.activeLocation);
    state.weather = w;
    applyWeatherToWorld(w);
    renderWeatherToUI(w);
    setSyncStatus("demo", "SIMULATED • Custom demo");
  };
  const editor = document.getElementById("demo-editor");
  editor?.addEventListener("input", applyEditor);
  editor?.addEventListener("change", applyEditor);
  document.getElementById("de-preset")?.addEventListener("change", (e) => {
    const p = DEMO_PRESETS[e.target.value]; if (!p) return;
    state.isNight = p.night;
    els.demoDayBtn?.classList.toggle("active", !p.night); els.demoNightBtn?.classList.toggle("active", p.night);
    const pressure = p.cond.startsWith("211") ? 1002 : p.rain > 5 ? 1006 : 1013;
    state.demoOverrides = { ...p, pressure };
    writeDemoEditor(state.demoOverrides);
    if (state.mode !== "demo") return; // presets only apply while demo is active
    applyEditor();
  });
}

function applyWeatherToWorld(weather, snap = false) {
  controller.applyWeather(weather, { snap });
  if (world) {
    world.applyEnvironment(controller.current);
  }
  renderIntelligenceText();
}

// -------------------------------------------------------------
// Quick Chips & Search Autocomplete
// -------------------------------------------------------------
function buildQuickChips() {
  if (!els.quickChips) return;
  const featured = INDIAN_CITIES.filter((c) => c.featured);
  els.quickChips.innerHTML = "";

  for (const city of featured) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `city-chip ${city.name.toLowerCase() === state.activeCityName.toLowerCase() ? "active" : ""}`;
    btn.textContent = city.name;
    btn.dataset.city = city.name;
    btn.addEventListener("click", () => {
      loadCityWeather(city.name, { force: true });
    });
    els.quickChips.appendChild(btn);
  }
}

function updateActiveCityChip(cityName) {
  if (!els.quickChips) return;
  for (const chip of els.quickChips.querySelectorAll(".city-chip")) {
    chip.classList.toggle("active", chip.dataset.city.toLowerCase() === cityName.toLowerCase());
  }
}

function showMapError(msg) {
  const el = document.getElementById("district-map-error");
  if (!el) return;
  el.textContent = msg; el.hidden = false;
  clearTimeout(showMapError.t); showMapError.t = setTimeout(() => { el.hidden = true; }, 9000);
}
function setCrumb(t) { const c = document.getElementById("district-crumb"); if (c) c.textContent = t; }
function populateDistrictSelect(stateName, list) {
  const sel = document.getElementById("district-select"); if (!sel) return;
  sel.innerHTML = `<option value="">${stateName ? `Districts in ${stateName} (${list.length})` : "Select a state, then a district…"}</option>` +
    [...list].sort((a, b) => a.name.localeCompare(b.name)).map((d) => `<option value="${d.id}">${d.name}</option>`).join("");
  sel.disabled = !list.length;
}
async function onMapStateSelected(stateName) {
  setCrumb(stateName);
  const cap = getPrimaryCityForState(stateName);
  if (cap) selectLocation({ ...resolveCityLoc(cap.name), kind: "capital" }, { skipMap: true });
  const list = await dmap.showDistricts(stateName);
  if (list && dmap.districtState === stateName) { populateDistrictSelect(stateName, list); setCrumb(`${stateName} • ${list.length} districts`); }
}
async function ensureSearchIndex() {
  if (searchIndex) return searchIndex;
  searchIndexPromise ||= Promise.all([loadDistrictIndex(), loadPlacesIndex()]).then(([districts, places]) => {
    const states = INDIAN_STATES_AND_UTS.map((x) => ({ name: x.name, lat: x.lat, lon: x.lon, bbox: x.bbox }));
    searchIndex = buildSearchIndex({ states, districts, places });
    return searchIndex;
  }).catch((e) => { searchIndexPromise = null; throw e; });
  return searchIndexPromise;
}
async function chooseResult(r) {
  const loc = r.kind === "state"
    ? { ...resolveCityLoc(getPrimaryCityForState(r.name)?.name || r.name), kind: "capital" }
    : { name: r.name, state: r.state, district: r.district || (r.kind === "district" ? r.name : undefined), lat: r.lat, lon: r.lon, kind: r.kind };
  if (r.kind === "state") { loc.state = r.name; }
  setStageMode("districts");
  dmap?.focusResult(r).then(async () => {
    const st = r.kind === "state" ? r.name : r.state;
    const list = (await ensureSearchIndex()).filter((i) => i.kind === "district" && normalizeState(i.state) === normalizeState(st));
    populateDistrictSelect(st, list);
    const w = describeResult(r).where;
    setCrumb(w === "India" ? `${r.name} • ${list.length} districts` : `${r.name} • ${w}`);
  });
  await selectLocation(loc, { skipMap: true });
}

function setupSearch() {
  if (!els.citySearchInput || !els.searchSuggestions) return;
  let debounceTimer = null;
  let highlightedIndex = -1;
  let currentResults = [];

  function clearSuggestions() {
    els.searchSuggestions.hidden = true;
    els.searchSuggestions.innerHTML = "";
    highlightedIndex = -1;
  }

  els.citySearchInput.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    const q = els.citySearchInput.value.trim();
    if (!q) {
      clearSuggestions();
      return;
    }

    debounceTimer = setTimeout(async () => {
      let results;
      try { results = searchPlaces(await ensureSearchIndex(), q, 8); }
      catch (e) { results = searchIndianCities(q, 8).map((c) => ({ kind: "city", name: c.name, state: c.state, lat: c.lat, lon: c.lon })); }
      if (els.citySearchInput.value.trim() !== q) return; // stale
      currentResults = results;
      if (results.length === 0) {
        els.searchSuggestions.innerHTML = `<div class="suggestion-item"><span class="suggestion-city">No supported Indian place matches “${q.replace(/[<>&"]/g, "")}”. Try a district, city or state name.</span></div>`;
        els.searchSuggestions.hidden = false;
        return;
      }
      els.searchSuggestions.innerHTML = results.map((r, idx) => {
        const d = describeResult(r);
        return `<div class="suggestion-item" data-index="${idx}" data-city="${r.name.replace(/"/g, "&quot;")}"><div><span class="suggestion-city">${r.name}</span> <span class="suggestion-state">${d.where}</span></div><span class="suggestion-region">${d.kind}</span></div>`;
      }).join("");
      els.searchSuggestions.hidden = false;
      highlightedIndex = -1;
    }, 200);
  });

  els.searchSuggestions.addEventListener("click", (e) => {
    const item = e.target.closest(".suggestion-item");
    if (!item || item.dataset.index == null) return;
    const r = currentResults[Number(item.dataset.index)];
    if (!r) return;
    els.citySearchInput.value = r.name;
    clearSuggestions();
    chooseResult(r);
  });

  els.citySearchInput.addEventListener("keydown", (e) => {
    const items = els.searchSuggestions.querySelectorAll(".suggestion-item");
    if (items.length === 0 || els.searchSuggestions.hidden) {
      if (e.key === "Enter") {
        e.preventDefault();
        const val = els.citySearchInput.value.trim();
        if (val) {
          clearSuggestions();
          loadCityWeather(val, { force: true });
        }
      }
      return;
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      highlightedIndex = (highlightedIndex + 1) % items.length;
      items.forEach((it, i) => it.classList.toggle("highlighted", i === highlightedIndex));
      items[highlightedIndex]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      highlightedIndex = (highlightedIndex - 1 + items.length) % items.length;
      items.forEach((it, i) => it.classList.toggle("highlighted", i === highlightedIndex));
      items[highlightedIndex]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (highlightedIndex >= 0 && items[highlightedIndex]) {
        const r = currentResults[Number(items[highlightedIndex].dataset.index)];
        if (r) {
          els.citySearchInput.value = r.name;
          clearSuggestions();
          chooseResult(r);
        }
      }
    } else if (e.key === "Escape") {
      clearSuggestions();
    }
  });

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".search-cluster")) {
      clearSuggestions();
    }
  });

  // Geolocation Button (Bounded to India)
  if (els.geoBtn) {
    els.geoBtn.addEventListener("click", () => {
      if (!navigator.geolocation) {
        showNotice("Geolocation Unavailable", "Browser does not support geolocation.", true);
        return;
      }

      setLoader(true, "Detecting location in India…");
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLoader(false);
          const { latitude, longitude } = pos.coords;
          if (!isWithinIndia(latitude, longitude)) {
            showNotice(
              "Location Outside India",
              `Detected coordinates (${latitude.toFixed(2)}, ${longitude.toFixed(2)}) are outside India. VARSHA focuses exclusively on Indian territory.`,
              true
            );
            return;
          }
          const nearest = findNearestIndianCity(latitude, longitude);
          showNotice("Location Detected", `Nearest Indian city identified: ${nearest.name}, ${nearest.state}.`);
          loadCityWeather(nearest.name, { force: true });
        },
        (err) => {
          setLoader(false);
          showNotice(
            "Location Access Required",
            "Could not retrieve location. Please choose a city from search or quick chips.",
            false
          );
        },
        { timeout: 8000 }
      );
    });
  }
}

// -------------------------------------------------------------
// Stage View Mode Switching (3D Map vs 3D World vs Split)
// -------------------------------------------------------------
function setStageMode(mode) {
  state.activeStageMode = mode;

  // Update tabs
  els.stageTabs.forEach((tab) => {
    const isActive = tab.dataset.mode === mode;
    tab.classList.toggle("active", isActive);
    tab.setAttribute("aria-pressed", isActive ? "true" : "false");
  });

  // Toggle canvas visibility / split layout
  if (els.primaryStage) {
    els.primaryStage.className = `primary-stage mode-${mode}`;
  }

  setTimeout(() => {
    if (world) world.resize();
    if (map) map.onResize();
    if (dmap) dmap.resize();
  }, 100);
}

function setupStageTabs() {
  els.stageTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      setStageMode(tab.dataset.mode);
    });
  });
}

// -------------------------------------------------------------
// Demo Presets & Scenario Controls
// -------------------------------------------------------------
function setupDemoControls() {
  const onPick = (e) => {
    const btn = e.target.closest("[data-preset]");
    if (btn) activateDemoPreset(btn.dataset.preset);
  };
  els.demoPresets?.addEventListener("click", onPick);
  document.getElementById("wx-selector")?.addEventListener("click", onPick);
  const goLive = () => { if (state.mode === "demo" || state.forceDemo) setForceDemo(false); };
  document.getElementById("demo-live-btn")?.addEventListener("click", goLive);
  document.getElementById("wx-live-btn")?.addEventListener("click", goLive);

  const setTod = (night) => {
    state.isNight = night;
    els.demoDayBtn?.classList.toggle("active", !night);
    els.demoNightBtn?.classList.toggle("active", night);
    if (state.mode === "demo" && state.forceDemo) switchToDemoForLocation(state.activeLocation);
    else if (state.mode === "live") { state.isNight = night; setForceDemo(true); }
    else switchToDemoForLocation(state.activeLocation);
  };
  els.demoDayBtn?.addEventListener("click", () => setTod(false));
  els.demoNightBtn?.addEventListener("click", () => setTod(true));
  tickWxClock();
  setInterval(tickWxClock, 15000);
}

// -------------------------------------------------------------
// Camera Controls, Overlays & Fullscreen
// -------------------------------------------------------------
function setupStageControls() {
  // Camera perspective buttons
  if (els.btnCamOrbit) {
    els.btnCamOrbit.addEventListener("click", () => {
      if (state.activeStageMode === "map" && map) map.resetCamera();
      else if (world) world.setCameraPreset("cinematic");
    });
  }

  if (els.btnCamHorizon) {
    els.btnCamHorizon.addEventListener("click", () => {
      if (state.activeStageMode === "map" && map) map.setPerspective("horizon");
      else if (world) world.setCameraPreset("horizon");
    });
  }

  if (els.btnCamHimalaya) {
    els.btnCamHimalaya.addEventListener("click", () => {
      if (state.activeStageMode === "map" && map) map.focusCity("Shimla");
      else if (world) world.setCameraPreset("himalaya");
    });
  }

  if (els.btnCamSatellite) {
    els.btnCamSatellite.addEventListener("click", () => {
      if (state.activeStageMode === "map" && map) map.setPerspective("topdown");
      else if (world) world.setCameraPreset("satellite");
    });
  }

  if (els.btnCamReset) {
    els.btnCamReset.addEventListener("click", () => {
      if (map) map.resetCamera();
      if (world) world.setCameraPreset("cinematic");
    });
  }

  // Pause / Resume animation
  if (els.btnStagePause) {
    els.btnStagePause.addEventListener("click", () => {
      state.isPaused = !state.isPaused;
      els.btnStagePause.textContent = state.isPaused ? "▶ Resume" : "⏸ Pause";
      if (world) world.setPaused(state.isPaused);
    });
  }

  // Fullscreen Mode
  if (els.btnStageFullscreen && els.primaryStage) {
    els.btnStageFullscreen.addEventListener("click", () => {
      if (!document.fullscreenElement) {
        els.primaryStage.requestFullscreen?.().catch(() => {});
        els.btnStageFullscreen.textContent = "↙ Normal";
      } else {
        document.exitFullscreen?.().catch(() => {});
        els.btnStageFullscreen.textContent = "⛶ Fullscreen";
      }
    });
  }

  // 3D Map Overlay Layer Buttons
  document.querySelectorAll(".layer-btn").forEach((lBtn) => {
    lBtn.addEventListener("click", () => {
      document.querySelectorAll(".layer-btn").forEach((b) => b.classList.remove("active"));
      lBtn.classList.add("active");
      if (map) {
        map.setOverlay(lBtn.dataset.layer);
      }
    });
  });

  if (els.refreshBtn) {
    els.refreshBtn.addEventListener("click", () => {
      loadCityWeather(state.activeCityName, { force: true });
    });
  }

  if (els.noticeDismiss) {
    els.noticeDismiss.addEventListener("click", hideNotice);
  }

  // Modal setup
  if (els.configBtn && els.configModal) {
    els.configBtn.addEventListener("click", () => {
      els.configModal.hidden = false;
      recheckServerStatus();
    });
  }
  if (els.modalCloseBtn && els.configModal) {
    els.modalCloseBtn.addEventListener("click", () => {
      els.configModal.hidden = true;
    });
  }
  if (els.modalDemoBtn && els.configModal) {
    els.modalDemoBtn.addEventListener("click", () => {
      els.configModal.hidden = true;
    });
  }
  if (els.modalRecheckBtn) {
    els.modalRecheckBtn.addEventListener("click", async () => {
      await recheckServerStatus();
    });
  }

  // Direct Key Insertion Handlers
  if (els.applyKeyBtn) {
    els.applyKeyBtn.addEventListener("click", () => {
      connectApiKey(els.userApiKeyInput.value);
    });
  }
  if (els.userApiKeyInput) {
    els.userApiKeyInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        connectApiKey(els.userApiKeyInput.value);
      }
    });
  }
  if (els.clearKeyBtn) {
    els.clearKeyBtn.addEventListener("click", clearApiKey);
  }
  if (els.modalSaveKeyBtn) {
    els.modalSaveKeyBtn.addEventListener("click", () => {
      connectApiKey(els.modalApiKeyInput.value);
    });
  }

  // Chart Tab switching
  document.querySelectorAll(".chart-tab").forEach((tabBtn) => {
    tabBtn.addEventListener("click", () => {
      document.querySelectorAll(".chart-tab").forEach((b) => b.classList.remove("active"));
      tabBtn.classList.add("active");
      if (chart) chart.setTab(tabBtn.dataset.tab);
    });
  });
}

async function connectApiKey(apiKeyToUse = null) {
  const key = (
    apiKeyToUse ||
    (els.userApiKeyInput ? els.userApiKeyInput.value : "") ||
    (els.modalApiKeyInput ? els.modalApiKeyInput.value : "")
  ).trim();

  if (!key) {
    if (els.keyFeedback) {
      els.keyFeedback.textContent = "Please enter an OpenWeather API key first.";
      els.keyFeedback.className = "key-feedback error";
    }
    showNotice("API Key Missing", "Paste your OpenWeather API key to stream live weather.", true);
    return;
  }

  saveUserApiKey(key);
  if (els.userApiKeyInput) els.userApiKeyInput.value = key;
  if (els.modalApiKeyInput) els.modalApiKeyInput.value = key;
  if (els.keyFeedback) {
    els.keyFeedback.textContent = "Validating key & connecting to OpenWeather…";
    els.keyFeedback.className = "key-feedback";
  }

  setSyncStatus("loading", "Validating key…");
  setLoader(true, "Connecting to OpenWeather real-time stream…");

  try {
    const status = await checkServerStatus(key);
    state.hasServerKey = true;
    await loadCityWeather(state.activeCityName, { force: true });
    if (els.keyFeedback) {
      els.keyFeedback.textContent = `✅ Live Weather Stream Connected for ${state.activeCityName}!`;
      els.keyFeedback.className = "key-feedback success";
    }
    showNotice(
      "Live Weather Stream Active",
      `OpenWeather satellite feed connected! Live telemetry, 3D India map, and 3D environment updated.`
    );
    if (els.configModal && !els.configModal.hidden) {
      setTimeout(() => {
        els.configModal.hidden = true;
      }, 800);
    }
  } catch (err) {
    if (els.keyFeedback) {
      els.keyFeedback.textContent = `❌ ${err.message || "Key validation failed."}`;
      els.keyFeedback.className = "key-feedback error";
    }
    showNotice("Key Connection Notice", err.message || "Failed to verify key.", true);
  } finally {
    setLoader(false);
  }
}

function clearApiKey() {
  saveUserApiKey("");
  if (els.userApiKeyInput) els.userApiKeyInput.value = "";
  if (els.modalApiKeyInput) els.modalApiKeyInput.value = "";
  state.hasServerKey = false;
  if (els.keyFeedback) {
    els.keyFeedback.textContent = "Key removed. Switched to Indian meteorological simulation.";
    els.keyFeedback.className = "key-feedback";
  }
  switchToDemoForCity(state.activeCityName, "API key cleared. Running in Demonstration Scenario Mode.");
}

async function recheckServerStatus() {
  if (!els.modalStatusText) return;
  els.modalStatusText.textContent = "Verifying with server…";
  const userKey = loadUserApiKey();
  const status = await checkServerStatus(userKey);
  state.hasServerKey = !!status.hasKey;

  if (status.hasKey) {
    els.modalStatusText.textContent = "✅ OpenWeather key is active!";
    els.modalStatusText.style.color = "var(--accent-emerald)";
    loadCityWeather(state.activeCityName, { force: true });
    setTimeout(() => {
      if (els.configModal) els.configModal.hidden = true;
    }, 1200);
  } else {
    els.modalStatusText.textContent = "⚠️ OPENWEATHER_API_KEY is not configured";
    els.modalStatusText.style.color = "var(--accent-amber)";
  }
}

function degToCompass(num) {
  const val = Math.floor((Number(num) || 0) / 22.5 + 0.5);
  const arr = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  return arr[val % 16];
}

function capitalize(text) {
  if (!text) return "—";
  return text.charAt(0).toUpperCase() + text.slice(1);
}

// -------------------------------------------------------------
// Render Loop for Environment Lerping
// -------------------------------------------------------------
let frameCount = 0;
function animateLoop() {
  controller.tick(1 / 60);
  if (world) {
    world.applyEnvironment(controller.current);
  }
  frameCount += 1;
  if (frameCount % 45 === 0) {
    renderIntelligenceText();
  }
  requestAnimationFrame(animateLoop);
}

// -------------------------------------------------------------
// Application Bootstrap
// -------------------------------------------------------------
async function bootstrap() {
  try {
    buildQuickChips();
    setupSearch();
    setupStageTabs();
    setupDemoControls();
    setupAutoRefreshAndDemoEditor();
    setupStageControls();

    // 0. Initialize 2D India state/district map
    const dEl = document.getElementById("india-district-map");
    if (dEl) {
      try {
        dmap = new IndiaWeatherMap(dEl, {
          onStateSelect: (stateName) => onMapStateSelected(stateName),
          onDistrictSelect: (d) => selectLocation({ name: d.name, state: d.state, district: d.name, lat: d.lat, lon: d.lon, kind: "district" }, { skipMap: true }),
          onError: (msg) => showMapError(msg),
        });
        document.getElementById("district-reset-btn")?.addEventListener("click", () => { dmap.resetIndiaView(); populateDistrictSelect(null, []); setCrumb("India"); });
        document.getElementById("district-select")?.addEventListener("change", (e) => { if (e.target.value) dmap.selectDistrict(e.target.value); });
      } catch (err) { showMapError(`Map failed to start: ${err.message}`); }
    }

    // 1. Initialize 3D India Geographic Map
    if (els.mapContainer) {
      map = new India3DGeoMap(els.mapContainer, {
        onCitySelect: (city) => {
          loadCityWeather(city.name, { force: true });
        },
        onStateSelect: (stateName) => {
          showNotice("State Focus Active", `Inspecting weather systems across ${stateName}.`);
        },
      });
    }

    // 2. Initialize 3D Environmental World
    if (els.sceneCanvas) {
      world = createWeatherWorld(els.sceneCanvas);
      world.start();
    }

    // 3. Initialize Analytics Chart
    if (els.chartCanvas) {
      chart = new WeatherAnalyticsChart(els.chartCanvas);
    }

    // Set initial stage mode (3D India Map default)
    setStageMode("districts");

    // Start Controller Lerp Loop
    animateLoop();

    // 4. Check API Key & Load Initial City
    const savedKey = loadUserApiKey();
    if (savedKey) {
      if (els.userApiKeyInput) els.userApiKeyInput.value = savedKey;
      if (els.modalApiKeyInput) els.modalApiKeyInput.value = savedKey;
      await connectApiKey(savedKey);
    } else {
      setSyncStatus("loading", "Connecting to server…");
      const serverStatus = await checkServerStatus();
      state.hasServerKey = !!serverStatus.hasKey;

      if (state.hasServerKey) {
        setSyncStatus("live", "Server key active");
        await loadCityWeather(state.activeCityName);
      } else {
        setSyncStatus("demo", "Demo Mode — simulated Indian weather");
        switchToDemoForCity(state.activeCityName);
        if (els.keyFeedback) {
          els.keyFeedback.textContent = "Ready — enter key to unlock real-time live weather for any Indian city.";
        }
      }
    }
  } catch (err) {
    console.error("Bootstrap error:", err);
    showNotice("Startup Warning", "VARSHA initialized in safe mode.", true);
    switchToDemoForCity("New Delhi");
  }
}

// Cleanup on exit
window.addEventListener("beforeunload", () => {
  if (world) world.dispose();
  if (map) map.dispose();
  if (chart) chart.dispose();
});

bootstrap();
