/**
 * Curated geographic database of Indian Cities, State Capitals,
 * Union Territories, and major economic and meteorological centers.
 */

export const INDIAN_CITIES = [
  // National Capital Region & North India
  { name: "New Delhi", state: "Delhi", lat: 28.6139, lon: 77.209, region: "North", featured: true },
  { name: "Srinagar", state: "Jammu and Kashmir", lat: 34.0837, lon: 74.7973, region: "North", featured: true },
  { name: "Jammu", state: "Jammu and Kashmir", lat: 32.7266, lon: 74.857, region: "North" },
  { name: "Leh", state: "Ladakh", lat: 34.1526, lon: 77.5771, region: "North" },
  { name: "Shimla", state: "Himachal Pradesh", lat: 31.1048, lon: 77.1734, region: "North" },
  { name: "Dharamshala", state: "Himachal Pradesh", lat: 32.219, lon: 76.3234, region: "North" },
  { name: "Chandigarh", state: "Chandigarh", lat: 30.7333, lon: 76.7794, region: "North", featured: true },
  { name: "Gurugram", state: "Haryana", lat: 28.4595, lon: 77.0266, region: "North" },
  { name: "Faridabad", state: "Haryana", lat: 28.4089, lon: 77.3178, region: "North" },
  { name: "Amritsar", state: "Punjab", lat: 31.634, lon: 74.8723, region: "North" },
  { name: "Ludhiana", state: "Punjab", lat: 30.901, lon: 75.8573, region: "North" },
  { name: "Dehradun", state: "Uttarakhand", lat: 30.3165, lon: 78.0322, region: "North", featured: true },
  { name: "Nainital", state: "Uttarakhand", lat: 29.3919, lon: 79.4542, region: "North" },
  { name: "Lucknow", state: "Uttar Pradesh", lat: 26.8467, lon: 80.9462, region: "North", featured: true },
  { name: "Varanasi", state: "Uttar Pradesh", lat: 25.3176, lon: 82.9739, region: "North" },
  { name: "Kanpur", state: "Uttar Pradesh", lat: 26.4499, lon: 80.3319, region: "North" },
  { name: "Agra", state: "Uttar Pradesh", lat: 27.1767, lon: 78.0081, region: "North" },
  { name: "Prayagraj", state: "Uttar Pradesh", lat: 25.4358, lon: 81.8463, region: "North" },
  { name: "Jaipur", state: "Rajasthan", lat: 26.9124, lon: 75.7873, region: "North", featured: true },
  { name: "Jodhpur", state: "Rajasthan", lat: 26.2389, lon: 73.0243, region: "North" },
  { name: "Udaipur", state: "Rajasthan", lat: 24.5854, lon: 73.7125, region: "North" },
  { name: "Jaisalmer", state: "Rajasthan", lat: 26.9157, lon: 70.9083, region: "North" },

  // West & Central India
  { name: "Mumbai", state: "Maharashtra", lat: 19.076, lon: 72.8777, region: "West", featured: true },
  { name: "Pune", state: "Maharashtra", lat: 18.5204, lon: 73.8567, region: "West", featured: true },
  { name: "Nagpur", state: "Maharashtra", lat: 21.1458, lon: 79.0882, region: "Central" },
  { name: "Nashik", state: "Maharashtra", lat: 19.9975, lon: 73.7898, region: "West" },
  { name: "Aurangabad", state: "Maharashtra", lat: 19.8762, lon: 75.3433, region: "West" },
  { name: "Ahmedabad", state: "Gujarat", lat: 23.0225, lon: 72.5714, region: "West", featured: true },
  { name: "Surat", state: "Gujarat", lat: 21.1702, lon: 72.8311, region: "West" },
  { name: "Vadodara", state: "Gujarat", lat: 22.3072, lon: 73.1812, region: "West" },
  { name: "Rajkot", state: "Gujarat", lat: 22.3039, lon: 70.8022, region: "West" },
  { name: "Daman", state: "Dadra and Nagar Haveli and Daman and Diu", lat: 20.4283, lon: 72.8397, region: "West" },
  { name: "Silvassa", state: "Dadra and Nagar Haveli and Daman and Diu", lat: 20.2763, lon: 73.0083, region: "West" },
  { name: "Bhopal", state: "Madhya Pradesh", lat: 23.2599, lon: 77.4126, region: "Central", featured: true },
  { name: "Indore", state: "Madhya Pradesh", lat: 22.7196, lon: 75.8577, region: "Central" },
  { name: "Gwalior", state: "Madhya Pradesh", lat: 26.2183, lon: 78.1828, region: "Central" },
  { name: "Jabalpur", state: "Madhya Pradesh", lat: 23.1815, lon: 79.9864, region: "Central" },
  { name: "Raipur", state: "Chhattisgarh", lat: 21.2514, lon: 81.6296, region: "Central" },
  { name: "Panaji", state: "Goa", lat: 15.4909, lon: 73.8278, region: "West" },

  // South India
  { name: "Bengaluru", state: "Karnataka", lat: 12.9716, lon: 77.5946, region: "South", featured: true },
  { name: "Mysuru", state: "Karnataka", lat: 12.2958, lon: 76.6394, region: "South" },
  { name: "Mangaluru", state: "Karnataka", lat: 12.9141, lon: 74.856, region: "South" },
  { name: "Hubballi", state: "Karnataka", lat: 15.3647, lon: 75.124, region: "South" },
  { name: "Chennai", state: "Tamil Nadu", lat: 13.0827, lon: 80.2707, region: "South", featured: true },
  { name: "Coimbatore", state: "Tamil Nadu", lat: 11.0168, lon: 76.9558, region: "South" },
  { name: "Madurai", state: "Tamil Nadu", lat: 9.9252, lon: 78.1198, region: "South" },
  { name: "Tiruchirappalli", state: "Tamil Nadu", lat: 10.7905, lon: 78.7047, region: "South" },
  { name: "Hyderabad", state: "Telangana", lat: 17.385, lon: 78.4867, region: "South", featured: true },
  { name: "Warangal", state: "Telangana", lat: 17.9689, lon: 79.5941, region: "South" },
  { name: "Visakhapatnam", state: "Andhra Pradesh", lat: 17.6868, lon: 83.2185, region: "South", featured: true },
  { name: "Vijayawada", state: "Andhra Pradesh", lat: 16.5062, lon: 80.648, region: "South" },
  { name: "Tirupati", state: "Andhra Pradesh", lat: 13.6288, lon: 79.4192, region: "South" },
  { name: "Kochi", state: "Kerala", lat: 9.9312, lon: 76.2673, region: "South", featured: true },
  { name: "Thiruvananthapuram", state: "Kerala", lat: 8.5241, lon: 76.9366, region: "South", featured: true },
  { name: "Kozhikode", state: "Kerala", lat: 11.2588, lon: 75.7804, region: "South" },
  { name: "Puducherry", state: "Puducherry", lat: 11.9416, lon: 79.8083, region: "South" },

  // East & Northeast India
  { name: "Kolkata", state: "West Bengal", lat: 22.5726, lon: 88.3639, region: "East", featured: true },
  { name: "Darjeeling", state: "West Bengal", lat: 27.041, lon: 88.2663, region: "East" },
  { name: "Siliguri", state: "West Bengal", lat: 26.7271, lon: 88.3953, region: "East" },
  { name: "Patna", state: "Bihar", lat: 25.5941, lon: 85.1376, region: "East", featured: true },
  { name: "Gaya", state: "Bihar", lat: 24.7914, lon: 85.0002, region: "East" },
  { name: "Ranchi", state: "Jharkhand", lat: 23.3441, lon: 85.3096, region: "East" },
  { name: "Jamshedpur", state: "Jharkhand", lat: 22.8046, lon: 86.2029, region: "East" },
  { name: "Bhubaneswar", state: "Odisha", lat: 20.2961, lon: 85.8245, region: "East", featured: true },
  { name: "Puri", state: "Odisha", lat: 19.8135, lon: 85.8312, region: "East" },
  { name: "Cuttack", state: "Odisha", lat: 20.4625, lon: 85.883, region: "East" },
  { name: "Guwahati", state: "Assam", lat: 26.1445, lon: 91.7362, region: "Northeast", featured: true },
  { name: "Shillong", state: "Meghalaya", lat: 25.5788, lon: 91.8933, region: "Northeast" },
  { name: "Cherrapunji", state: "Meghalaya", lat: 25.2986, lon: 91.7324, region: "Northeast" },
  { name: "Gangtok", state: "Sikkim", lat: 27.3389, lon: 88.6065, region: "Northeast" },
  { name: "Agartala", state: "Tripura", lat: 23.8315, lon: 91.2868, region: "Northeast" },
  { name: "Imphal", state: "Manipur", lat: 24.817, lon: 93.9368, region: "Northeast" },
  { name: "Aizawl", state: "Mizoram", lat: 23.7271, lon: 92.7176, region: "Northeast" },
  { name: "Kohima", state: "Nagaland", lat: 25.6751, lon: 94.1086, region: "Northeast" },
  { name: "Itanagar", state: "Arunachal Pradesh", lat: 27.0844, lon: 93.6053, region: "Northeast" },

  // Islands
  { name: "Port Blair", state: "Andaman and Nicobar", lat: 11.6234, lon: 92.7265, region: "Islands" },
  { name: "Kavaratti", state: "Lakshadweep", lat: 10.5669, lon: 72.642, region: "Islands" },
];

/**
 * Bounds of Indian Territory (approximate bounding box for geographic validation)
 */
export const INDIA_BOUNDS = {
  minLat: 6.0,
  maxLat: 37.5,
  minLon: 68.0,
  maxLon: 97.5,
};

export function isWithinIndia(lat, lon) {
  const nLat = Number(lat);
  const nLon = Number(lon);
  if (!Number.isFinite(nLat) || !Number.isFinite(nLon)) return false;
  return (
    nLat >= INDIA_BOUNDS.minLat &&
    nLat <= INDIA_BOUNDS.maxLat &&
    nLon >= INDIA_BOUNDS.minLon &&
    nLon <= INDIA_BOUNDS.maxLon
  );
}

export function searchIndianCities(query, limit = 8) {
  if (!query || typeof query !== "string") return [];
  const q = query.trim().toLowerCase();
  if (!q) return [];

  // Exact prefix match first, then substring
  const exactPrefix = [];
  const substringMatch = [];

  for (const city of INDIAN_CITIES) {
    const nameLow = city.name.toLowerCase();
    const stateLow = city.state.toLowerCase();
    if (nameLow.startsWith(q)) {
      exactPrefix.push(city);
    } else if (nameLow.includes(q) || stateLow.includes(q)) {
      substringMatch.push(city);
    }
    if (exactPrefix.length + substringMatch.length >= limit * 2) break;
  }

  return [...exactPrefix, ...substringMatch].slice(0, limit);
}

export function getCityByName(name) {
  if (!name) return null;
  const q = name.trim().toLowerCase();
  return INDIAN_CITIES.find(
    (c) => c.name.toLowerCase() === q || `${c.name.toLowerCase()}, ${c.state.toLowerCase()}` === q
  ) || null;
}

export function findNearestIndianCity(lat, lon) {
  const nLat = Number(lat);
  const nLon = Number(lon);
  if (!Number.isFinite(nLat) || !Number.isFinite(nLon)) return INDIAN_CITIES[0];

  let nearest = INDIAN_CITIES[0];
  let minDistance = Infinity;

  for (const city of INDIAN_CITIES) {
    const dLat = city.lat - nLat;
    const dLon = city.lon - nLon;
    const distSq = dLat * dLat + dLon * dLon;
    if (distSq < minDistance) {
      minDistance = distSq;
      nearest = city;
    }
  }

  return nearest;
}

export function getCitiesByState(stateName) {
  if (!stateName) return [];
  const normTarget = stateName.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]/g, "");
  return INDIAN_CITIES.filter((c) => {
    const normState = c.state.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]/g, "");
    return normState === normTarget || normState.includes(normTarget) || normTarget.includes(normState);
  });
}

export function getPrimaryCityForState(stateName) {
  const cities = getCitiesByState(stateName);
  if (cities.length === 0) return null;
  const featured = cities.find((c) => c.featured);
  return featured || cities[0];
}
