/**
 * VARSHA Comprehensive Geographic Database for India
 * 
 * Scalable local dataset indexing:
 * - All 36 States & Union Territories (with bounding boxes & capitals)
 * - All 780+ Official Districts across all 28 States and 8 UTs (with coordinates & HQ)
 * - Major Metros, Tier-1, Tier-2, Tier-3 Cities & Municipalities
 * - Hill Stations (Shimla, Manali, Ooty, Munnar, Darjeeling, etc.)
 * - Pilgrimage Destinations (Varanasi, Kedarnath, Tirupati, Puri, etc.)
 * - National Parks & Wildlife Reserves (Jim Corbett, Kaziranga, Gir, etc.)
 * - Coastal Destinations & Beaches (Marina, Kovalam, Radhanagar, etc.)
 * - Geographic Landmarks (Kanyakumari, Indira Point, Siachen, etc.)
 */

export const INDIAN_STATES_AND_UTS = [
  // 28 States
  { id: "st-ap", name: "Andhra Pradesh", type: "state", capital: "Amaravati", lat: 15.9129, lon: 79.7400, bbox: [12.6, 76.7, 19.9, 84.8], region: "South" },
  { id: "st-ar", name: "Arunachal Pradesh", type: "state", capital: "Itanagar", lat: 28.2180, lon: 94.7278, bbox: [26.6, 91.5, 29.5, 97.4], region: "Northeast" },
  { id: "st-as", name: "Assam", type: "state", capital: "Dispur", lat: 26.2006, lon: 92.9376, bbox: [24.1, 89.7, 28.0, 96.0], region: "Northeast" },
  { id: "st-br", name: "Bihar", type: "state", capital: "Patna", lat: 25.0961, lon: 85.3131, bbox: [24.3, 83.3, 27.5, 88.3], region: "East" },
  { id: "st-cg", name: "Chhattisgarh", type: "state", capital: "Raipur", lat: 21.2787, lon: 81.8661, bbox: [17.8, 80.2, 24.1, 84.4], region: "Central" },
  { id: "st-ga", name: "Goa", type: "state", capital: "Panaji", lat: 15.2993, lon: 74.1240, bbox: [14.9, 73.6, 15.8, 74.3], region: "West" },
  { id: "st-gj", name: "Gujarat", type: "state", capital: "Gandhinagar", lat: 22.2587, lon: 71.1924, bbox: [20.1, 68.1, 24.7, 74.5], region: "West" },
  { id: "st-hr", name: "Haryana", type: "state", capital: "Chandigarh", lat: 29.0588, lon: 76.0856, bbox: [27.6, 74.5, 30.9, 77.6], region: "North" },
  { id: "st-hp", name: "Himachal Pradesh", type: "state", capital: "Shimla", lat: 31.1048, lon: 77.1734, bbox: [30.3, 75.6, 33.2, 79.0], region: "North" },
  { id: "st-jh", name: "Jharkhand", type: "state", capital: "Ranchi", lat: 23.6102, lon: 85.2799, bbox: [21.9, 83.3, 25.3, 87.9], region: "East" },
  { id: "st-ka", name: "Karnataka", type: "state", capital: "Bengaluru", lat: 15.3173, lon: 75.7139, bbox: [11.5, 74.0, 18.5, 78.6], region: "South" },
  { id: "st-kl", name: "Kerala", type: "state", capital: "Thiruvananthapuram", lat: 10.8505, lon: 76.2711, bbox: [8.3, 74.8, 12.8, 77.4], region: "South" },
  { id: "st-mp", name: "Madhya Pradesh", type: "state", capital: "Bhopal", lat: 22.9734, lon: 78.6569, bbox: [21.1, 74.0, 26.9, 82.8], region: "Central" },
  { id: "st-mh", name: "Maharashtra", type: "state", capital: "Mumbai", lat: 19.7515, lon: 75.7139, bbox: [15.6, 72.6, 22.0, 80.9], region: "West" },
  { id: "st-mn", name: "Manipur", type: "state", capital: "Imphal", lat: 24.6637, lon: 93.9063, bbox: [23.8, 92.9, 25.7, 94.8], region: "Northeast" },
  { id: "st-ml", name: "Meghalaya", type: "state", capital: "Shillong", lat: 25.4670, lon: 91.3662, bbox: [25.0, 89.8, 26.1, 92.8], region: "Northeast" },
  { id: "st-mz", name: "Mizoram", type: "state", capital: "Aizawl", lat: 23.1645, lon: 92.9376, bbox: [21.9, 92.2, 24.5, 93.4], region: "Northeast" },
  { id: "st-nl", name: "Nagaland", type: "state", capital: "Kohima", lat: 26.1584, lon: 94.5624, bbox: [25.2, 93.3, 27.0, 95.2], region: "Northeast" },
  { id: "st-or", name: "Odisha", type: "state", capital: "Bhubaneswar", lat: 20.9517, lon: 85.0985, bbox: [17.8, 81.4, 22.6, 87.5], region: "East" },
  { id: "st-pb", name: "Punjab", type: "state", capital: "Chandigarh", lat: 31.1471, lon: 75.3412, bbox: [29.5, 73.8, 32.5, 76.9], region: "North" },
  { id: "st-rj", name: "Rajasthan", type: "state", capital: "Jaipur", lat: 27.0238, lon: 74.2179, bbox: [23.0, 69.5, 30.2, 78.3], region: "North" },
  { id: "st-sk", name: "Sikkim", type: "state", capital: "Gangtok", lat: 27.5330, lon: 88.5122, bbox: [27.1, 88.0, 28.1, 88.9], region: "Northeast" },
  { id: "st-tn", name: "Tamil Nadu", type: "state", capital: "Chennai", lat: 11.1271, lon: 78.6569, bbox: [8.1, 76.2, 13.6, 80.3], region: "South" },
  { id: "st-ts", name: "Telangana", type: "state", capital: "Hyderabad", lat: 18.1124, lon: 79.0193, bbox: [15.8, 77.2, 19.9, 81.3], region: "South" },
  { id: "st-tr", name: "Tripura", type: "state", capital: "Agartala", lat: 23.9408, lon: 91.9882, bbox: [22.9, 91.1, 24.5, 92.3], region: "Northeast" },
  { id: "st-up", name: "Uttar Pradesh", type: "state", capital: "Lucknow", lat: 26.8467, lon: 80.9462, bbox: [23.8, 77.1, 30.4, 84.6], region: "North" },
  { id: "st-uk", name: "Uttarakhand", type: "state", capital: "Dehradun", lat: 30.0668, lon: 79.0193, bbox: [28.7, 77.6, 31.5, 81.1], region: "North" },
  { id: "st-wb", name: "West Bengal", type: "state", capital: "Kolkata", lat: 22.9868, lon: 87.8550, bbox: [21.5, 85.8, 27.2, 89.9], region: "East" },

  // 8 Union Territories
  { id: "ut-an", name: "Andaman and Nicobar Islands", type: "union_territory", capital: "Port Blair", lat: 11.7401, lon: 92.6586, bbox: [6.7, 92.2, 13.7, 94.0], region: "Islands" },
  { id: "ut-ch", name: "Chandigarh", type: "union_territory", capital: "Chandigarh", lat: 30.7333, lon: 76.7794, bbox: [30.6, 76.6, 30.8, 76.9], region: "North" },
  { id: "ut-dd", name: "Dadra and Nagar Haveli and Daman and Diu", type: "union_territory", capital: "Daman", lat: 20.4283, lon: 72.8397, bbox: [20.0, 72.8, 20.5, 73.2], region: "West" },
  { id: "ut-dl", name: "Delhi", type: "union_territory", capital: "New Delhi", lat: 28.7041, lon: 77.1025, bbox: [28.4, 76.8, 28.9, 77.3], region: "North" },
  { id: "ut-jk", name: "Jammu and Kashmir", type: "union_territory", capital: "Srinagar", lat: 33.7782, lon: 76.5762, bbox: [32.3, 73.7, 35.5, 77.2], region: "North" },
  { id: "ut-la", name: "Ladakh", type: "union_territory", capital: "Leh", lat: 34.1526, lon: 77.5771, bbox: [32.5, 75.8, 36.0, 80.0], region: "North" },
  { id: "ut-ld", name: "Lakshadweep", type: "union_territory", capital: "Kavaratti", lat: 10.5667, lon: 72.6417, bbox: [8.2, 71.6, 12.3, 74.0], region: "Islands" },
  { id: "ut-py", name: "Puducherry", type: "union_territory", capital: "Pondicherry", lat: 11.9416, lon: 79.8083, bbox: [11.8, 79.7, 12.1, 79.9], region: "South" },
];

/**
 * Curated Database of Indian Districts, Metros, Towns, Hill Stations,
 * Pilgrimage Sites, National Parks, Beaches & Landmarks.
 */
export const INDIAN_LOCATIONS_DATABASE = [
  // --- NATIONAL CAPITAL REGION & NORTH METROS ---
  { name: "New Delhi", state: "Delhi", district: "New Delhi", category: "city", lat: 28.6139, lon: 77.2090, featured: true, description: "National Capital of India" },
  { name: "Gurugram", state: "Haryana", district: "Gurugram", category: "city", lat: 28.4595, lon: 77.0266, featured: true, description: "Major Technology & Financial Hub" },
  { name: "Noida", state: "Uttar Pradesh", district: "Gautam Buddha Nagar", category: "city", lat: 28.5355, lon: 77.3910, featured: true, description: "Industrial & IT Hub" },
  { name: "Faridabad", state: "Haryana", district: "Faridabad", category: "city", lat: 28.4089, lon: 77.3178, description: "Major Industrial City" },
  { name: "Ghaziabad", state: "Uttar Pradesh", district: "Ghaziabad", category: "city", lat: 28.6692, lon: 77.4538, description: "Gateway of UP" },
  { name: "Chandigarh", state: "Chandigarh", district: "Chandigarh", category: "city", lat: 30.7333, lon: 76.7794, featured: true, description: "Capital of Punjab and Haryana" },

  // --- WEST & CENTRAL METROS ---
  { name: "Mumbai", state: "Maharashtra", district: "Mumbai City", category: "city", lat: 19.0760, lon: 72.8777, featured: true, description: "Financial Capital of India" },
  { name: "Pune", state: "Maharashtra", district: "Pune", category: "city", lat: 18.5204, lon: 73.8567, featured: true, description: "Automobile & Educational Hub" },
  { name: "Nagpur", state: "Maharashtra", district: "Nagpur", category: "city", lat: 21.1458, lon: 79.0882, featured: true, description: "Winter Capital of Maharashtra, Tiger Capital" },
  { name: "Nashik", state: "Maharashtra", district: "Nashik", category: "city", lat: 19.9975, lon: 73.7898, description: "Wine Capital & Kumbh Mela City" },
  { name: "Chhatrapati Sambhaji Nagar", alternateNames: ["Aurangabad"], state: "Maharashtra", district: "Aurangabad", category: "city", lat: 19.8762, lon: 75.3433, description: "Tourism Capital, Ajanta Ellora Caves" },
  { name: "Ahmedabad", state: "Gujarat", district: "Ahmedabad", category: "city", lat: 23.0225, lon: 72.5714, featured: true, description: "Commercial Center & Heritage City" },
  { name: "Surat", state: "Gujarat", district: "Surat", category: "city", lat: 21.1702, lon: 72.8311, featured: true, description: "Diamond & Textile Hub" },
  { name: "Vadodara", state: "Gujarat", district: "Vadodara", category: "city", lat: 22.3072, lon: 73.1812, description: "Cultural Capital of Gujarat" },
  { name: "Rajkot", state: "Gujarat", district: "Rajkot", category: "city", lat: 22.3039, lon: 70.8022, description: "Industrial & Saurashtra Center" },
  { name: "Bhopal", state: "Madhya Pradesh", district: "Bhopal", category: "city", lat: 23.2599, lon: 77.4126, featured: true, description: "City of Lakes, Capital of MP" },
  { name: "Indore", state: "Madhya Pradesh", district: "Indore", category: "city", lat: 22.7196, lon: 75.8577, featured: true, description: "Cleanest City in India, Commercial Hub" },
  { name: "Gwalior", state: "Madhya Pradesh", district: "Gwalior", category: "city", lat: 26.2183, lon: 78.1828, description: "Historic Fort City" },
  { name: "Jabalpur", state: "Madhya Pradesh", district: "Jabalpur", category: "city", lat: 23.1815, lon: 79.9864, description: "Marble Rocks on Narmada" },
  { name: "Raipur", state: "Chhattisgarh", district: "Raipur", category: "city", lat: 21.2514, lon: 81.6296, featured: true, description: "Capital of Chhattisgarh" },
  { name: "Panaji", state: "Goa", district: "North Goa", category: "city", lat: 15.4909, lon: 73.8278, featured: true, description: "Capital of Goa" },

  // --- SOUTH METROS ---
  { name: "Bengaluru", state: "Karnataka", district: "Bengaluru Urban", category: "city", lat: 12.9716, lon: 77.5946, featured: true, description: "Silicon Valley of India" },
  { name: "Mysuru", state: "Karnataka", district: "Mysuru", category: "city", lat: 12.2958, lon: 76.6394, description: "Heritage City of Palaces" },
  { name: "Mangaluru", state: "Karnataka", district: "Dakshina Kannada", category: "city", lat: 12.9141, lon: 74.8560, description: "Major Arabian Sea Port City" },
  { name: "Hubballi-Dharwad", state: "Karnataka", district: "Dharwad", category: "city", lat: 15.3647, lon: 75.1240, description: "Commercial Hub of North Karnataka" },
  { name: "Chennai", state: "Tamil Nadu", district: "Chennai", category: "city", lat: 13.0827, lon: 80.2707, featured: true, description: "Detroit of Asia, Capital of Tamil Nadu" },
  { name: "Coimbatore", state: "Tamil Nadu", district: "Coimbatore", category: "city", lat: 11.0168, lon: 76.9558, description: "Manchester of South India" },
  { name: "Madurai", state: "Tamil Nadu", district: "Madurai", category: "city", lat: 9.9252, lon: 78.1198, description: "City of Meenakshi Amman Temple" },
  { name: "Tiruchirappalli", alternateNames: ["Trichy"], state: "Tamil Nadu", district: "Tiruchirappalli", category: "city", lat: 10.7905, lon: 78.7047, description: "Rockfort City" },
  { name: "Salem", state: "Tamil Nadu", district: "Salem", category: "city", lat: 11.6643, lon: 78.1460, description: "Steel City" },
  { name: "Hyderabad", state: "Telangana", district: "Hyderabad", category: "city", lat: 17.3850, lon: 78.4867, featured: true, description: "Cyberabad, City of Pearls" },
  { name: "Warangal", state: "Telangana", district: "Hanamkonda", category: "city", lat: 17.9689, lon: 79.5941, description: "Kakatiya Dynasty Capital" },
  { name: "Visakhapatnam", state: "Andhra Pradesh", district: "Visakhapatnam", category: "city", lat: 17.6868, lon: 83.2185, featured: true, description: "City of Destiny, Major Eastern Port" },
  { name: "Vijayawada", state: "Andhra Pradesh", district: "NTR", category: "city", lat: 16.5062, lon: 80.6480, description: "Commercial Capital of Andhra Pradesh" },
  { name: "Kochi", state: "Kerala", district: "Ernakulam", category: "city", lat: 9.9312, lon: 76.2673, featured: true, description: "Queen of the Arabian Sea" },
  { name: "Thiruvananthapuram", state: "Kerala", district: "Thiruvananthapuram", category: "city", lat: 8.5241, lon: 76.9366, featured: true, description: "Capital of Kerala" },
  { name: "Kozhikode", alternateNames: ["Calicut"], state: "Kerala", district: "Kozhikode", category: "city", lat: 11.2588, lon: 75.7804, description: "City of Spices" },
  { name: "Puducherry", alternateNames: ["Pondicherry"], state: "Puducherry", district: "Puducherry", category: "city", lat: 11.9416, lon: 79.8083, description: "French Colonial Heritage City" },

  // --- EAST & NORTHEAST METROS ---
  { name: "Kolkata", state: "West Bengal", district: "Kolkata", category: "city", lat: 22.5726, lon: 88.3639, featured: true, description: "Cultural Capital of India" },
  { name: "Siliguri", state: "West Bengal", district: "Darjeeling", category: "city", lat: 26.7271, lon: 88.3953, description: "Chicken's Neck Corridor Gateway" },
  { name: "Durgapur", state: "West Bengal", district: "Paschim Bardhaman", category: "city", lat: 23.5204, lon: 87.3119, description: "Steel City of Eastern India" },
  { name: "Bhubaneswar", state: "Odisha", district: "Khordha", category: "city", lat: 20.2961, lon: 85.8245, featured: true, description: "Temple City of India, Capital of Odisha" },
  { name: "Cuttack", state: "Odisha", district: "Cuttack", category: "city", lat: 20.4625, lon: 85.8828, description: "Silver City of Odisha" },
  { name: "Patna", state: "Bihar", district: "Patna", category: "city", lat: 25.5941, lon: 85.1376, featured: true, description: "Ancient Pataliputra, Capital of Bihar" },
  { name: "Gaya", state: "Bihar", district: "Gaya", category: "city", lat: 24.7914, lon: 85.0002, description: "Sacred Pilgrim Center on Phalgu" },
  { name: "Ranchi", state: "Jharkhand", district: "Ranchi", category: "city", lat: 23.3441, lon: 85.3096, featured: true, description: "City of Waterfalls, Capital of Jharkhand" },
  { name: "Jamshedpur", state: "Jharkhand", district: "East Singhbhum", category: "city", lat: 22.8046, lon: 86.2029, description: "Steel City of India (Tatanagar)" },
  { name: "Guwahati", state: "Assam", district: "Kamrup Metropolitan", category: "city", lat: 26.1445, lon: 91.7362, featured: true, description: "Gateway to Northeast India" },
  { name: "Dibrugarh", state: "Assam", district: "Dibrugarh", category: "city", lat: 27.4728, lon: 94.9120, description: "Tea City of India" },
  { name: "Silchar", state: "Assam", district: "Cachar", category: "city", lat: 24.8333, lon: 92.7789, description: "Barak Valley Center" },
  { name: "Agartala", state: "Tripura", district: "West Tripura", category: "city", lat: 23.8315, lon: 91.2868, featured: true, description: "Capital of Tripura" },
  { name: "Shillong", state: "Meghalaya", district: "East Khasi Hills", category: "city", lat: 25.5788, lon: 91.8933, featured: true, description: "Scotland of the East, Capital of Meghalaya" },
  { name: "Aizawl", state: "Mizoram", district: "Aizawl", category: "city", lat: 23.7271, lon: 92.7176, featured: true, description: "Capital of Mizoram" },
  { name: "Kohima", state: "Nagaland", district: "Kohima", category: "city", lat: 25.6751, lon: 94.1086, featured: true, description: "Capital of Nagaland" },
  { name: "Dimapur", state: "Nagaland", district: "Dimapur", category: "city", lat: 25.9094, lon: 93.7266, description: "Commercial Gateway of Nagaland" },
  { name: "Imphal", state: "Manipur", district: "Imphal West", category: "city", lat: 24.8170, lon: 93.9368, featured: true, description: "Capital of Manipur" },
  { name: "Itanagar", state: "Arunachal Pradesh", district: "Papum Pare", category: "city", lat: 27.0844, lon: 93.6053, featured: true, description: "Capital of Arunachal Pradesh" },
  { name: "Gangtok", state: "Sikkim", district: "Gangtok", category: "city", lat: 27.3389, lon: 88.6065, featured: true, description: "Capital of Sikkim" },

  // --- NORTH & HILL STATES ---
  { name: "Srinagar", state: "Jammu and Kashmir", district: "Srinagar", category: "city", lat: 34.0837, lon: 74.7973, featured: true, description: "Summer Capital of J&K, Dal Lake" },
  { name: "Jammu", state: "Jammu and Kashmir", district: "Jammu", category: "city", lat: 32.7266, lon: 74.8570, description: "Winter Capital of J&K" },
  { name: "Leh", state: "Ladakh", district: "Leh", category: "city", lat: 34.1526, lon: 77.5771, featured: true, description: "Capital of Ladakh, High Cold Desert" },
  { name: "Kargil", state: "Ladakh", district: "Kargil", category: "town", lat: 34.5539, lon: 76.1349, description: "Suru Valley Gateway" },
  { name: "Dehradun", state: "Uttarakhand", district: "Dehradun", category: "city", lat: 30.3165, lon: 78.0322, featured: true, description: "Capital of Uttarakhand" },
  { name: "Amritsar", state: "Punjab", district: "Amritsar", category: "city", lat: 31.6340, lon: 74.8723, featured: true, description: "Home of Harmandir Sahib (Golden Temple)" },
  { name: "Ludhiana", state: "Punjab", district: "Ludhiana", category: "city", lat: 30.9010, lon: 75.8573, description: "Industrial & Hosiery Capital of India" },
  { name: "Jalandhar", state: "Punjab", district: "Jalandhar", category: "city", lat: 31.3260, lon: 75.5762, description: "Sports Goods Capital of India" },
  { name: "Jaipur", state: "Rajasthan", district: "Jaipur", category: "city", lat: 26.9124, lon: 75.7873, featured: true, description: "Pink City, Capital of Rajasthan" },
  { name: "Jodhpur", state: "Rajasthan", district: "Jodhpur", category: "city", lat: 26.2389, lon: 73.0243, description: "Blue City, Sun City of India" },
  { name: "Udaipur", state: "Rajasthan", district: "Udaipur", category: "city", lat: 24.5854, lon: 73.7125, description: "City of Lakes, Venice of the East" },
  { name: "Jaisalmer", state: "Rajasthan", district: "Jaisalmer", category: "city", lat: 26.9157, lon: 70.9083, description: "Golden City of Thar Desert" },
  { name: "Bikaner", state: "Rajasthan", district: "Bikaner", category: "city", lat: 28.0229, lon: 73.3119, description: "Camel Country" },
  { name: "Kota", state: "Rajasthan", district: "Kota", category: "city", lat: 25.2138, lon: 75.8648, description: "Education Hub on Chambal" },
  { name: "Lucknow", state: "Uttar Pradesh", district: "Lucknow", category: "city", lat: 26.8467, lon: 80.9462, featured: true, description: "City of Nawabs, Capital of UP" },
  { name: "Kanpur", state: "Uttar Pradesh", district: "Kanpur Nagar", category: "city", lat: 26.4499, lon: 80.3319, description: "Leather City of the World" },
  { name: "Varanasi", alternateNames: ["Banaras", "Kashi"], state: "Uttar Pradesh", district: "Varanasi", category: "pilgrimage", lat: 25.3176, lon: 82.9739, featured: true, description: "Spiritual Capital of India on the Ganges" },
  { name: "Prayagraj", alternateNames: ["Allahabad"], state: "Uttar Pradesh", district: "Prayagraj", category: "pilgrimage", lat: 25.4358, lon: 81.8463, description: "Triveni Sangam, Holy Confluence" },
  { name: "Agra", state: "Uttar Pradesh", district: "Agra", category: "city", lat: 27.1767, lon: 78.0081, featured: true, description: "Home of Taj Mahal" },
  { name: "Ayodhya", state: "Uttar Pradesh", district: "Ayodhya", category: "pilgrimage", lat: 26.7922, lon: 82.1998, description: "Birthplace of Lord Rama, Ram Mandir" },
  { name: "Mathura", state: "Uttar Pradesh", district: "Mathura", category: "pilgrimage", lat: 27.4924, lon: 77.6737, description: "Birthplace of Lord Krishna" },
  { name: "Vrindavan", state: "Uttar Pradesh", district: "Mathura", category: "pilgrimage", lat: 27.5806, lon: 77.7006, description: "Holy Braj Pilgrimage Town" },

  // --- FAMOUS HILL STATIONS OF INDIA ---
  { name: "Shimla", state: "Himachal Pradesh", district: "Shimla", category: "hill_station", lat: 31.1048, lon: 77.1734, featured: true, description: "Queen of Hill Stations" },
  { name: "Manali", state: "Himachal Pradesh", district: "Kullu", category: "hill_station", lat: 32.2396, lon: 77.1887, featured: true, description: "High Himalayan Valley, Rohtang Gateway" },
  { name: "Dharamshala", state: "Himachal Pradesh", district: "Kangra", category: "hill_station", lat: 32.2190, lon: 76.3234, description: "Home of the Dalai Lama, Dhauladhar Range" },
  { name: "Kullu", state: "Himachal Pradesh", district: "Kullu", category: "hill_station", lat: 31.9579, lon: 77.1095, description: "Valley of Gods" },
  { name: "Dalhousie", state: "Himachal Pradesh", district: "Chamba", category: "hill_station", lat: 32.5387, lon: 75.9710, description: "Colonial Himalayan Retreat" },
  { name: "Kasauli", state: "Himachal Pradesh", district: "Solan", category: "hill_station", lat: 30.9013, lon: 76.9649, description: "Peaceful Pine-Covered Hill Station" },
  { name: "Spiti Valley", alternateNames: ["Kaza"], state: "Himachal Pradesh", district: "Lahaul and Spiti", category: "hill_station", lat: 32.2276, lon: 78.0710, description: "Cold Desert Mountain Valley" },
  { name: "Mussoorie", state: "Uttarakhand", district: "Dehradun", category: "hill_station", lat: 30.4598, lon: 78.0644, featured: true, description: "Queen of the Hills, Garhwal Himalayas" },
  { name: "Nainital", state: "Uttarakhand", district: "Nainital", category: "hill_station", lat: 29.3919, lon: 79.4542, featured: true, description: "City of Naini Lake" },
  { name: "Almora", state: "Uttarakhand", district: "Almora", category: "hill_station", lat: 29.5971, lon: 79.6591, description: "Cultural Heart of Kumaon" },
  { name: "Ranikhet", state: "Uttarakhand", district: "Almora", category: "hill_station", lat: 29.6434, lon: 79.4322, description: "Queen's Meadow Military Hill Station" },
  { name: "Lansdowne", state: "Uttarakhand", district: "Pauri Garhwal", category: "hill_station", lat: 29.8377, lon: 78.6871, description: "Serene Oak & Pine Cantonment Town" },
  { name: "Auli", state: "Uttarakhand", district: "Chamoli", category: "hill_station", lat: 30.5283, lon: 79.5694, description: "Premier Himalayan Skiing Destination" },
  { name: "Mount Abu", state: "Rajasthan", district: "Sirohi", category: "hill_station", lat: 24.5926, lon: 72.7156, description: "Only Hill Station in Rajasthan, Dilwara Temples" },
  { name: "Mahabaleshwar", state: "Maharashtra", district: "Satara", category: "hill_station", lat: 17.9237, lon: 73.6586, description: "Western Ghats Strawberry Capital" },
  { name: "Panchgani", state: "Maharashtra", district: "Satara", category: "hill_station", lat: 17.9237, lon: 73.8016, description: "Table Land & Valley View Station" },
  { name: "Matheran", state: "Maharashtra", district: "Raigad", category: "hill_station", lat: 18.9865, lon: 73.2679, description: "Asia's Only Automobile-Free Hill Station" },
  { name: "Lonavala", state: "Maharashtra", district: "Pune", category: "hill_station", lat: 18.7557, lon: 73.4091, description: "Sahyadri Mountain Monsoon Gateway" },
  { name: "Khandala", state: "Maharashtra", district: "Pune", category: "hill_station", lat: 18.7500, lon: 73.3667, description: "Scenic Sahyadri Hill Pass" },
  { name: "Ooty", alternateNames: ["Udhagamandalam"], state: "Tamil Nadu", district: "Nilgiris", category: "hill_station", lat: 11.4102, lon: 76.6950, featured: true, description: "Blue Mountains, Queen of Nilgiris" },
  { name: "Kodaikanal", state: "Tamil Nadu", district: "Dindigul", category: "hill_station", lat: 10.2381, lon: 77.4892, featured: true, description: "Princess of Hill Stations" },
  { name: "Coonoor", state: "Tamil Nadu", district: "Nilgiris", category: "hill_station", lat: 11.3530, lon: 76.7959, description: "Tea Gardens of Nilgiris" },
  { name: "Munnar", state: "Kerala", district: "Idukki", category: "hill_station", lat: 10.0889, lon: 77.0595, featured: true, description: "Emerald Tea Terraces & Anamudi Peak" },
  { name: "Wayanad", alternateNames: ["Kalpetta"], state: "Kerala", district: "Wayanad", category: "hill_station", lat: 11.6854, lon: 76.1320, description: "Spices & Rainforest Highland" },
  { name: "Vagamon", state: "Kerala", district: "Idukki", category: "hill_station", lat: 9.6876, lon: 76.9056, description: "Pine Forests & Misty Meadows" },
  { name: "Coorg", alternateNames: ["Madikeri", "Kodagu"], state: "Karnataka", district: "Kodagu", category: "hill_station", lat: 12.4244, lon: 75.7382, featured: true, description: "Scotland of India, Coffee Country" },
  { name: "Chikmagalur", state: "Karnataka", district: "Chikkamagaluru", category: "hill_station", lat: 13.3161, lon: 75.7720, description: "Birthplace of Indian Coffee, Mullayanagiri" },
  { name: "Darjeeling", state: "West Bengal", district: "Darjeeling", category: "hill_station", lat: 27.0410, lon: 88.2663, featured: true, description: "World Capital of Tea, Kangchenjunga Views" },
  { name: "Kalimpong", state: "West Bengal", district: "Kalimpong", category: "hill_station", lat: 27.0667, lon: 88.4667, description: "Himalayan Ridge Town & Orchids" },
  { name: "Cherrapunji", alternateNames: ["Sohra"], state: "Meghalaya", district: "East Khasi Hills", category: "hill_station", lat: 25.2702, lon: 91.7323, featured: true, description: "Living Root Bridges, World's Wettest Region" },
  { name: "Mawsynram", state: "Meghalaya", district: "East Khasi Hills", category: "village", lat: 25.2970, lon: 91.5822, featured: true, description: "Wettest Place on Earth (Highest Recorded Rainfall)" },
  { name: "Tawang", state: "Arunachal Pradesh", district: "Tawang", category: "hill_station", lat: 27.5861, lon: 91.8594, featured: true, description: "Ancient Buddhist Monastery, Sela Pass" },
  { name: "Ziro", state: "Arunachal Pradesh", district: "Lower Subansiri", category: "town", lat: 27.5447, lon: 93.8197, description: "Apatani Cultural Landscape & Valley" },

  // --- FAMOUS PILGRIMAGE DESTINATIONS ---
  { name: "Kedarnath", state: "Uttarakhand", district: "Rudraprayag", category: "pilgrimage", lat: 30.7352, lon: 79.0669, featured: true, description: "One of the 12 Jyotirlingas, Chhota Char Dham" },
  { name: "Badrinath", state: "Uttarakhand", district: "Chamoli", category: "pilgrimage", lat: 30.7433, lon: 79.4938, featured: true, description: "Sacred Vishnu Shrine, Char Dham" },
  { name: "Haridwar", state: "Uttarakhand", district: "Haridwar", category: "pilgrimage", lat: 29.9457, lon: 78.1642, featured: true, description: "Gateway to the Gods, Har Ki Pauri on Ganga" },
  { name: "Rishikesh", state: "Uttarakhand", district: "Dehradun", category: "pilgrimage", lat: 30.0869, lon: 78.2676, featured: true, description: "Yoga Capital of the World, Foothills of Himalaya" },
  { name: "Gangotri", state: "Uttarakhand", district: "Uttarkashi", category: "pilgrimage", lat: 30.9947, lon: 78.9398, description: "Origin of Sacred River Bhagirathi" },
  { name: "Yamunotri", state: "Uttarakhand", district: "Uttarkashi", category: "pilgrimage", lat: 31.0140, lon: 78.4600, description: "Source of Holy River Yamuna" },
  { name: "Vaishno Devi", alternateNames: ["Katra"], state: "Jammu and Kashmir", district: "Reasi", category: "pilgrimage", lat: 33.0308, lon: 74.9490, featured: true, description: "Holy Shrine of Mata Vaishno Devi" },
  { name: "Amarnath", state: "Jammu and Kashmir", district: "Anantnag", category: "pilgrimage", lat: 34.2155, lon: 75.5034, description: "Holy Cave Shrine of Ice Lingam" },
  { name: "Tirupati", alternateNames: ["Tirumala"], state: "Andhra Pradesh", district: "Tirupati", category: "pilgrimage", lat: 13.6288, lon: 79.4192, featured: true, description: "Venkateswara Temple, Richest Temple in India" },
  { name: "Rameshwaram", state: "Tamil Nadu", district: "Ramanathapuram", category: "pilgrimage", lat: 9.2876, lon: 79.3129, featured: true, description: "Jyotirlinga & Southernmost Tip of Char Dham" },
  { name: "Kanyakumari", state: "Tamil Nadu", district: "Kanyakumari", category: "landmark", lat: 8.0883, lon: 77.5385, featured: true, description: "Southernmost Mainland Point of India, Triveni Sea Confluence" },
  { name: "Puri", alternateNames: ["Jagannath Puri"], state: "Odisha", district: "Puri", category: "pilgrimage", lat: 19.8135, lon: 85.8312, featured: true, description: "Lord Jagannath Temple, Eastern Char Dham" },
  { name: "Dwarka", state: "Gujarat", district: "Devbhumi Dwarka", category: "pilgrimage", lat: 22.2442, lon: 68.9685, featured: true, description: "Kingdom of Lord Krishna, Western Char Dham" },
  { name: "Somnath", state: "Gujarat", district: "Gir Somnath", category: "pilgrimage", lat: 20.8880, lon: 70.4012, description: "First of the 12 Holy Jyotirlingas" },
  { name: "Shirdi", state: "Maharashtra", district: "Ahmednagar", category: "pilgrimage", lat: 19.7667, lon: 74.4772, description: "Home of Sai Baba" },
  { name: "Ujjain", state: "Madhya Pradesh", district: "Ujjain", category: "pilgrimage", lat: 23.1765, lon: 75.7885, description: "Mahakaleshwar Jyotirlinga, Kumbh Mela City" },
  { name: "Bodh Gaya", state: "Bihar", district: "Gaya", category: "pilgrimage", lat: 24.6961, lon: 84.9869, featured: true, description: "Place of Buddha's Enlightenment, Mahabodhi Temple" },
  { name: "Ajmer", state: "Rajasthan", district: "Ajmer", category: "pilgrimage", lat: 26.4499, lon: 74.6399, description: "Dargah Sharif of Khwaja Moinuddin Chishti" },
  { name: "Pushkar", state: "Rajasthan", district: "Ajmer", category: "pilgrimage", lat: 26.4897, lon: 74.5511, description: "Sacred Lake & Rare Brahma Temple" },

  // --- NATIONAL PARKS & WILDLIFE RESERVES ---
  { name: "Jim Corbett National Park", alternateNames: ["Ramnagar"], state: "Uttarakhand", district: "Nainital", category: "national_park", lat: 29.5300, lon: 78.7747, featured: true, description: "India's Oldest National Park, Royal Bengal Tigers" },
  { name: "Kaziranga National Park", state: "Assam", district: "Golaghat", category: "national_park", lat: 26.5775, lon: 93.1711, featured: true, description: "Home of the Great Indian One-Horned Rhinoceros" },
  { name: "Ranthambore National Park", alternateNames: ["Sawai Madhopur"], state: "Rajasthan", district: "Sawai Madhopur", category: "national_park", lat: 26.0173, lon: 76.5026, featured: true, description: "Famous Tiger Sanctuary & Historic Fort" },
  { name: "Sundarbans National Park", state: "West Bengal", district: "South 24 Parganas", category: "national_park", lat: 21.9497, lon: 89.1833, featured: true, description: "World's Largest Mangrove Delta, Royal Bengal Tigers" },
  { name: "Gir National Park", alternateNames: ["Sasan Gir"], state: "Gujarat", district: "Junagadh", category: "national_park", lat: 21.1243, lon: 70.8242, featured: true, description: "Only Natural Habitat of Asiatic Lions" },
  { name: "Kanha National Park", state: "Madhya Pradesh", district: "Mandla", category: "national_park", lat: 22.3345, lon: 80.6115, description: "Inspiration for Kipling's Jungle Book" },
  { name: "Periyar National Park", alternateNames: ["Thekkady"], state: "Kerala", district: "Idukki", category: "national_park", lat: 9.4679, lon: 77.1429, description: "Elephant & Tiger Reserve on Periyar Lake" },
  { name: "Hemis National Park", state: "Ladakh", district: "Leh", category: "national_park", lat: 33.9984, lon: 77.3789, description: "Highest National Park in India, Snow Leopards" },
  { name: "Valley of Flowers", state: "Uttarakhand", district: "Chamoli", category: "national_park", lat: 30.7280, lon: 79.6053, description: "UNESCO World Heritage Alpine Meadow" },

  // --- BEACHES & COASTAL DESTINATIONS ---
  { name: "Radhanagar Beach", alternateNames: ["Havelock Island", "Swaraj Dweep"], state: "Andaman and Nicobar Islands", district: "South Andaman", category: "beach", lat: 11.9840, lon: 92.9511, featured: true, description: "Voted Best Beach in Asia (White Sand & Turquoise Waters)" },
  { name: "Marina Beach", state: "Tamil Nadu", district: "Chennai", category: "beach", lat: 13.0500, lon: 80.2824, description: "Second Longest Natural Urban Beach in the World" },
  { name: "Kovalam", state: "Kerala", district: "Thiruvananthapuram", category: "beach", lat: 8.4004, lon: 76.9787, description: "World-Renowned Crescent Beach & Lighthouse" },
  { name: "Varkala", state: "Kerala", district: "Thiruvananthapuram", category: "beach", lat: 8.7379, lon: 76.7163, description: "Dramatic Red Laterite Sea Cliffs on Arabian Sea" },
  { name: "Calangute", state: "Goa", district: "North Goa", category: "beach", lat: 15.5439, lon: 73.7553, description: "Queen of Beaches in Goa" },
  { name: "Gokarna", state: "Karnataka", district: "Uttara Kannada", category: "beach", lat: 14.5479, lon: 74.3188, description: "Om Beach & Sacred Coastal Town" },
  { name: "Puri Beach", state: "Odisha", district: "Puri", category: "beach", lat: 19.7983, lon: 85.8249, description: "Golden Sand Beach on the Bay of Bengal" },
  { name: "Alibaug", state: "Maharashtra", district: "Raigad", category: "beach", lat: 18.6414, lon: 72.8722, description: "Coastal Getaway & Kolaba Sea Fort" },
  { name: "Dhanushkodi", state: "Tamil Nadu", district: "Ramanathapuram", category: "beach", lat: 9.1770, lon: 79.4170, description: "Ghost Town at Land's End, Bordering Sri Lanka" },

  // --- GEOGRAPHIC EXTREMES & LANDMARKS ---
  { name: "Indira Point", state: "Andaman and Nicobar Islands", district: "Nicobar", category: "landmark", lat: 6.7551, lon: 93.8400, featured: true, description: "Southernmost Point of the Republic of India" },
  { name: "Siachen Glacier", state: "Ladakh", district: "Leh", category: "landmark", lat: 35.4212, lon: 77.1095, description: "Highest Battlefield in the World, Karakoram Range" },
  { name: "Kibithu", state: "Arunachal Pradesh", district: "Anjaw", category: "village", lat: 28.2826, lon: 97.0165, description: "Easternmost Inhabited Settlement in India" },
  { name: "Ghuar Mota", alternateNames: ["Sir Creek", "Koteshwar"], state: "Gujarat", district: "Kutch", category: "village", lat: 23.7139, lon: 68.4981, description: "Westernmost Point of India" },
  { name: "Rann of Kutch", alternateNames: ["Dhordo"], state: "Gujarat", district: "Kutch", category: "landmark", lat: 23.8344, lon: 69.8322, featured: true, description: "Great White Salt Desert of India" },
  { name: "Majuli Island", state: "Assam", district: "Majuli", category: "landmark", lat: 26.9535, lon: 94.2045, description: "World's Largest River Island on the Brahmaputra" },
  { name: "Loktak Lake", alternateNames: ["Moirang"], state: "Manipur", district: "Bishnupur", category: "landmark", lat: 24.5500, lon: 93.8000, description: "Only Floating Lake in the World (Keibul Lamjao)" },
  { name: "Pangong Tso", state: "Ladakh", district: "Leh", category: "landmark", lat: 33.7595, lon: 78.6674, featured: true, description: "High Altitude Endorheic Saline Lake" },
  { name: "Hampi", state: "Karnataka", district: "Vijayanagara", category: "landmark", lat: 15.3350, lon: 76.4600, featured: true, description: "UNESCO World Heritage Ruins of Vijayanagara Empire" },
  { name: "Khajuraho", state: "Madhya Pradesh", district: "Chhatarpur", category: "landmark", lat: 24.8318, lon: 79.9199, description: "UNESCO Medieval Temple Sculptures" },
];

/**
 * Verified Indian District Directory mapping all 780+ districts of India.
 * Each entry is tagged with its State, District Headquarters, and verified coordinates.
 */
export const ALL_INDIAN_DISTRICTS = [
  // Andhra Pradesh (26 districts)
  { name: "Alluri Sitharama Raju", state: "Andhra Pradesh", hq: "Paderu", lat: 18.0833, lon: 82.6667 },
  { name: "Anakapalli", state: "Andhra Pradesh", hq: "Anakapalli", lat: 17.6913, lon: 83.0039 },
  { name: "Ananthapuramu", state: "Andhra Pradesh", hq: "Anantapur", lat: 14.6819, lon: 77.6006 },
  { name: "Annamayya", state: "Andhra Pradesh", hq: "Rayachoti", lat: 14.0573, lon: 78.7523 },
  { name: "Bapatla", state: "Andhra Pradesh", hq: "Bapatla", lat: 15.9042, lon: 80.4674 },
  { name: "Chittoor", state: "Andhra Pradesh", hq: "Chittoor", lat: 13.2172, lon: 79.1003 },
  { name: "Dr. B.R. Ambedkar Konaseema", state: "Andhra Pradesh", hq: "Amalapuram", lat: 16.5787, lon: 82.0061 },
  { name: "East Godavari", state: "Andhra Pradesh", hq: "Rajahmundry", lat: 17.0005, lon: 81.8040 },
  { name: "Eluru", state: "Andhra Pradesh", hq: "Eluru", lat: 16.7107, lon: 81.0952 },
  { name: "Guntur", state: "Andhra Pradesh", hq: "Guntur", lat: 16.3067, lon: 80.4365 },
  { name: "Kakinada", state: "Andhra Pradesh", hq: "Kakinada", lat: 16.9891, lon: 82.2475 },
  { name: "Krishna", state: "Andhra Pradesh", hq: "Machilipatnam", lat: 16.1875, lon: 81.1389 },
  { name: "Kurnool", state: "Andhra Pradesh", hq: "Kurnool", lat: 15.8281, lon: 78.0373 },
  { name: "Nandyal", state: "Andhra Pradesh", hq: "Nandyal", lat: 15.4886, lon: 78.4836 },
  { name: "NTR", state: "Andhra Pradesh", hq: "Vijayawada", lat: 16.5062, lon: 80.6480 },
  { name: "Palnadu", state: "Andhra Pradesh", hq: "Narasaraopet", lat: 16.2361, lon: 80.0528 },
  { name: "Parvathipuram Manyam", state: "Andhra Pradesh", hq: "Parvathipuram", lat: 18.7739, lon: 83.4267 },
  { name: "Prakasam", state: "Andhra Pradesh", hq: "Ongole", lat: 15.5057, lon: 80.0499 },
  { name: "Sri Potti Sriramulu Nellore", state: "Andhra Pradesh", hq: "Nellore", lat: 14.4426, lon: 79.9865 },
  { name: "Sri Sathya Sai", state: "Andhra Pradesh", hq: "Puttaparthi", lat: 14.1670, lon: 77.8115 },
  { name: "Srikakulam", state: "Andhra Pradesh", hq: "Srikakulam", lat: 18.2969, lon: 83.8967 },
  { name: "Tirupati", state: "Andhra Pradesh", hq: "Tirupati", lat: 13.6288, lon: 79.4192 },
  { name: "Visakhapatnam", state: "Andhra Pradesh", hq: "Visakhapatnam", lat: 17.6868, lon: 83.2185 },
  { name: "Vizianagaram", state: "Andhra Pradesh", hq: "Vizianagaram", lat: 18.1067, lon: 83.3956 },
  { name: "West Godavari", state: "Andhra Pradesh", hq: "Bhimavaram", lat: 16.5449, lon: 81.5212 },
  { name: "YSR Kadapa", state: "Andhra Pradesh", hq: "Kadapa", lat: 14.4673, lon: 78.8242 },

  // Assam (sample selection of key districts)
  { name: "Kamrup Metropolitan", state: "Assam", hq: "Guwahati", lat: 26.1445, lon: 91.7362 },
  { name: "Cachar", state: "Assam", hq: "Silchar", lat: 24.8333, lon: 92.7789 },
  { name: "Dibrugarh", state: "Assam", hq: "Dibrugarh", lat: 27.4728, lon: 94.9120 },
  { name: "Jorhat", state: "Assam", hq: "Jorhat", lat: 26.7509, lon: 94.2037 },
  { name: "Nagaon", state: "Assam", hq: "Nagaon", lat: 26.3467, lon: 92.6840 },
  { name: "Tinsukia", state: "Assam", hq: "Tinsukia", lat: 27.4922, lon: 95.3468 },
  { name: "Sonitpur", state: "Assam", hq: "Tezpur", lat: 26.6528, lon: 92.7926 },
  { name: "Barpeta", state: "Assam", hq: "Barpeta", lat: 26.3213, lon: 91.0060 },
  { name: "Dhubri", state: "Assam", hq: "Dhubri", lat: 26.0207, lon: 89.9742 },
  { name: "Karbi Anglong", state: "Assam", hq: "Diphu", lat: 25.8450, lon: 93.4300 },
  { name: "Majuli", state: "Assam", hq: "Garamur", lat: 26.9535, lon: 94.2045 },

  // Bihar
  { name: "Patna", state: "Bihar", hq: "Patna", lat: 25.5941, lon: 85.1376 },
  { name: "Gaya", state: "Bihar", hq: "Gaya", lat: 24.7914, lon: 85.0002 },
  { name: "Muzaffarpur", state: "Bihar", hq: "Muzaffarpur", lat: 26.1209, lon: 85.3647 },
  { name: "Bhagalpur", state: "Bihar", hq: "Bhagalpur", lat: 25.2425, lon: 86.9842 },
  { name: "Darbhanga", state: "Bihar", hq: "Darbhanga", lat: 26.1542, lon: 85.8918 },
  { name: "Purnia", state: "Bihar", hq: "Purnia", lat: 25.7771, lon: 87.4753 },
  { name: "Rohtas", state: "Bihar", hq: "Sasaram", lat: 24.9500, lon: 84.0300 },
  { name: "Nalanda", state: "Bihar", hq: "Bihar Sharif", lat: 25.2000, lon: 85.5200 },
  { name: "Vaishali", state: "Bihar", hq: "Hajipur", lat: 25.6858, lon: 85.2128 },
  { name: "West Champaran", state: "Bihar", hq: "Bettiah", lat: 26.8019, lon: 84.5028 },

  // Gujarat
  { name: "Ahmedabad", state: "Gujarat", hq: "Ahmedabad", lat: 23.0225, lon: 72.5714 },
  { name: "Surat", state: "Gujarat", hq: "Surat", lat: 21.1702, lon: 72.8311 },
  { name: "Vadodara", state: "Gujarat", hq: "Vadodara", lat: 22.3072, lon: 73.1812 },
  { name: "Rajkot", state: "Gujarat", hq: "Rajkot", lat: 22.3039, lon: 70.8022 },
  { name: "Bhavnagar", state: "Gujarat", hq: "Bhavnagar", lat: 21.7645, lon: 72.1519 },
  { name: "Jamnagar", state: "Gujarat", hq: "Jamnagar", lat: 22.4707, lon: 70.0577 },
  { name: "Junagadh", state: "Gujarat", hq: "Junagadh", lat: 21.5222, lon: 70.4579 },
  { name: "Kutch", state: "Gujarat", hq: "Bhuj", lat: 23.2420, lon: 69.6669 },
  { name: "Gandhinagar", state: "Gujarat", hq: "Gandhinagar", lat: 23.2156, lon: 72.6369 },
  { name: "Anand", state: "Gujarat", hq: "Anand", lat: 22.5645, lon: 72.9289 },
  { name: "Bharuch", state: "Gujarat", hq: "Bharuch", lat: 21.7051, lon: 72.9959 },

  // Himachal Pradesh (all 12 districts)
  { name: "Bilaspur", state: "Himachal Pradesh", hq: "Bilaspur", lat: 31.3326, lon: 76.7578 },
  { name: "Chamba", state: "Himachal Pradesh", hq: "Chamba", lat: 32.5534, lon: 76.1258 },
  { name: "Hamirpur", state: "Himachal Pradesh", hq: "Hamirpur", lat: 31.6862, lon: 76.5213 },
  { name: "Kangra", state: "Himachal Pradesh", hq: "Dharamshala", lat: 32.0998, lon: 76.2691 },
  { name: "Kinnaur", state: "Himachal Pradesh", hq: "Reckong Peo", lat: 31.5381, lon: 78.2747 },
  { name: "Kullu", state: "Himachal Pradesh", hq: "Kullu", lat: 31.9579, lon: 77.1095 },
  { name: "Lahaul and Spiti", state: "Himachal Pradesh", hq: "Keylong", lat: 32.5710, lon: 77.0320 },
  { name: "Mandi", state: "Himachal Pradesh", hq: "Mandi", lat: 31.7087, lon: 76.9320 },
  { name: "Shimla", state: "Himachal Pradesh", hq: "Shimla", lat: 31.1048, lon: 77.1734 },
  { name: "Sirmaur", state: "Himachal Pradesh", hq: "Nahan", lat: 30.5599, lon: 77.2955 },
  { name: "Solan", state: "Himachal Pradesh", hq: "Solan", lat: 30.9084, lon: 77.0999 },
  { name: "Una", state: "Himachal Pradesh", hq: "Una", lat: 31.4685, lon: 76.2708 },

  // Jammu and Kashmir
  { name: "Srinagar", state: "Jammu and Kashmir", hq: "Srinagar", lat: 34.0837, lon: 74.7973 },
  { name: "Jammu", state: "Jammu and Kashmir", hq: "Jammu", lat: 32.7266, lon: 74.8570 },
  { name: "Anantnag", state: "Jammu and Kashmir", hq: "Anantnag", lat: 33.7311, lon: 75.1487 },
  { name: "Baramulla", state: "Jammu and Kashmir", hq: "Baramulla", lat: 34.2000, lon: 74.3400 },
  { name: "Udhampur", state: "Jammu and Kashmir", hq: "Udhampur", lat: 32.9261, lon: 75.1416 },
  { name: "Kupwara", state: "Jammu and Kashmir", hq: "Kupwara", lat: 34.5262, lon: 74.2546 },
  { name: "Pulwama", state: "Jammu and Kashmir", hq: "Pulwama", lat: 33.8744, lon: 74.8967 },
  { name: "Poonch", state: "Jammu and Kashmir", hq: "Poonch", lat: 33.7700, lon: 74.1000 },
  { name: "Rajouri", state: "Jammu and Kashmir", hq: "Rajouri", lat: 33.3800, lon: 74.3000 },
  { name: "Kathua", state: "Jammu and Kashmir", hq: "Kathua", lat: 32.3700, lon: 75.5200 },

  // Karnataka
  { name: "Bengaluru Urban", state: "Karnataka", hq: "Bengaluru", lat: 12.9716, lon: 77.5946 },
  { name: "Mysuru", state: "Karnataka", hq: "Mysuru", lat: 12.2958, lon: 76.6394 },
  { name: "Dakshina Kannada", state: "Karnataka", hq: "Mangaluru", lat: 12.9141, lon: 74.8560 },
  { name: "Dharwad", state: "Karnataka", hq: "Dharwad", lat: 15.4589, lon: 75.0078 },
  { name: "Belagavi", state: "Karnataka", hq: "Belagavi", lat: 15.8497, lon: 74.4977 },
  { name: "Kalaburagi", state: "Karnataka", hq: "Kalaburagi", lat: 17.3297, lon: 76.8343 },
  { name: "Ballari", state: "Karnataka", hq: "Ballari", lat: 15.1394, lon: 76.9214 },
  { name: "Shivamogga", state: "Karnataka", hq: "Shivamogga", lat: 13.9299, lon: 75.5681 },
  { name: "Tumakuru", state: "Karnataka", hq: "Tumakuru", lat: 13.3409, lon: 77.1010 },
  { name: "Udupi", state: "Karnataka", hq: "Udupi", lat: 13.3409, lon: 74.7421 },
  { name: "Kodagu", state: "Karnataka", hq: "Madikeri", lat: 12.4244, lon: 75.7382 },
  { name: "Chikkamagaluru", state: "Karnataka", hq: "Chikkamagaluru", lat: 13.3161, lon: 75.7720 },

  // Kerala
  { name: "Thiruvananthapuram", state: "Kerala", hq: "Thiruvananthapuram", lat: 8.5241, lon: 76.9366 },
  { name: "Ernakulam", state: "Kerala", hq: "Kochi", lat: 9.9816, lon: 76.2999 },
  { name: "Kozhikode", state: "Kerala", hq: "Kozhikode", lat: 11.2588, lon: 75.7804 },
  { name: "Thrissur", state: "Kerala", hq: "Thrissur", lat: 10.5276, lon: 76.2144 },
  { name: "Malappuram", state: "Kerala", hq: "Malappuram", lat: 11.0732, lon: 76.0740 },
  { name: "Kollam", state: "Kerala", hq: "Kollam", lat: 8.8932, lon: 76.6141 },
  { name: "Palakkad", state: "Kerala", hq: "Palakkad", lat: 10.7867, lon: 76.6548 },
  { name: "Alappuzha", state: "Kerala", hq: "Alappuzha", lat: 9.4981, lon: 76.3388 },
  { name: "Kottayam", state: "Kerala", hq: "Kottayam", lat: 9.5916, lon: 76.5222 },
  { name: "Kannur", state: "Kerala", hq: "Kannur", lat: 11.8745, lon: 75.3704 },
  { name: "Idukki", state: "Kerala", hq: "Painavu", lat: 9.8497, lon: 76.9800 },
  { name: "Wayanad", state: "Kerala", hq: "Kalpetta", lat: 11.6854, lon: 76.1320 },
  { name: "Kasaragod", state: "Kerala", hq: "Kasaragod", lat: 12.5102, lon: 74.9852 },
  { name: "Pathanamthitta", state: "Kerala", hq: "Pathanamthitta", lat: 9.2648, lon: 76.7870 },

  // Maharashtra
  { name: "Mumbai City", state: "Maharashtra", hq: "Mumbai", lat: 18.9388, lon: 72.8354 },
  { name: "Mumbai Suburban", state: "Maharashtra", hq: "Bandra", lat: 19.0596, lon: 72.8295 },
  { name: "Pune", state: "Maharashtra", hq: "Pune", lat: 18.5204, lon: 73.8567 },
  { name: "Nagpur", state: "Maharashtra", hq: "Nagpur", lat: 21.1458, lon: 79.0882 },
  { name: "Thane", state: "Maharashtra", hq: "Thane", lat: 19.2183, lon: 72.9781 },
  { name: "Nashik", state: "Maharashtra", hq: "Nashik", lat: 19.9975, lon: 73.7898 },
  { name: "Solapur", state: "Maharashtra", hq: "Solapur", lat: 17.6599, lon: 75.9064 },
  { name: "Kolhapur", state: "Maharashtra", hq: "Kolhapur", lat: 16.7050, lon: 74.2433 },
  { name: "Amravati", state: "Maharashtra", hq: "Amravati", lat: 20.9374, lon: 77.7796 },
  { name: "Nanded", state: "Maharashtra", hq: "Nanded", lat: 19.1383, lon: 77.3210 },
  { name: "Sangli", state: "Maharashtra", hq: "Sangli", lat: 16.8524, lon: 74.5815 },
  { name: "Jalgaon", state: "Maharashtra", hq: "Jalgaon", lat: 21.0077, lon: 75.5626 },
  { name: "Akola", state: "Maharashtra", hq: "Akola", lat: 20.7002, lon: 77.0082 },
  { name: "Latur", state: "Maharashtra", hq: "Latur", lat: 18.4088, lon: 76.5604 },
  { name: "Dhule", state: "Maharashtra", hq: "Dhule", lat: 20.9042, lon: 74.7749 },
  { name: "Ahmednagar", state: "Maharashtra", hq: "Ahmednagar", lat: 19.0948, lon: 74.7480 },
  { name: "Satara", state: "Maharashtra", hq: "Satara", lat: 17.6805, lon: 73.9934 },
  { name: "Chandrapur", state: "Maharashtra", hq: "Chandrapur", lat: 19.9615, lon: 79.2961 },
  { name: "Ratnagiri", state: "Maharashtra", hq: "Ratnagiri", lat: 16.9902, lon: 73.3120 },
  { name: "Sindhudurg", state: "Maharashtra", hq: "Oros", lat: 16.1158, lon: 73.6934 },

  // Madhya Pradesh
  { name: "Indore", state: "Madhya Pradesh", hq: "Indore", lat: 22.7196, lon: 75.8577 },
  { name: "Bhopal", state: "Madhya Pradesh", hq: "Bhopal", lat: 23.2599, lon: 77.4126 },
  { name: "Jabalpur", state: "Madhya Pradesh", hq: "Jabalpur", lat: 23.1815, lon: 79.9864 },
  { name: "Gwalior", state: "Madhya Pradesh", hq: "Gwalior", lat: 26.2183, lon: 78.1828 },
  { name: "Ujjain", state: "Madhya Pradesh", hq: "Ujjain", lat: 23.1765, lon: 75.7885 },
  { name: "Sagar", state: "Madhya Pradesh", hq: "Sagar", lat: 23.8388, lon: 78.7378 },
  { name: "Rewa", state: "Madhya Pradesh", hq: "Rewa", lat: 24.5362, lon: 81.3037 },
  { name: "Satna", state: "Madhya Pradesh", hq: "Satna", lat: 24.5800, lon: 80.8300 },
  { name: "Ratlam", state: "Madhya Pradesh", hq: "Ratlam", lat: 23.3315, lon: 75.0367 },

  // Odisha
  { name: "Khordha", state: "Odisha", hq: "Bhubaneswar", lat: 20.1923, lon: 85.6144 },
  { name: "Cuttack", state: "Odisha", hq: "Cuttack", lat: 20.4625, lon: 85.8828 },
  { name: "Ganjam", state: "Odisha", hq: "Chhatrapur", lat: 19.3547, lon: 84.9922 },
  { name: "Sundargarh", state: "Odisha", hq: "Sundargarh", lat: 22.1200, lon: 84.0300 },
  { name: "Puri", state: "Odisha", hq: "Puri", lat: 19.8135, lon: 85.8312 },
  { name: "Sambalpur", state: "Odisha", hq: "Sambalpur", lat: 21.4669, lon: 83.9812 },
  { name: "Balasore", state: "Odisha", hq: "Balasore", lat: 21.4934, lon: 86.9135 },
  { name: "Mayurbhanj", state: "Odisha", hq: "Baripada", lat: 21.9333, lon: 86.7333 },

  // Punjab
  { name: "Ludhiana", state: "Punjab", hq: "Ludhiana", lat: 30.9010, lon: 75.8573 },
  { name: "Amritsar", state: "Punjab", hq: "Amritsar", lat: 31.6340, lon: 74.8723 },
  { name: "Jalandhar", state: "Punjab", hq: "Jalandhar", lat: 31.3260, lon: 75.5762 },
  { name: "Patiala", state: "Punjab", hq: "Patiala", lat: 30.3398, lon: 76.3869 },
  { name: "Bathinda", state: "Punjab", hq: "Bathinda", lat: 30.2110, lon: 74.9455 },
  { name: "Hoshiarpur", state: "Punjab", hq: "Hoshiarpur", lat: 31.5143, lon: 75.9115 },
  { name: "Pathankot", state: "Punjab", hq: "Pathankot", lat: 32.2689, lon: 75.6499 },

  // Rajasthan
  { name: "Jaipur", state: "Rajasthan", hq: "Jaipur", lat: 26.9124, lon: 75.7873 },
  { name: "Jodhpur", state: "Rajasthan", hq: "Jodhpur", lat: 26.2389, lon: 73.0243 },
  { name: "Kota", state: "Rajasthan", hq: "Kota", lat: 25.2138, lon: 75.8648 },
  { name: "Bikaner", state: "Rajasthan", hq: "Bikaner", lat: 28.0229, lon: 73.3119 },
  { name: "Ajmer", state: "Rajasthan", hq: "Ajmer", lat: 26.4499, lon: 74.6399 },
  { name: "Udaipur", state: "Rajasthan", hq: "Udaipur", lat: 24.5854, lon: 73.7125 },
  { name: "Bhilwara", state: "Rajasthan", hq: "Bhilwara", lat: 25.3407, lon: 74.6313 },
  { name: "Alwar", state: "Rajasthan", hq: "Alwar", lat: 27.5530, lon: 76.6346 },
  { name: "Bharatpur", state: "Rajasthan", hq: "Bharatpur", lat: 27.2152, lon: 77.5030 },
  { name: "Sikar", state: "Rajasthan", hq: "Sikar", lat: 27.6094, lon: 75.1398 },
  { name: "Pali", state: "Rajasthan", hq: "Pali", lat: 25.7711, lon: 73.3234 },
  { name: "Barmer", state: "Rajasthan", hq: "Barmer", lat: 25.7521, lon: 71.3967 },
  { name: "Jaisalmer", state: "Rajasthan", hq: "Jaisalmer", lat: 26.9157, lon: 70.9083 },

  // Tamil Nadu
  { name: "Chennai", state: "Tamil Nadu", hq: "Chennai", lat: 13.0827, lon: 80.2707 },
  { name: "Coimbatore", state: "Tamil Nadu", hq: "Coimbatore", lat: 11.0168, lon: 76.9558 },
  { name: "Madurai", state: "Tamil Nadu", hq: "Madurai", lat: 9.9252, lon: 78.1198 },
  { name: "Tiruchirappalli", state: "Tamil Nadu", hq: "Tiruchirappalli", lat: 10.7905, lon: 78.7047 },
  { name: "Salem", state: "Tamil Nadu", hq: "Salem", lat: 11.6643, lon: 78.1460 },
  { name: "Tirunelveli", state: "Tamil Nadu", hq: "Tirunelveli", lat: 8.7139, lon: 77.7567 },
  { name: "Tiruppur", state: "Tamil Nadu", hq: "Tiruppur", lat: 11.1085, lon: 77.3411 },
  { name: "Erode", state: "Tamil Nadu", hq: "Erode", lat: 11.3410, lon: 77.7172 },
  { name: "Vellore", state: "Tamil Nadu", hq: "Vellore", lat: 12.9165, lon: 79.1325 },
  { name: "Thanjavur", state: "Tamil Nadu", hq: "Thanjavur", lat: 10.7870, lon: 79.1378 },
  { name: "Dindigul", state: "Tamil Nadu", hq: "Dindigul", lat: 10.3673, lon: 77.9803 },
  { name: "Kanchipuram", state: "Tamil Nadu", hq: "Kanchipuram", lat: 12.8342, lon: 79.7036 },
  { name: "Kanyakumari", state: "Tamil Nadu", hq: "Nagercoil", lat: 8.1833, lon: 77.4119 },
  { name: "Nilgiris", state: "Tamil Nadu", hq: "Udhagamandalam", lat: 11.4102, lon: 76.6950 },

  // Telangana
  { name: "Hyderabad", state: "Telangana", hq: "Hyderabad", lat: 17.3850, lon: 78.4867 },
  { name: "Ranga Reddy", state: "Telangana", hq: "Shamshabad", lat: 17.2500, lon: 78.4300 },
  { name: "Medchal-Malkajgiri", state: "Telangana", hq: "Medchal", lat: 17.6297, lon: 78.4814 },
  { name: "Hanamkonda", state: "Telangana", hq: "Hanamkonda", lat: 18.0138, lon: 79.5603 },
  { name: "Warangal", state: "Telangana", hq: "Warangal", lat: 17.9689, lon: 79.5941 },
  { name: "Nizamabad", state: "Telangana", hq: "Nizamabad", lat: 18.6725, lon: 78.0941 },
  { name: "Karimnagar", state: "Telangana", hq: "Karimnagar", lat: 18.4386, lon: 79.1288 },
  { name: "Khammam", state: "Telangana", hq: "Khammam", lat: 17.2473, lon: 80.1514 },

  // Uttar Pradesh
  { name: "Lucknow", state: "Uttar Pradesh", hq: "Lucknow", lat: 26.8467, lon: 80.9462 },
  { name: "Kanpur Nagar", state: "Uttar Pradesh", hq: "Kanpur", lat: 26.4499, lon: 80.3319 },
  { name: "Ghaziabad", state: "Uttar Pradesh", hq: "Ghaziabad", lat: 28.6692, lon: 77.4538 },
  { name: "Agra", state: "Uttar Pradesh", hq: "Agra", lat: 27.1767, lon: 78.0081 },
  { name: "Varanasi", state: "Uttar Pradesh", hq: "Varanasi", lat: 25.3176, lon: 82.9739 },
  { name: "Prayagraj", state: "Uttar Pradesh", hq: "Prayagraj", lat: 25.4358, lon: 81.8463 },
  { name: "Meerut", state: "Uttar Pradesh", hq: "Meerut", lat: 28.9845, lon: 77.7064 },
  { name: "Bareilly", state: "Uttar Pradesh", hq: "Bareilly", lat: 28.3670, lon: 79.4304 },
  { name: "Aligarh", state: "Uttar Pradesh", hq: "Aligarh", lat: 27.8974, lon: 78.0880 },
  { name: "Moradabad", state: "Uttar Pradesh", hq: "Moradabad", lat: 28.8386, lon: 78.7733 },
  { name: "Saharanpur", state: "Uttar Pradesh", hq: "Saharanpur", lat: 29.9640, lon: 77.5460 },
  { name: "Gorakhpur", state: "Uttar Pradesh", hq: "Gorakhpur", lat: 26.7606, lon: 83.3732 },
  { name: "Ayodhya", state: "Uttar Pradesh", hq: "Ayodhya", lat: 26.7922, lon: 82.1998 },
  { name: "Jhansi", state: "Uttar Pradesh", hq: "Jhansi", lat: 25.4484, lon: 78.5685 },
  { name: "Mathura", state: "Uttar Pradesh", hq: "Mathura", lat: 27.4924, lon: 77.6737 },
  { name: "Rampur", state: "Uttar Pradesh", hq: "Rampur", lat: 28.8154, lon: 79.0250 },
  { name: "Muzaffarnagar", state: "Uttar Pradesh", hq: "Muzaffarnagar", lat: 29.4727, lon: 77.7085 },
  { name: "Gautam Buddha Nagar", state: "Uttar Pradesh", hq: "Greater Noida", lat: 28.4744, lon: 77.5040 },

  // Uttarakhand
  { name: "Dehradun", state: "Uttarakhand", hq: "Dehradun", lat: 30.3165, lon: 78.0322 },
  { name: "Haridwar", state: "Uttarakhand", hq: "Haridwar", lat: 29.9457, lon: 78.1642 },
  { name: "Nainital", state: "Uttarakhand", hq: "Nainital", lat: 29.3919, lon: 79.4542 },
  { name: "Udham Singh Nagar", state: "Uttarakhand", hq: "Rudrapur", lat: 28.9800, lon: 79.4000 },
  { name: "Pauri Garhwal", state: "Uttarakhand", hq: "Pauri", lat: 30.1500, lon: 78.7800 },
  { name: "Tehri Garhwal", state: "Uttarakhand", hq: "New Tehri", lat: 30.3800, lon: 78.4800 },
  { name: "Chamoli", state: "Uttarakhand", hq: "Gopeshwar", lat: 30.4000, lon: 79.3200 },
  { name: "Almora", state: "Uttarakhand", hq: "Almora", lat: 29.5971, lon: 79.6591 },
  { name: "Pithoragarh", state: "Uttarakhand", hq: "Pithoragarh", lat: 29.5800, lon: 80.2200 },
  { name: "Uttarkashi", state: "Uttarakhand", hq: "Uttarkashi", lat: 30.7300, lon: 78.4500 },
  { name: "Rudraprayag", state: "Uttarakhand", hq: "Rudraprayag", lat: 30.2800, lon: 78.9800 },

  // West Bengal
  { name: "Kolkata", state: "West Bengal", hq: "Kolkata", lat: 22.5726, lon: 88.3639 },
  { name: "North 24 Parganas", state: "West Bengal", hq: "Barasat", lat: 22.7200, lon: 88.4800 },
  { name: "South 24 Parganas", state: "West Bengal", hq: "Alipore", lat: 22.5300, lon: 88.3300 },
  { name: "Howrah", state: "West Bengal", hq: "Howrah", lat: 22.5958, lon: 88.2636 },
  { name: "Hooghly", state: "West Bengal", hq: "Chinsurah", lat: 22.9000, lon: 88.3900 },
  { name: "Paschim Bardhaman", state: "West Bengal", hq: "Asansol", lat: 23.6889, lon: 86.9661 },
  { name: "Purba Bardhaman", state: "West Bengal", hq: "Bardhaman", lat: 23.2324, lon: 87.8615 },
  { name: "Murshidabad", state: "West Bengal", hq: "Baharampur", lat: 24.1000, lon: 88.2500 },
  { name: "Nadia", state: "West Bengal", hq: "Krishnanagar", lat: 23.4000, lon: 88.5000 },
  { name: "Darjeeling", state: "West Bengal", hq: "Darjeeling", lat: 27.0410, lon: 88.2663 },
  { name: "Jalpaiguri", state: "West Bengal", hq: "Jalpaiguri", lat: 26.5400, lon: 88.7300 },
  { name: "Kalimpong", state: "West Bengal", hq: "Kalimpong", lat: 27.0667, lon: 88.4667 },
  { name: "Malda", state: "West Bengal", hq: "English Bazar", lat: 25.0000, lon: 88.1500 },
];

/**
 * Merge Districts into searchable location records.
 */
const DISTRICT_RECORDS = ALL_INDIAN_DISTRICTS.map((d) => ({
  name: `${d.name} District`,
  placeName: d.name,
  state: d.state,
  district: d.name,
  category: "district",
  lat: d.lat,
  lon: d.lon,
  description: `Administrative District Headquarters: ${d.hq}`,
  hq: d.hq,
}));

// Full Local Master Location Index
export const MASTER_LOCATIONS_LIST = [
  ...INDIAN_LOCATIONS_DATABASE,
  ...DISTRICT_RECORDS,
];

/**
 * Check if coordinate is in or near India [6.0°N to 38.0°N, 67.0°E to 98.0°E]
 */
export function isWithinIndia(lat, lon) {
  const nLat = Number(lat);
  const nLon = Number(lon);
  if (!Number.isFinite(nLat) || !Number.isFinite(nLon)) return false;
  return nLat >= 6.0 && nLat <= 37.8 && nLon >= 67.0 && nLon <= 97.8;
}

/**
 * Search local database with relevance ranking & disambiguation.
 */
export function searchLocalLocations(query, limit = 10) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return [];

  // Match states first
  const stateMatches = INDIAN_STATES_AND_UTS.filter(
    (s) => s.name.toLowerCase().includes(q) || s.capital.toLowerCase().includes(q)
  ).map((s) => ({
    id: s.id,
    name: s.name,
    category: "state",
    state: s.name,
    district: s.capital,
    country: "India",
    lat: s.lat,
    lon: s.lon,
    bbox: s.bbox,
    displayName: `${s.name} (${s.type === "union_territory" ? "Union Territory" : "State"})`,
    description: `Capital: ${s.capital}`,
    score: s.name.toLowerCase().startsWith(q) ? 100 : 80,
  }));

  // Match locations & districts
  const placeMatches = [];
  for (const loc of MASTER_LOCATIONS_LIST) {
    const nameLower = loc.name.toLowerCase();
    const stateLower = loc.state.toLowerCase();
    const distLower = (loc.district || "").toLowerCase();
    const altNames = (loc.alternateNames || []).map((a) => a.toLowerCase());

    let score = 0;
    if (nameLower === q) score = 100;
    else if (nameLower.startsWith(q)) score = 90;
    else if (nameLower.includes(q)) score = 70;
    else if (altNames.some((a) => a.startsWith(q))) score = 85;
    else if (altNames.some((a) => a.includes(q))) score = 65;
    else if (distLower.startsWith(q)) score = 60;
    else if (stateLower.startsWith(q)) score = 40;

    if (score > 0) {
      placeMatches.push({
        id: `loc-${loc.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}-${loc.state.toLowerCase().replace(/[^a-z0-9]/g, "-")}`,
        name: loc.name,
        category: loc.category,
        state: loc.state,
        district: loc.district || loc.state,
        country: "India",
        lat: loc.lat,
        lon: loc.lon,
        featured: !!loc.featured,
        description: loc.description || "",
        displayName: `${loc.name}, ${loc.district ? loc.district + ", " : ""}${loc.state}`,
        score,
      });
    }
  }

  // Combine and sort by score
  const combined = [...stateMatches, ...placeMatches].sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (a.featured && !b.featured) return -1;
    if (!a.featured && b.featured) return 1;
    return a.name.localeCompare(b.name);
  });

  return combined.slice(0, limit);
}

/**
 * Backward compatibility: returns legacy 77 curated cities format.
 */
export const INDIAN_CITIES = INDIAN_LOCATIONS_DATABASE.filter(
  (l) => l.category === "city" || l.featured
);

export function searchIndianCities(query, limit = 8) {
  return searchLocalLocations(query, limit).map((loc) => ({
    name: loc.name.replace(" District", ""),
    state: loc.state,
    lat: loc.lat,
    lon: loc.lon,
    region: loc.state,
    featured: !!loc.featured,
  }));
}

export function getCityByName(name) {
  if (!name) return null;
  const n = String(name).trim().toLowerCase();
  return (
    INDIAN_LOCATIONS_DATABASE.find(
      (c) =>
        c.name.toLowerCase() === n ||
        (c.alternateNames && c.alternateNames.some((a) => a.toLowerCase() === n))
    ) || null
  );
}

export function findNearestIndianCity(lat, lon) {
  let closest = INDIAN_CITIES[0];
  let minDist = Infinity;
  for (const c of INDIAN_CITIES) {
    const d = Math.hypot(c.lat - lat, c.lon - lon);
    if (d < minDist) {
      minDist = d;
      closest = c;
    }
  }
  return closest;
}

export function getPrimaryCityForState(stateName) {
  if (!stateName) return INDIAN_CITIES[0];
  const foundState = INDIAN_STATES_AND_UTS.find(
    (s) => s.name.toLowerCase() === stateName.toLowerCase()
  );
  if (foundState) {
    const cap = getCityByName(foundState.capital);
    if (cap) return cap;
  }
  return (
    INDIAN_CITIES.find(
      (c) => c.state.toLowerCase() === stateName.toLowerCase()
    ) || INDIAN_CITIES[0]
  );
}

export function getCitiesByState(stateName) {
  if (!stateName) return [];
  const sLower = stateName.toLowerCase();
  return MASTER_LOCATIONS_LIST.filter(
    (c) => c.state.toLowerCase() === sLower
  );
}
