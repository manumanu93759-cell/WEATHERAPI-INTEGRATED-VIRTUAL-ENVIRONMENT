/**
 * Provider-friendly polling: one request at a time, abort on location change/stop,
 * exponential backoff on failures, pause-able, quiet console. Pure JS so it is unit-testable.
 */
export class LivePoller {
  constructor({ fetchFn, onResult, onError, onStateChange, intervalMs = 60000, minIntervalMs = 5000, maxBackoffMs = 300000, setT = (fn, ms) => setTimeout(fn, ms), clearT = (id) => clearTimeout(id) }) {
    Object.assign(this, { fetchFn, onResult, onError, onStateChange, minIntervalMs, maxBackoffMs, setT, clearT });
    this.intervalMs = Math.max(minIntervalMs, intervalMs);
    this.timer = null; this.running = false; this.inFlight = false; this.controller = null;
    this.failures = 0; this.generation = 0; this.lastSuccess = null; this.lastErrorLogged = 0;
  }
  setInterval(ms) { this.intervalMs = Math.max(this.minIntervalMs, ms); if (this.running && !this.inFlight) this._schedule(); }
  start({ immediate = true } = {}) { this.stop(); this.running = true; this.generation++; this.failures = 0; if (immediate) this._tick(); else this._schedule(); }
  /** Call when the selected location changes: aborts the in-flight request and restarts. */
  restart() { if (!this.running) return; this.start({ immediate: true }); }
  stop() {
    this.running = false; this.generation++;
    if (this.timer) { this.clearT(this.timer); this.timer = null; }
    if (this.controller) { this.controller.abort(); this.controller = null; }
    this.inFlight = false;
  }
  delay() { return this.failures ? Math.min(this.maxBackoffMs, this.intervalMs * 2 ** Math.min(this.failures, 6)) : this.intervalMs; }
  _schedule() { if (this.timer) this.clearT(this.timer); if (!this.running) return; this.timer = this.setT(() => this._tick(), this.delay()); }
  async _tick() {
    if (!this.running || this.inFlight) return;
    this.timer = null; this.inFlight = true;
    const gen = this.generation; this.controller = new AbortController();
    try {
      const data = await this.fetchFn(this.controller.signal);
      if (gen !== this.generation) return; // stale response: location changed or poller stopped
      this.failures = 0; this.lastSuccess = Date.now();
      this.onResult?.(data, { at: this.lastSuccess });
    } catch (err) {
      if (gen !== this.generation || err?.name === "AbortError") return;
      this.failures++;
      this.onError?.(err, { failures: this.failures, nextInMs: this.delay() });
    } finally {
      if (gen === this.generation) { this.inFlight = false; this.controller = null; this._schedule(); this.onStateChange?.(); }
    }
  }
}
