import { normalize, normalizeState } from "../utils/geoText.js";

/**
 * In-memory search over states/UTs, districts (boundary dataset) and cities/towns (GeoNames).
 * Results always carry state (and district when known) so duplicate names stay unambiguous.
 */
export function buildSearchIndex({ states = [], districts = [], places = [] }) {
  const items = [];
  for (const s of states) items.push({ kind: "state", name: s.name, state: s.name, lat: s.lat, lon: s.lon, bbox: s.bbox, key: normalize(s.name), rank: 0 });
  for (const d of districts) items.push({ kind: "district", id: d.id, name: d.name, state: d.state, lat: d.lat, lon: d.lon, bbox: d.bbox, key: normalize(d.name), rank: 1 });
  for (const p of places) {
    const [name, state, district, lat, lon, isCity, pop, alts] = p;
    items.push({ kind: isCity ? "city" : "town", name, state, district, lat, lon, pop, key: normalize(name), alts: (alts || []).map(normalize), rank: isCity ? 2 : 3 });
  }
  return items;
}

export function searchPlaces(index, query, limit = 8) {
  const q = normalize(query);
  if (q.length < 2) return [];
  const scored = [];
  for (const it of index) {
    let score = -1;
    if (it.key === q) score = 100;
    else if (it.key.startsWith(q)) score = 80;
    else if (it.key.split(" ").some((w) => w.startsWith(q))) score = 60;
    else if (it.alts && it.alts.some((a) => a === q || a.startsWith(q))) score = 55;
    else if (q.length >= 3 && it.key.includes(q)) score = 30;
    else if (q.length >= 3 && normalize(it.state).startsWith(q) && it.kind !== "state") continue;
    if (score < 0) continue;
    // prefer states > districts > cities > towns, then larger places
    scored.push({ it, s: score - it.rank * 3 + Math.min(5, Math.log10((it.pop || 0) + 1)) });
  }
  scored.sort((a, b) => b.s - a.s || a.it.name.localeCompare(b.it.name));
  // De-duplicate identical (kind,name,state,district)
  const seen = new Set(), out = [];
  for (const { it } of scored) {
    const k = `${it.kind}|${it.key}|${normalizeState(it.state)}|${it.district || ""}`;
    if (seen.has(k)) continue; seen.add(k); out.push(it);
    if (out.length >= limit) break;
  }
  return out;
}

export function describeResult(r) {
  const kind = { state: "State / UT", district: "District", city: "City", town: "Town" }[r.kind] || r.kind;
  const where = r.kind === "state" ? "India" : [r.district && r.district !== r.name ? r.district + " district" : null, r.state].filter(Boolean).join(", ");
  return { kind, where };
}
