import { getCityByName } from "../data/indianCities.js";
import { getIconForCondition } from "./demoWeather.js";

const CACHE_PREFIX = "varsha.weather.cache.";
const LAST_SELECTED_CITY_KEY = "varsha.lastCity";
const USER_API_KEY_STORAGE = "varsha.userApiKey";

export function loadUserApiKey() {
  try {
    return localStorage.getItem(USER_API_KEY_STORAGE) || "";
  } catch {
    return "";
  }
}

export function saveUserApiKey(key) {
  try {
    if (key && key.trim()) localStorage.setItem(USER_API_KEY_STORAGE, key.trim());
    else localStorage.removeItem(USER_API_KEY_STORAGE);
  } catch {}
}

export function loadLastSelectedCity() {
  try {
    return localStorage.getItem(LAST_SELECTED_CITY_KEY) || "New Delhi";
  } catch {
    return "New Delhi";
  }
}

export function saveLastSelectedCity(cityName) {
  try {
    if (cityName) localStorage.setItem(LAST_SELECTED_CITY_KEY, cityName);
  } catch {}
}

export function getCachedCityWeather(cityName) {
  try {
    const raw = localStorage.getItem(`${CACHE_PREFIX}${cityName.toLowerCase()}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed;
  } catch {
    return null;
  }
}

export function saveCachedCityWeather(cityName, data) {
  try {
    localStorage.setItem(`${CACHE_PREFIX}${cityName.toLowerCase()}`, JSON.stringify(data));
  } catch {}
}


/** Parse a fetch Response as JSON; give a clear error when the host returned HTML (e.g. missing /api backend). */
async function readJson(res) {
  const text = await res.text();
  try { return JSON.parse(text); } catch {
    const err = new Error(
      /^\s*</.test(text)
        ? "The /api backend is not reachable (received HTML instead of JSON). Deploy with the Netlify Function or run `npm start`."
        : "Weather server returned an invalid response."
    );
    err.code = "API_NOT_JSON";
    throw err;
  }
}

/**
 * Checks server status and OpenWeather API key availability.
 */
export async function checkServerStatus(apiKey = null) {
  try {
    const activeKey = (apiKey != null ? apiKey : loadUserApiKey()).trim();
    const headers = {};
    if (activeKey) headers["x-api-key"] = activeKey;
    const res = await fetch("/api/status", { headers });
    if (!res.ok) throw new Error("Server status endpoint failed");
    return await readJson(res);
  } catch (err) {
    return {
      ok: false,
      hasKey: false,
      name: "VARSHA Weather Intelligence API",
      message: "Server unreachable or running in isolated frontend mode.",
    };
  }
}

/**
 * Converts OpenWeather AQI (1-5) to Indian National AQI terminology and colors.
 */
export function getAirQualityMeta(aqi) {
  switch (Number(aqi)) {
    case 1:
      return { label: "Good", color: "#10b981", badge: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30", description: "Minimal impact on health. Ideal for outdoor activity." };
    case 2:
      return { label: "Fair", color: "#84cc16", badge: "bg-lime-500/20 text-lime-400 border-lime-500/30", description: "Minor breathing discomfort to sensitive people." };
    case 3:
      return { label: "Moderate", color: "#f59e0b", badge: "bg-amber-500/20 text-amber-400 border-amber-500/30", description: "Breathing discomfort to people with lungs, asthma, and heart diseases." };
    case 4:
      return { label: "Poor", color: "#f97316", badge: "bg-orange-500/20 text-orange-400 border-orange-500/30", description: "Breathing discomfort to most people on prolonged exposure." };
    case 5:
      return { label: "Very Poor / Severe", color: "#ef4444", badge: "bg-rose-500/20 text-rose-400 border-rose-500/30", description: "Respiratory illness on prolonged exposure. Avoid outdoor activities." };
    default:
      return { label: "Unavailable", color: "#94a3b8", badge: "bg-slate-500/20 text-slate-400 border-slate-500/30", description: "Air quality telemetry not provided for this location." };
  }
}

/**
 * Derives contextual, proportionate weather advisories based on actual telemetry.
 */
export function generateContextualGuidance(weather, airQuality) {
  const guidance = [];
  const temp = Number(weather.temp);
  const humidity = Number(weather.humidity);
  const wind = Number(weather.windSpeed);
  const id = Number(weather.weatherId);
  const visibility = Number(weather.visibility);

  // Heatwave
  if (temp >= 40) {
    guidance.push({
      type: "heat",
      level: "alert",
      title: "Heatwave Alert",
      text: `Severe heatwave conditions recorded (${Math.round(temp)}°C). Restrict direct afternoon sunlight exposure and maintain regular hydration.`,
    });
  } else if (temp >= 35) {
    guidance.push({
      type: "heat",
      level: "warning",
      title: "High Temperature Advisory",
      text: `Hot daytime temperatures (${Math.round(temp)}°C). High fluid intake recommended during physical activity.`,
    });
  }

  // Thunderstorm / Squall
  if (id >= 200 && id < 300) {
    guidance.push({
      type: "storm",
      level: "alert",
      title: "Active Thunderstorm & Lightning",
      text: "Convective storm cells detected. Stay indoors, disconnect sensitive electronics, and avoid taking shelter under trees.",
    });
  }

  // Heavy Rainfall / Monsoon
  if ((id >= 500 && id < 600) || id === 502 || id === 503 || id === 504) {
    guidance.push({
      type: "monsoon",
      level: "warning",
      title: "Precipitation Alert",
      text: "Sustained rainfall observed. Waterlogging possible in urban corridors and transit choke points. Exercise caution.",
    });
  }

  // Dense Fog / Low Visibility
  if (visibility > 0 && visibility < 1000) {
    guidance.push({
      type: "transit",
      level: "warning",
      title: "Reduced Visibility Alert",
      text: `Surface visibility restricted to ${(visibility / 1000).toFixed(1)} km due to mist/fog. Highway and airport operations may experience delays.`,
    });
  }

  // Air Pollution Warning
  if (airQuality && (airQuality.aqi >= 4 || (airQuality.components?.pm2_5 && airQuality.components.pm2_5 > 60))) {
    guidance.push({
      type: "air",
      level: "alert",
      title: "Elevated Air Pollution",
      text: `Air Quality Index is ${airQuality.label} (PM2.5: ${Math.round(airQuality.components?.pm2_5 || 0)} µg/m³). Vulnerable groups should limit strenuous outdoor activity.`,
    });
  }

  // High Wind
  if (wind >= 10) {
    guidance.push({
      type: "wind",
      level: "warning",
      title: "Gusty Winds Advisory",
      text: `Wind speeds reaching ${(wind * 3.6).toFixed(0)} km/h (${wind.toFixed(1)} m/s). Secure loose outdoor objects.`,
    });
  }

  // Pleasant / Normal conditions
  if (guidance.length === 0) {
    guidance.push({
      type: "general",
      level: "info",
      title: "Normal Meteorological Conditions",
      text: "No severe weather warnings active for this sector. Atmospheric parameters are within typical seasonal ranges.",
    });
  }

  return guidance;
}

/**
 * Format IST local clock and date.
 */
export function formatIST(unixSeconds, timezoneOffset = 19800) {
  if (!Number.isFinite(unixSeconds)) return { clock: "—", date: "—", full: "—" };
  const d = new Date((unixSeconds + timezoneOffset) * 1000);
  const hours = String(d.getUTCHours()).padStart(2, "0");
  const minutes = String(d.getUTCMinutes()).padStart(2, "0");
  const clock = `${hours}:${minutes} IST`;

  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const dayName = days[d.getUTCDay()];
  const dateNum = d.getUTCDate();
  const monthName = months[d.getUTCMonth()];
  const year = d.getUTCFullYear();

  return {
    clock,
    date: `${dayName}, ${dateNum} ${monthName} ${year}`,
    full: `${dayName}, ${dateNum} ${monthName} ${year} • ${clock}`,
  };
}

/**
 * Parse 5-day / 3-hour forecast into 24h hourly and 5-day daily aggregates.
 */
function parseForecastData(forecastPayload) {
  if (!forecastPayload || !Array.isArray(forecastPayload.list)) {
    return { hourly: [], daily: [] };
  }

  const list = forecastPayload.list;
  
  // 1. Hourly: Take first 8 slots (next 24 hours in 3h increments)
  const hourly = list.slice(0, 8).map((slot) => {
    const dt = slot.dt;
    const date = new Date(dt * 1000);
    const hours = String(date.getHours()).padStart(2, "0");
    const weather0 = slot.weather?.[0] || {};
    const rain = slot.rain?.["3h"] ? (slot.rain["3h"] / 3).toFixed(1) : 0;
    const pop = Math.round((slot.pop || 0) * 100);

    return {
      time: `${hours}:00`,
      hour: date.getHours(),
      temp: Math.round(slot.main?.temp ?? 0),
      feelsLike: Math.round(slot.main?.feels_like ?? 0),
      weatherId: weather0.id || 800,
      weatherMain: weather0.main || "Clear",
      description: weather0.description || "",
      icon: getIconForCondition(weather0.id, date.getHours() < 6 || date.getHours() >= 19),
      pop,
      rain,
      windSpeed: slot.wind?.speed || 0,
    };
  });

  // 2. Daily: Group by local date string
  const dayGroups = new Map();
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  for (const slot of list) {
    const d = new Date(slot.dt * 1000);
    const key = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
    if (!dayGroups.has(key)) {
      dayGroups.set(key, []);
    }
    dayGroups.get(key).push(slot);
  }

  const daily = [];
  const entries = Array.from(dayGroups.entries()).slice(0, 5);

  for (const [, slots] of entries) {
    const firstSlot = slots[0];
    const d = new Date(firstSlot.dt * 1000);
    const dayName = dayNames[d.getDay()];
    const dateStr = d.toLocaleDateString("en-IN", { month: "short", day: "numeric" });

    let min = Infinity;
    let max = -Infinity;
    let maxPop = 0;
    const weatherCount = new Map();

    for (const s of slots) {
      if (s.main.temp_min < min) min = s.main.temp_min;
      if (s.main.temp_max > max) max = s.main.temp_max;
      if (s.pop && s.pop > maxPop) maxPop = s.pop;
      const wid = s.weather?.[0]?.id || 800;
      weatherCount.set(wid, (weatherCount.get(wid) || 0) + 1);
    }

    // Pick most frequent weather condition in this day
    let dominantWeatherId = 800;
    let dominantCount = 0;
    for (const [wid, count] of weatherCount.entries()) {
      if (count > dominantCount) {
        dominantCount = count;
        dominantWeatherId = wid;
      }
    }

    const representativeSlot = slots.find((s) => s.weather?.[0]?.id === dominantWeatherId) || firstSlot;
    const weather0 = representativeSlot.weather?.[0] || {};

    daily.push({
      dayName,
      dateStr,
      tempMin: Math.round(min),
      tempMax: Math.round(max),
      weatherId: dominantWeatherId,
      weatherMain: weather0.main || "Clear",
      description: weather0.description || "",
      icon: getIconForCondition(dominantWeatherId, false),
      pop: Math.round(maxPop * 100),
    });
  }

  return { hourly, daily };
}

/**
 * Fetch live data from backend for city or coordinates.
 */
export async function fetchLiveWeatherData({ city, lat, lon, apiKey = null, signal, skipSecondary = false } = {}) {
  const activeKey = (apiKey != null ? apiKey : loadUserApiKey()).trim();
  const headers = {};
  if (activeKey) {
    headers["x-api-key"] = activeKey;
  }

  const queryParams = new URLSearchParams();
  if (lat && lon) {
    queryParams.set("lat", lat);
    queryParams.set("lon", lon);
  } else if (city) {
    queryParams.set("city", city);
  } else {
    throw new Error("No location specified.");
  }

  // 1. Fetch current weather
  const weatherRes = await fetch(`/api/weather?${queryParams.toString()}`, { headers, signal });
  const weatherData = await readJson(weatherRes);

  if (weatherData.error === "KEY_MISSING") {
    const err = new Error(weatherData.message);
    err.code = "KEY_MISSING";
    throw err;
  }

  if (weatherData.error === "INVALID_KEY") {
    const err = new Error("Invalid OpenWeather API Key. Please verify your key at openweathermap.org.");
    err.code = "INVALID_KEY";
    throw err;
  }

  if (!weatherRes.ok || weatherData.error) {
    const err = new Error(weatherData.message || "Weather request failed.");
    err.code = weatherData.error || "WEATHER_ERROR";
    throw err;
  }

  // Coordinate check for sub-fetches
  const resolvedLat = weatherData.coord?.lat || lat;
  const resolvedLon = weatherData.coord?.lon || lon;

  // 2. Fetch forecast and air pollution concurrently
  let forecastData = null;
  let airQualityData = null;

  try {
    if (skipSecondary) throw new Error("skip");
    const [fRes, aRes] = await Promise.allSettled([
      fetch(`/api/forecast?${queryParams.toString()}`, { headers }).then((r) => r.ok ? readJson(r) : null),
      resolvedLat && resolvedLon
        ? fetch(`/api/air-pollution?lat=${resolvedLat}&lon=${resolvedLon}`, { headers }).then((r) => r.ok ? readJson(r) : null)
        : Promise.resolve(null),
    ]);

    if (fRes.status === "fulfilled") forecastData = fRes.value;
    if (aRes.status === "fulfilled") airQualityData = aRes.value;
  } catch (e) {
    // Non-fatal if secondary feeds fail
  }

  const { hourly, daily } = parseForecastData(forecastData);

  // Parse Air Quality
  let airQuality = null;
  if (airQualityData?.list?.[0]) {
    const item = airQualityData.list[0];
    const meta = getAirQualityMeta(item.main?.aqi);
    airQuality = {
      aqi: item.main?.aqi || 2,
      label: meta.label,
      color: meta.color,
      badge: meta.badge,
      description: meta.description,
      components: item.components || {},
    };
  }

  const weather0 = weatherData.weather?.[0] || {};
  const sys = weatherData.sys || {};
  const main = weatherData.main || {};
  const wind = weatherData.wind || {};
  const clouds = weatherData.clouds || {};

  const indianMeta = weatherData._indianMeta || getCityByName(weatherData.name) || {};
  const cityName = indianMeta.name || weatherData.name || city || "Unknown Location";
  const stateName = indianMeta.state || "India";

  const isNight = (() => {
    const dt = weatherData.dt || Date.now() / 1000;
    if (sys.sunrise && sys.sunset) {
      return dt < sys.sunrise || dt > sys.sunset;
    }
    const d = new Date();
    return d.getHours() < 6 || d.getHours() >= 19;
  })();

  const normalized = {
    source: weatherData._source || "live",
    isDemo: false,
    city: cityName,
    state: stateName,
    country: "IN",
    region: indianMeta.region || "Central",
    lat: resolvedLat,
    lon: resolvedLon,
    dt: weatherData.dt,
    observedAt: weatherData.dt ? weatherData.dt * 1000 : null,
    fromServerCache: !!weatherData._cached,
    hasSecondary: !skipSecondary,
    timezone: weatherData.timezone || 19800,
    temp: Math.round(main.temp),
    feelsLike: Math.round(main.feels_like),
    tempMin: Math.round(main.temp_min),
    tempMax: Math.round(main.temp_max),
    condition: weather0.main || "Clear",
    description: weather0.description || "",
    weatherId: weather0.id || 800,
    icon: getIconForCondition(weather0.id, isNight),
    humidity: main.humidity ?? null,
    windSpeed: wind.speed ?? 0,
    windDeg: wind.deg ?? 0,
    pressure: main.pressure ?? null,
    visibility: weatherData.visibility ?? 10000,
    clouds: clouds.all ?? 0,
    sunrise: sys.sunrise ?? null,
    sunset: sys.sunset ?? null,
    rain1h: weatherData.rain?.["1h"] || 0,
    pop: hourly[0]?.pop || 0,
    airQuality,
    hourly,
    daily,
    guidance: generateContextualGuidance({
      temp: main.temp,
      humidity: main.humidity,
      windSpeed: wind.speed,
      weatherId: weather0.id,
      visibility: weatherData.visibility,
    }, airQuality),
    fetchedAt: Date.now(),
  };

  if (!skipSecondary) { saveCachedCityWeather(cityName, normalized); saveLastSelectedCity(cityName); }

  return normalized;
}
