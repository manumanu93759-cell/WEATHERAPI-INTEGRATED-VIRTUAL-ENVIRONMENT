import { stateSlug } from "../utils/geoText.js";

const cache = new Map();   // url -> parsed JSON
const inflight = new Map(); // url -> Promise

/** Fetch JSON with status + content-type validation, caching and in-flight de-duplication. */
export function loadJson(url, { fetchImpl = globalThis.fetch } = {}) {
  if (cache.has(url)) return Promise.resolve(cache.get(url));
  if (inflight.has(url)) return inflight.get(url);
  const p = (async () => {
    const res = await fetchImpl(url);
    if (!res.ok) throw new Error(`Map data request failed (${res.status}) for ${url}`);
    const ct = res.headers?.get?.("content-type") || "";
    const text = await res.text();
    if (/text\/html/i.test(ct) || /^\s*</.test(text)) throw new Error(`Map data not found at ${url} (server returned HTML).`);
    const data = JSON.parse(text);
    cache.set(url, data);
    return data;
  })().finally(() => inflight.delete(url));
  inflight.set(url, p);
  return p;
}

export const loadDistrictIndex = (o) => loadJson("/data/district-index.json", o);
export const loadPlacesIndex = (o) => loadJson("/data/places-index.json", o);
export const loadStateDistricts = (stateName, o) => loadJson(`/data/districts/${stateSlug(stateName)}.json`, o);
