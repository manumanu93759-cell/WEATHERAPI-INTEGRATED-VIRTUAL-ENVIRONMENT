import { getCityByName } from "../data/indianCities.js";

/**
 * Rich realistic simulated weather scenarios designed specifically for
 * Indian meteorological zones and phenomena.
 */
export const INDIAN_WEATHER_PRESETS = {
  monsoon: {
    id: "monsoon",
    name: "Monsoon Deluge",
    description: "Heavy southwest monsoon downpour with deep cloud cover and gusty winds",
    weatherId: 502,
    weatherMain: "Rain",
    weatherDescription: "heavy intensity rain",
    temp: 26,
    feelsLike: 29,
    tempMin: 24,
    tempMax: 28,
    humidity: 92,
    windSpeed: 7.8,
    windDeg: 235,
    pressure: 1002,
    visibility: 3200,
    clouds: 96,
    pop: 95,
    rain1h: 18.5,
    aqi: 1, // Rain washes out particulate matter
    components: { pm2_5: 14, pm10: 28, no2: 12, o3: 18, so2: 6, co: 320 },
    guidance: [
      { type: "monsoon", level: "warning", title: "Heavy Monsoon Rainfall", text: "Active monsoon conditions. Waterlogging likely in low-lying urban areas. Avoid unnecessary travel." },
      { type: "comfort", level: "info", title: "Clean Air Window", text: "Rain scavenging has brought PM2.5 levels to the 'Good' range across the city." }
    ]
  },
  thunderstorm: {
    id: "thunderstorm",
    name: "Kalbaisakhi / Thunderstorm",
    description: "Severe pre-monsoon convective squall with lightning and torrential rain",
    weatherId: 211,
    weatherMain: "Thunderstorm",
    weatherDescription: "thunderstorm with heavy rain",
    temp: 24,
    feelsLike: 27,
    tempMin: 22,
    tempMax: 33,
    humidity: 88,
    windSpeed: 13.5,
    windDeg: 290,
    pressure: 998,
    visibility: 2500,
    clouds: 98,
    pop: 90,
    rain1h: 24.0,
    aqi: 2,
    components: { pm2_5: 35, pm10: 62, no2: 24, o3: 38, so2: 10, co: 480 },
    guidance: [
      { type: "storm", level: "alert", title: "Thunderstorm & High Wind Advisory", text: "Squally winds exceeding 45 km/h with frequent lightning. Stay indoors and away from trees and tin sheds." },
      { type: "safety", level: "warning", title: "Flash Flooding Risk", text: "Sudden precipitation rate > 20 mm/hr may overwhelm local drainage systems." }
    ]
  },
  heatwave: {
    id: "heatwave",
    name: "Summer Heatwave (Loo)",
    description: "Scorching dry heat with intense sunlight typical of peak North/Central Indian summer",
    weatherId: 800,
    weatherMain: "Clear",
    weatherDescription: "clear sky and extreme heat",
    temp: 42,
    feelsLike: 45,
    tempMin: 31,
    tempMax: 44,
    humidity: 24,
    windSpeed: 5.2,
    windDeg: 280,
    pressure: 1006,
    visibility: 8000,
    clouds: 5,
    pop: 0,
    rain1h: 0,
    aqi: 3,
    components: { pm2_5: 78, pm10: 165, no2: 42, o3: 88, so2: 16, co: 620 },
    guidance: [
      { type: "heat", level: "alert", title: "Severe Heatwave Alert", text: "Maximum temperature exceeding 42°C. High risk of dehydration and heat exhaustion. Maintain electrolyte intake and avoid peak afternoon sun (12 PM - 4 PM)." },
      { type: "uv", level: "warning", title: "High UV Radiation", text: "UV index is extremely high (10+). Wear protective clothing, sunglasses, and high-SPF sunscreen." }
    ]
  },
  fog: {
    id: "fog",
    name: "Winter Fog & Smog",
    description: "Dense radiation fog combined with winter temperature inversion",
    weatherId: 741,
    weatherMain: "Fog",
    weatherDescription: "dense fog with low visibility",
    temp: 13,
    feelsLike: 12,
    tempMin: 8,
    tempMax: 18,
    humidity: 95,
    windSpeed: 1.2,
    windDeg: 45,
    pressure: 1018,
    visibility: 400,
    clouds: 60,
    pop: 5,
    rain1h: 0,
    aqi: 5, // Severe smog
    components: { pm2_5: 280, pm10: 420, no2: 74, o3: 32, so2: 28, co: 1800 },
    guidance: [
      { type: "air", level: "alert", title: "Severe Air Quality Advisory", text: "PM2.5 levels in the hazardous category. Sensitive individuals, children, and elderly should remain indoors. N95 masks advised outdoors." },
      { type: "transit", level: "warning", title: "Dense Fog Alert", text: "Surface visibility below 500 meters. Major flight and train schedule disruptions expected. Drive with low-beam fog lights." }
    ]
  },
  pleasant: {
    id: "pleasant",
    name: "Mild Deccan Breeze",
    description: "Comfortable, partly cloudy climate with gentle breeze and ideal humidity",
    weatherId: 802,
    weatherMain: "Clouds",
    weatherDescription: "scattered clouds",
    temp: 24,
    feelsLike: 24,
    tempMin: 18,
    tempMax: 28,
    humidity: 58,
    windSpeed: 3.8,
    windDeg: 110,
    pressure: 1014,
    visibility: 9500,
    clouds: 40,
    pop: 15,
    rain1h: 0,
    aqi: 2,
    components: { pm2_5: 38, pm10: 68, no2: 22, o3: 40, so2: 8, co: 410 },
    guidance: [
      { type: "general", level: "info", title: "Favorable Weather Window", text: "Mild temperatures and moderate humidity provide optimal conditions for outdoor recreation." },
      { type: "air", level: "info", title: "Moderate Air Quality", text: "Air quality index is satisfactory for most healthy adults." }
    ]
  },
  snow: {
    id: "snow",
    name: "Himalayan Snowfall",
    description: "Western Disturbance bringing snowfall to high-altitude Himalayan ranges",
    weatherId: 601,
    weatherMain: "Snow",
    weatherDescription: "snow showers",
    temp: -2,
    feelsLike: -7,
    tempMin: -5,
    tempMax: 3,
    humidity: 82,
    windSpeed: 5.4,
    windDeg: 340,
    pressure: 1022,
    visibility: 2200,
    clouds: 90,
    pop: 85,
    rain1h: 0,
    aqi: 1,
    components: { pm2_5: 8, pm10: 16, no2: 6, o3: 25, so2: 2, co: 180 },
    guidance: [
      { type: "cold", level: "warning", title: "Sub-Zero Freeze Advisory", text: "Freezing temperatures and black ice on mountain passes. Heavy winter gear and snow chains required." },
      { type: "scenic", level: "info", title: "Pristine Atmospheric Clarity", text: "Himalayan air mass provides exceptionally clean air and pristine visual range." }
    ]
  }
};

// Canonical six demo scenarios (Sunny / Cloudy / Rainy / Snowy / Thunderstorm / Foggy).
const mkPreset = (base, o) => ({ ...INDIAN_WEATHER_PRESETS[base], ...o });
INDIAN_WEATHER_PRESETS.sunny = mkPreset("pleasant", {
  id: "sunny", name: "Sunny", description: "Clear skies with bright sunshine",
  weatherId: 800, weatherMain: "Clear", weatherDescription: "clear sky",
  temp: 28, feelsLike: 29, tempMin: 20, tempMax: 31, humidity: 62, windSpeed: 3.3, windDeg: 90,
  pressure: 1012, visibility: 10000, clouds: 6, pop: 0,
});
INDIAN_WEATHER_PRESETS.cloudy = mkPreset("pleasant", {
  id: "cloudy", name: "Cloudy", description: "Heavy broken cloud cover, soft diffuse light",
  weatherId: 804, weatherMain: "Clouds", weatherDescription: "overcast clouds",
  temp: 22, feelsLike: 22, tempMin: 19, tempMax: 25, humidity: 70, windSpeed: 5.2, windDeg: 210,
  pressure: 1010, visibility: 8000, clouds: 90, pop: 25,
});
INDIAN_WEATHER_PRESETS.rainy = mkPreset("monsoon", {
  id: "rainy", name: "Rainy", description: "Steady moderate rain with low cloud",
  weatherId: 501, weatherMain: "Rain", weatherDescription: "moderate rain",
  temp: 20, feelsLike: 20, tempMin: 18, tempMax: 23, humidity: 86, windSpeed: 5.8, windDeg: 240,
  pressure: 1008, visibility: 5000, clouds: 88, pop: 85, rain1h: 4.5,
});

/**
 * Generate simulated hourly forecast (8 slots, 3-hour intervals over 24h)
 */
function generateSimulatedHourly(base, isNight) {
  const hours = [];
  const startHour = new Date().getHours();
  
  for (let i = 0; i < 8; i += 1) {
    const slotHour = (startHour + i * 3) % 24;
    const isSlotNight = slotHour < 6 || slotHour >= 19;
    
    // diurnal temp variation
    const tempOffset = isSlotNight ? -3.5 : (slotHour >= 12 && slotHour <= 15 ? 2.5 : 0);
    const slotTemp = Math.round(base.temp + tempOffset + (Math.sin(i) * 1.5));
    
    let pop = base.pop;
    if (base.id === "monsoon") pop = Math.min(100, Math.max(70, base.pop + (i % 2 === 0 ? 5 : -10)));
    else if (base.id === "thunderstorm") pop = i < 3 ? base.pop : Math.max(20, base.pop - i * 15);
    else if (base.id === "heatwave") pop = 0;

    hours.push({
      time: `${String(slotHour).padStart(2, "0")}:00`,
      hour: slotHour,
      temp: slotTemp,
      feelsLike: slotTemp + (base.feelsLike - base.temp),
      weatherId: base.weatherId,
      weatherMain: base.weatherMain,
      description: base.weatherDescription,
      icon: getIconForCondition(base.weatherId, isSlotNight),
      pop,
      rain: pop > 50 ? (base.rain1h * (pop / 100)).toFixed(1) : 0,
      windSpeed: base.windSpeed + Math.sin(i * 1.2) * 1.5,
    });
  }
  return hours;
}

/**
 * Generate simulated 5-day daily forecast
 */
function generateSimulatedDaily(base) {
  const days = [];
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const now = new Date();

  for (let i = 1; i <= 5; i += 1) {
    const d = new Date();
    d.setDate(now.getDate() + i);
    const dayName = dayNames[d.getDay()];
    const dateStr = d.toLocaleDateString("en-IN", { month: "short", day: "numeric" });
    
    const varFactor = Math.sin(i * 1.5) * 2;
    const min = Math.round(base.tempMin + varFactor - 1);
    const max = Math.round(base.tempMax + varFactor + 1);
    
    let pop = base.pop;
    if (base.id === "monsoon") pop = Math.round(Math.min(95, Math.max(65, 85 + Math.sin(i) * 15)));
    else if (base.id === "heatwave") pop = 0;
    else pop = Math.round(Math.min(90, Math.max(10, base.pop + Math.sin(i * 2) * 25)));

    days.push({
      dayName,
      dateStr,
      tempMin: min,
      tempMax: max,
      weatherId: base.weatherId,
      weatherMain: base.weatherMain,
      description: base.weatherDescription,
      icon: getIconForCondition(base.weatherId, false),
      pop,
    });
  }
  return days;
}

export function getIconForCondition(id, isNight = false) {
  if (id >= 200 && id < 300) return "⚡"; // Thunderstorm
  if (id >= 300 && id < 600) return "🌧️"; // Rain / Drizzle
  if (id >= 600 && id < 700) return "❄️"; // Snow
  if (id >= 700 && id < 800) return "🌫️"; // Atmosphere / Fog
  if (id === 800) return isNight ? "🌙" : "☀️"; // Clear
  if (id === 801 || id === 802) return isNight ? "☁️" : "⛅"; // Few clouds
  if (id > 802) return "☁️"; // Overcast
  return "🌤️";
}

/**
 * Creates a complete simulated weather bundle adhering to the real schema
 */
export function createSimulatedWeatherBundle({
  presetKey = "pleasant",
  cityName = "Bengaluru",
  isNight = false,
} = {}) {
  const base = INDIAN_WEATHER_PRESETS[presetKey] || INDIAN_WEATHER_PRESETS.pleasant;
  const cityMeta = getCityByName(cityName) || {
    name: cityName,
    state: "India",
    lat: 12.9716,
    lon: 77.5946,
    region: "South"
  };

  const now = Math.floor(Date.now() / 1000);
  // IST sunrise ~ 6:00 AM, sunset ~ 6:15 PM
  const sunrise = now - (isNight ? 14 * 3600 : 4 * 3600);
  const sunset = now + (isNight ? -2 * 3600 : 7 * 3600);

  const hourly = generateSimulatedHourly(base, isNight);
  const daily = generateSimulatedDaily(base);

  return {
    source: "demo",
    isDemo: true,
    presetId: base.id,
    presetName: base.name,
    city: cityMeta.name,
    state: cityMeta.state,
    country: "IN",
    region: cityMeta.region,
    lat: cityMeta.lat,
    lon: cityMeta.lon,
    dt: now,
    timezone: 19800, // IST UTC+5:30
    temp: base.temp,
    feelsLike: base.feelsLike,
    tempMin: base.tempMin,
    tempMax: base.tempMax,
    condition: base.weatherMain,
    description: base.weatherDescription,
    weatherId: base.weatherId,
    icon: getIconForCondition(base.weatherId, isNight),
    humidity: base.humidity,
    windSpeed: base.windSpeed,
    windDeg: base.windDeg,
    pressure: base.pressure,
    visibility: base.visibility,
    clouds: base.clouds,
    sunrise,
    sunset,
    rain1h: base.rain1h,
    pop: base.pop,
    airQuality: {
      aqi: base.aqi,
      label: ["Good", "Fair", "Moderate", "Poor", "Very Poor"][base.aqi - 1] || "Moderate",
      components: base.components,
    },
    hourly,
    daily,
    guidance: base.guidance,
    fetchedAt: Date.now(),
  };
}
