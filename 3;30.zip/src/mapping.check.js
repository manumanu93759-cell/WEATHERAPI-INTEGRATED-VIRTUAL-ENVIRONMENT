import { mapWeatherToEnvironment, computeSolarPhase } from "./environment.js";
import { createDemoWeather } from "./demo.js";
import { parseWeatherPayload } from "./weather.js";
import { createSimulatedWeatherBundle } from "./services/demoWeather.js";

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

// 1. Existing baseline tests
const rain = mapWeatherToEnvironment(createDemoWeather({ preset: "rain", timeOfDay: "day" }));
assert(rain.rainIntensity > 0.5, "Rain preset should enable rain");
assert(rain.snowIntensity < 0.1, "Rain preset should not look like snow");

const storm = mapWeatherToEnvironment(createDemoWeather({ preset: "thunderstorm" }));
assert(storm.storminess > 0.8, "Thunderstorm should be stormy");
assert(storm.rainIntensity > 0.8, "Thunderstorm should include heavy rain");

const fog = mapWeatherToEnvironment(createDemoWeather({ preset: "fog" }));
assert(fog.fogDensity > rain.fogDensity, "Fog should be denser than rain fog");

const snow = mapWeatherToEnvironment(createDemoWeather({ preset: "snow" }));
assert(snow.snowIntensity > 0.5, "Snow preset should enable snow");
assert(snow.rainIntensity === 0, "Snow should not also dump rain");

const night = mapWeatherToEnvironment(createDemoWeather({ preset: "clear", timeOfDay: "night" }));
assert(night.dayFactor < 0.2, "Night demo should be dark");
assert(night.starVisibility > 0.4, "Clear night should show stars");

const day = mapWeatherToEnvironment(createDemoWeather({ preset: "clear", timeOfDay: "day" }));
assert(day.dayFactor > 0.8, "Day demo should be bright");
assert(day.sunIntensity > night.sunIntensity, "Day sun should beat night sun");

const cloudy = mapWeatherToEnvironment(createDemoWeather({ preset: "cloudy" }));
assert(cloudy.cloudDensity > day.cloudDensity, "Cloudy should add clouds");
assert(cloudy.sunIntensity < day.sunIntensity, "Clouds should soften sunlight");

const windy = mapWeatherToEnvironment(createDemoWeather({ preset: "clear", windSpeed: 14 }));
assert(windy.windSpeed === 14, "Wind speed should pass through");

// 2. Indian Monsoon and Heatwave tests
const monsoonBundle = createSimulatedWeatherBundle({ presetKey: "monsoon", cityName: "Mumbai" });
const monsoonEnv = mapWeatherToEnvironment(monsoonBundle);
assert(monsoonEnv.isMonsoon === 1, "Monsoon preset should set isMonsoon = 1");
assert(monsoonEnv.rainIntensity >= 0.9, "Monsoon should trigger heavy rain");
assert(monsoonEnv.cloudDensity >= 0.9, "Monsoon should have dense cloud cover");

const heatwaveBundle = createSimulatedWeatherBundle({ presetKey: "heatwave", cityName: "New Delhi" });
const heatwaveEnv = mapWeatherToEnvironment(heatwaveBundle);
assert(heatwaveEnv.temperatureAccent > 0.8, "Heatwave should have high temperature accent");
assert(heatwaveEnv.rainIntensity === 0, "Heatwave should have 0 rain");

const missing = mapWeatherToEnvironment(
  parseWeatherPayload({ name: "Nowhere", weather: [], main: {}, wind: {}, clouds: {}, sys: {} }, "live")
);
assert(Number.isFinite(missing.fogDensity), "Missing fields must still map safely");

const dawn = computeSolarPhase(1000, 1000, 10_000);
assert(dawn.phase === "dawn", "Sunrise window is dawn");
const afterSunset = computeSolarPhase(20_000, 1000, 10_000);
assert(afterSunset.phase === "night", "After sunset is night");

console.log("mapping.check.js: all environment mapping assertions passed (including Indian Monsoon & Heatwave)");
