const STORAGE_KEY = "skyshift.apiKey";
const STORAGE_CITY = "skyshift.city";
const MIN_REFRESH_MS = 60_000;
const ENDPOINT = "https://api.openweathermap.org/data/2.5/weather";

let lastFetchAt = 0;
let inFlight = null;

export function loadSavedKey() {
  try {
    return localStorage.getItem(STORAGE_KEY) || "";
  } catch {
    return "";
  }
}

export function saveKey(key) {
  try {
    if (key) localStorage.setItem(STORAGE_KEY, key);
    else localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Private mode or blocked storage should not crash the app.
  }
}

export function loadSavedCity() {
  try {
    return localStorage.getItem(STORAGE_CITY) || "Bengaluru";
  } catch {
    return "Bengaluru";
  }
}

export function saveCity(city) {
  try {
    localStorage.setItem(STORAGE_CITY, city);
  } catch {
    /* ignore */
  }
}

function asNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function asString(value, fallback = "") {
  return typeof value === "string" && value.trim() ? value : fallback;
}

/**
 * Normalize the OpenWeather payload into a stable shape the rest of the app
 * can consume even if some fields are missing.
 */
export function parseWeatherPayload(data, source = "live") {
  const weather0 = Array.isArray(data?.weather) ? data.weather[0] || {} : {};
  const sys = data?.sys || {};
  const main = data?.main || {};
  const wind = data?.wind || {};
  const clouds = data?.clouds || {};

  return {
    source,
    city: asString(data?.name, "Unknown location"),
    country: asString(sys.country, ""),
    temp: asNumber(main.temp, null),
    feelsLike: asNumber(main.feels_like, null),
    description: asString(weather0.description, "unknown conditions"),
    weatherId: asNumber(weather0.id, 800),
    weatherMain: asString(weather0.main, "Clear"),
    humidity: asNumber(main.humidity, null),
    windSpeed: asNumber(wind.speed, 0),
    windDeg: asNumber(wind.deg, 0),
    clouds: asNumber(clouds.all, 0),
    visibility: asNumber(data?.visibility, 10000),
    pressure: asNumber(main.pressure, null),
    sunrise: asNumber(sys.sunrise, null),
    sunset: asNumber(sys.sunset, null),
    timezone: asNumber(data?.timezone, 0),
    dt: asNumber(data?.dt, Math.floor(Date.now() / 1000)),
    fetchedAt: Date.now(),
  };
}

export function formatLocalClock(unixSeconds, timezoneOffset) {
  if (!Number.isFinite(unixSeconds)) return "—";
  const localMs = (unixSeconds + asNumber(timezoneOffset, 0)) * 1000;
  const date = new Date(localMs);
  const hours = String(date.getUTCHours()).padStart(2, "0");
  const minutes = String(date.getUTCMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}

export function describeApiError(status, message) {
  if (status === 401) return "Invalid API key. Check the key in your OpenWeather account.";
  if (status === 404) return "City not found. Try a different spelling or include the country code.";
  if (status === 429) return "OpenWeather rate limit reached. Wait a minute, then sync again.";
  if (status >= 500) return "OpenWeather is unavailable right now. Demo mode still works.";
  return message || "Weather request failed.";
}

export async function fetchCurrentWeather(city, apiKey, { force = false } = {}) {
  const trimmedCity = asString(city).trim();
  const trimmedKey = asString(apiKey).trim();

  if (!trimmedCity) {
    throw Object.assign(new Error("Enter a city name."), { code: "validation" });
  }
  if (!trimmedKey) {
    throw Object.assign(new Error("Paste an OpenWeather API key to use live weather."), {
      code: "validation",
    });
  }

  const now = Date.now();
  if (!force && now - lastFetchAt < MIN_REFRESH_MS && inFlight) {
    return inFlight;
  }
  if (!force && now - lastFetchAt < MIN_REFRESH_MS) {
    const wait = Math.ceil((MIN_REFRESH_MS - (now - lastFetchAt)) / 1000);
    throw Object.assign(
      new Error(`Live weather was just synced. Try again in ${wait}s to avoid extra API calls.`),
      { code: "throttle" }
    );
  }

  if (inFlight) {
    return inFlight;
  }

  const params = new URLSearchParams({
    q: trimmedCity,
    appid: trimmedKey,
    units: "metric",
  });

  const request = (async () => {
    let response;
    try {
      response = await fetch(`${ENDPOINT}?${params.toString()}`);
    } catch {
      throw Object.assign(new Error("Network error. Check your connection and try again."), {
        code: "network",
      });
    }

    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (!response.ok) {
      const apiMessage = asString(payload?.message, "");
      throw Object.assign(new Error(describeApiError(response.status, apiMessage)), {
        code: "http",
        status: response.status,
      });
    }

    if (!payload || typeof payload !== "object") {
      throw Object.assign(new Error("Unexpected weather payload."), { code: "parse" });
    }

    lastFetchAt = Date.now();
    return parseWeatherPayload(payload, "live");
  })();

  inFlight = request;
  try {
    return await request;
  } finally {
    inFlight = null;
  }
}

export const MIN_REFRESH_SECONDS = MIN_REFRESH_MS / 1000;
